Edge Connector Chrome Native v1.1.10

핵심 변경:
- 확장 프로그램을 실행할 때마다 repo 최신 버전을 확인합니다.
- Repo URL: https://etech-symantec.github.io/edge-connect/downloads/version.json
- Cache-Control: no-cache/no-store + timestamp query를 사용합니다.
- 로컬 버전은 %LOCALAPPDATA%\Etech\EdgeConnector\edge-connector.version에서 읽습니다.
- 로컬 버전이 repo 최신보다 낮으면 공식 Install_Edge_Connector.cmd를 다시 실행해 자동 업데이트합니다.
- 업데이트 후 로컬 버전이 repo 최신에 도달했는지 다시 검증합니다.
- 버전 비교는 숫자 단위로 수행합니다. 예: 1.29 < 1.38, 1.10 > 1.9.
- 최신 버전이면 재설치하지 않고 바로 Edge Connector를 실행합니다.
- 실행 후 실제 동적 127.0.0.1 포트를 찾아 자동 접속합니다.

현재 사용자가 확인한 repo 최신 버전이 1.38이어도 1.38은 코드에 하드코딩하지 않았습니다.
향후 version.json이 1.39/1.40 등으로 변경되면 자동으로 해당 버전을 설치합니다.

Chrome Extension ID:
afpojmpdnpchpnomphpphmhbdehpbenl

Native Host:
com.etech.edgeconnector

Native Host SHA-256:
BEED0FD327FEB3AF4268F222C9EBF514E7A6C5372AACDC5C494A8B300205B20A

이미지 파일:
0개

기존 v1.1.7 사용자:
1. Install_Edge_Connector_Chrome_Native_v1.1.10.cmd 실행
2. chrome://extensions 에서 ProxySG Edge Connector 새로고침
3. 확장 아이콘 클릭
4. 설치 버전이 1.29라면 repo 최신 1.38을 확인한 뒤 자동 업데이트 후 실행


v1.1.10 업데이트 잠금 개선:
- 업데이트 전에 Edge_Connector.exe / 구버전 프로세스 트리를 강제 종료
- EdgeConnector 설치 폴더에서 실행 중인 프로세스도 추가 종료
- PID 소멸 확인 후 0.9초 파일 핸들 해제 대기
- 설치 실패 시 프로세스 종료를 다시 수행하고 최대 3회 자동 재시도
- curl 진행률은 오류 화면에서 제거하고 핵심 설치 오류만 표시


v1.1.10 업데이트 잠금 해결
---------------------------
기존 v1.1.9에서는 Chrome이 실행한 Native Host의 일반 사용자 권한으로
Edge_Connector.exe를 종료하려 했기 때문에, Edge Connector가 높은 권한으로
실행된 경우 PID를 찾고도 종료하지 못할 수 있었습니다.

v1.1.10에서는 업데이트가 필요한 경우:
1. Repo 최신 버전 확인
2. 관리자 권한(UAC) 업데이트 helper 실행
3. 관리자 권한으로 Edge_Connector.exe 및 설치 폴더 프로세스 종료
4. 최대 20초 동안 실제 종료 여부 확인
5. 공식 Install_Edge_Connector.cmd 실행
6. 실패 시 최대 3회 재시도
7. 설치 버전 재검증
8. 최신 Edge Connector 실행
9. 실제 127.0.0.1 동적 LISTEN 포트로 접속

업데이트가 필요하지 않은 경우 UAC는 뜨지 않습니다.

Native Host SHA-256:
0D10B83172CAF112B9EE3BEDF76CFB085129F9CE030A93CF4C6CDA0BF99CEE91
