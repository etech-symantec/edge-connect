package main

import (
	"bufio"
	"encoding/binary"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const (
	installerURL = "https://etech-symantec.github.io/edge-connect/downloads/Install_Edge_Connector.cmd"
	versionURL   = "https://etech-symantec.github.io/edge-connect/downloads/version.json"
	hostVersion  = "1.1.11"
)

type Request struct {
	Cmd string `json:"cmd"`
}

type Response struct {
	OK               bool   `json:"ok"`
	Installed        bool   `json:"installed"`
	Launched         bool   `json:"launched"`
	Updated          bool   `json:"updated,omitempty"`
	URL              string `json:"url,omitempty"`
	Port             int    `json:"port,omitempty"`
	InstalledVersion string `json:"installedVersion,omitempty"`
	LatestVersion    string `json:"latestVersion,omitempty"`
	Warning          string `json:"warning,omitempty"`
	Error            string `json:"error,omitempty"`
	Detail           string `json:"detail,omitempty"`
}

func main() {
	in := bufio.NewReader(os.Stdin)
	for {
		var n uint32
		if err := binary.Read(in, binary.LittleEndian, &n); err != nil {
			if err == io.EOF {
				return
			}
			send(Response{OK: false, Error: "read length failed", Detail: err.Error()})
			return
		}
		if n == 0 || n > 1024*1024 {
			send(Response{OK: false, Error: "invalid message length"})
			return
		}
		buf := make([]byte, n)
		if _, err := io.ReadFull(in, buf); err != nil {
			send(Response{OK: false, Error: "read message failed", Detail: err.Error()})
			return
		}
		var req Request
		if err := json.Unmarshal(buf, &req); err != nil {
			send(Response{OK: false, Error: "invalid json", Detail: err.Error()})
			continue
		}
		switch req.Cmd {
		case "status":
			send(status())
		case "launch":
			send(launch(false))
		case "ensure", "":
			send(launch(true))
		default:
			send(Response{OK: false, Error: "unknown command"})
		}
	}
}

func send(v Response) {
	b, _ := json.Marshal(v)
	_ = binary.Write(os.Stdout, binary.LittleEndian, uint32(len(b)))
	_, _ = os.Stdout.Write(b)
}

func connectorDir() string {
	return filepath.Join(os.Getenv("LOCALAPPDATA"), "Etech", "EdgeConnector")
}

func connectorPath() string {
	return filepath.Join(connectorDir(), "Edge_Connector.exe")
}

func status() Response {
	exe := connectorPath()
	ver := installedVersion()
	if _, err := os.Stat(exe); err != nil {
		return Response{OK: true, Installed: false, InstalledVersion: ver}
	}
	if url, port := findRunningURL(); url != "" {
		return Response{OK: true, Installed: true, Launched: true, URL: url, Port: port, InstalledVersion: ver}
	}
	return Response{OK: true, Installed: true, InstalledVersion: ver}
}

func launch(installIfMissing bool) Response {
	exe := connectorPath()
	_, statErr := os.Stat(exe)
	exists := statErr == nil
	installedVer := installedVersion()

	// Every ensure/launch checks the repository first. This deliberately uses
	// no-cache semantics so a newly published Edge Connector is picked up.
	latestVer, versionErr := fetchLatestVersion()
	warning := ""
	updated := false

	if versionErr != nil {
		warning = "repo version check failed: " + versionErr.Error()
		if !exists {
			if !installIfMissing {
				return Response{OK: false, Installed: false, Error: "Edge Connector is not installed", Detail: warning}
			}
			if err := installConnector(); err != nil {
				return Response{OK: false, Installed: false, Error: "install failed", Detail: err.Error()}
			}
			exists = true
			installedVer = installedVersion()
			updated = true
		}
	} else {
		needUpdate := !exists || installedVer == "" || compareVersions(installedVer, latestVer) < 0
		if needUpdate {
			if !installIfMissing && !exists {
				return Response{OK: false, Installed: false, LatestVersion: latestVer, Error: "Edge Connector is not installed"}
			}
			if err := installConnector(); err != nil {
				return Response{OK: false, Installed: exists, InstalledVersion: installedVer, LatestVersion: latestVer, Error: "install/update failed", Detail: err.Error()}
			}
			exists = true
			updated = true
			installedVer = installedVersion()

			// The official installer writes edge-connector.version from the same
			// repo version.json. If it did not reach the version we just observed,
			// do not silently launch an outdated build.
			if installedVer == "" {
				return Response{OK: false, Installed: true, LatestVersion: latestVer, Updated: true, Error: "update completed but installed version marker is missing"}
			}
			if compareVersions(installedVer, latestVer) < 0 {
				return Response{OK: false, Installed: true, InstalledVersion: installedVer, LatestVersion: latestVer, Updated: true, Error: "update did not reach repo latest version"}
			}
		}
	}

	if !exists {
		return Response{OK: false, Installed: false, InstalledVersion: installedVer, LatestVersion: latestVer, Error: "Edge Connector is not installed"}
	}

	// Reuse an already-running current instance when possible. If an update ran,
	// the official installer already stopped the old process before replacement.
	if url, port := waitRunningURL(700 * time.Millisecond); url != "" {
		return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
	}

	exe = connectorPath()
	cmd := exec.Command(exe)
	cmd.Env = append(os.Environ(), "PROXYSG_NO_BROWSER=1")
	cmd.Dir = filepath.Dir(exe)
	if err := cmd.Start(); err != nil {
		return Response{OK: false, Installed: true, InstalledVersion: installedVer, LatestVersion: latestVer, Updated: updated, Error: "launch failed", Detail: err.Error()}
	}

	pid := cmd.Process.Pid
	_ = cmd.Process.Release()

	deadline := time.Now().Add(12 * time.Second)
	for time.Now().Before(deadline) {
		if url, port := findURLForPID(pid); url != "" {
			return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
		}
		if url, port := findRunningURL(); url != "" {
			return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
		}
		time.Sleep(250 * time.Millisecond)
	}

	return Response{OK: false, Installed: true, Launched: true, Updated: updated, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning, Error: "local HTTP listener was not detected within 12 seconds"}
}

func fetchLatestVersion() (string, error) {
	client := &http.Client{Timeout: 10 * time.Second}
	url := versionURL + "?cb=" + strconv.FormatInt(time.Now().UnixMilli(), 10)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Cache-Control", "no-cache, no-store, max-age=0")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("User-Agent", "EdgeConnectorNativeHost/"+hostVersion)

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("version.json HTTP %d", resp.StatusCode)
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, 64*1024))
	if err != nil {
		return "", err
	}

	var obj map[string]interface{}
	if err := json.Unmarshal(body, &obj); err != nil {
		return "", fmt.Errorf("version.json parse failed: %w", err)
	}
	for _, key := range []string{"edgeConnectorVersion", "version", "latestVersion"} {
		if raw, ok := obj[key]; ok {
			v := normalizeVersion(fmt.Sprint(raw))
			if v != "" {
				return v, nil
			}
		}
	}
	return "", fmt.Errorf("version.json has no supported version field")
}

func installedVersion() string {
	marker := filepath.Join(connectorDir(), "edge-connector.version")
	if b, err := os.ReadFile(marker); err == nil {
		if v := normalizeVersion(string(b)); v != "" {
			return v
		}
	}

	versionFile := filepath.Join(connectorDir(), "version.json")
	if b, err := os.ReadFile(versionFile); err == nil {
		var obj map[string]interface{}
		if json.Unmarshal(b, &obj) == nil {
			for _, key := range []string{"edgeConnectorVersion", "version", "latestVersion"} {
				if raw, ok := obj[key]; ok {
					if v := normalizeVersion(fmt.Sprint(raw)); v != "" {
						return v
					}
				}
			}
		}
	}
	return ""
}

func normalizeVersion(s string) string {
	s = strings.TrimSpace(s)
	if strings.HasPrefix(strings.ToLower(s), "v") {
		s = strings.TrimSpace(s[1:])
	}
	if s == "" {
		return ""
	}
	var parts []string
	var cur strings.Builder
	flush := func() {
		if cur.Len() > 0 {
			parts = append(parts, cur.String())
			cur.Reset()
		}
	}
	for _, r := range s {
		switch {
		case r >= '0' && r <= '9':
			cur.WriteRune(r)
		case r == '.':
			flush()
		default:
			flush()
			if len(parts) > 0 {
				return strings.Join(parts, ".")
			}
		}
	}
	flush()
	if len(parts) == 0 {
		return ""
	}
	return strings.Join(parts, ".")
}

func compareVersions(a, b string) int {
	pa := versionParts(a)
	pb := versionParts(b)
	n := len(pa)
	if len(pb) > n {
		n = len(pb)
	}
	for i := 0; i < n; i++ {
		av, bv := 0, 0
		if i < len(pa) {
			av = pa[i]
		}
		if i < len(pb) {
			bv = pb[i]
		}
		if av < bv {
			return -1
		}
		if av > bv {
			return 1
		}
	}
	return 0
}

func versionParts(s string) []int {
	s = normalizeVersion(s)
	if s == "" {
		return nil
	}
	fields := strings.Split(s, ".")
	out := make([]int, 0, len(fields))
	for _, f := range fields {
		n, err := strconv.Atoi(f)
		if err == nil {
			out = append(out, n)
		}
	}
	return out
}

func installConnector() error {
	client := &http.Client{Timeout: 30 * time.Second}
	url := installerURL + "?cb=" + strconv.FormatInt(time.Now().UnixMilli(), 10)
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Cache-Control", "no-cache, no-store, max-age=0")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("User-Agent", "EdgeConnectorNativeHost/"+hostVersion)
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("installer download HTTP %d", resp.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 4*1024*1024))
	if err != nil {
		return err
	}
	if len(body) < 100 {
		return fmt.Errorf("installer response too small")
	}

	dir := filepath.Join(os.TempDir(), "EdgeConnectorNativeHost")
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	path := filepath.Join(dir, "Install_Edge_Connector.cmd")
	if err := os.WriteFile(path, body, 0600); err != nil {
		return err
	}

	// Chrome starts the Native Messaging Host with the user's normal token.
	// An existing Edge Connector may have been started by an elevated installer,
	// in which case a normal-token taskkill cannot terminate it. Run the entire
	// stop/replace sequence through a UAC-elevated PowerShell helper.
	if err := runInstallerElevated(path, dir); err != nil {
		return err
	}
	if _, err := os.Stat(connectorPath()); err != nil {
		return fmt.Errorf("installer completed but Edge_Connector.exe was not found")
	}
	return nil
}

func psLiteral(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "''") + "'"
}

func runInstallerElevated(installerPath, workDir string) error {
	psPath := filepath.Join(workDir, "Update_Edge_Connector_Elevated.ps1")
	resultPath := filepath.Join(workDir, "update-result.txt")
	stdoutPath := filepath.Join(workDir, "installer-stdout.log")
	stderrPath := filepath.Join(workDir, "installer-stderr.log")

	_ = os.Remove(resultPath)
	_ = os.Remove(stdoutPath)
	_ = os.Remove(stderrPath)

	script := `$ErrorActionPreference = 'Stop'
$installer = ` + psLiteral(installerPath) + `
$workDir = ` + psLiteral(workDir) + `
$connectorDir = ` + psLiteral(connectorDir()) + `
$resultFile = ` + psLiteral(resultPath) + `
$stdoutFile = ` + psLiteral(stdoutPath) + `
$stderrFile = ` + psLiteral(stderrPath) + `

function Save-Result([string]$Text) {
  try { Set-Content -LiteralPath $resultFile -Value $Text -Encoding UTF8 -Force } catch {}
}

function Get-EdgeProcesses {
  $prefix = $connectorDir.TrimEnd('\\') + '\\'
  @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -ieq 'Edge_Connector.exe' -or
    $_.Name -ieq 'ProxySG_Policy_Trace_Editor.exe' -or
    ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase))
  })
}

function Stop-EdgeConnector {
  # Do not call taskkill by image name unconditionally. When no matching process
  # exists, taskkill writes an error that can become terminating under
  # $ErrorActionPreference='Stop'. Instead, enumerate existing processes first
  # and terminate only the PIDs that actually exist.
  $deadline = (Get-Date).AddSeconds(20)
  do {
    $left = @(Get-EdgeProcesses)
    if ($left.Count -eq 0) {
      Start-Sleep -Milliseconds 1200
      return
    }
    foreach ($p in $left) {
      try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop } catch {}
      try { & taskkill.exe /F /T /PID $p.ProcessId 2>$null | Out-Null } catch {}
    }
    Start-Sleep -Milliseconds 300
  } while ((Get-Date) -lt $deadline)

  $left = @(Get-EdgeProcesses)
  if ($left.Count -gt 0) {
    $desc = ($left | ForEach-Object { $_.Name + ' PID ' + $_.ProcessId }) -join ', '
    throw ('elevated stop failed; process still running: ' + $desc)
  }
}

try {
  $last = ''
  for ($attempt = 1; $attempt -le 3; $attempt++) {
    try {
      Stop-EdgeConnector
      Remove-Item -LiteralPath $stdoutFile,$stderrFile -Force -ErrorAction SilentlyContinue
      $quotedInstaller = '"' + $installer + '"'
      $p = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d','/c',$quotedInstaller) -WorkingDirectory $workDir -Wait -PassThru -RedirectStandardOutput $stdoutFile -RedirectStandardError $stderrFile
      if ($p.ExitCode -eq 0 -and (Test-Path -LiteralPath (Join-Path $connectorDir 'Edge_Connector.exe'))) {
        Save-Result ('OK attempt=' + $attempt)
        exit 0
      }
      $last = 'installer exit=' + $p.ExitCode + ' attempt=' + $attempt
    } catch {
      $last = $_.Exception.Message
    }
    Start-Sleep -Milliseconds (800 * $attempt)
  }

  $tail = @()
  foreach ($f in @($stdoutFile,$stderrFile)) {
    if (Test-Path -LiteralPath $f) {
      $tail += Get-Content -LiteralPath $f -Tail 12 -ErrorAction SilentlyContinue
    }
  }
  Save-Result (($last + ' | ' + (($tail -join ' | ') -replace '\\s+',' ')).Trim())
  exit 31
} catch {
  Save-Result ('elevated updater exception: ' + $_.Exception.Message)
  exit 32
}
`

	if err := os.WriteFile(psPath, []byte(script), 0600); err != nil {
		return err
	}

	command := "$p=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File'," + psLiteral(psPath) + ") -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
	c := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command)
	outer, err := c.CombinedOutput()

	result := ""
	if b, readErr := os.ReadFile(resultPath); readErr == nil {
		result = strings.TrimSpace(string(b))
	}
	if err != nil {
		outerText := strings.TrimSpace(string(outer))
		if len(outerText) > 500 {
			outerText = outerText[len(outerText)-500:]
		}
		if result == "" {
			result = outerText
		}
		if result == "" {
			result = "UAC was cancelled or elevated updater failed"
		}
		return fmt.Errorf("elevated update failed: %s", result)
	}
	if !strings.HasPrefix(result, "OK") {
		if result == "" {
			result = "elevated updater returned success without result marker"
		}
		return fmt.Errorf("elevated update failed: %s", result)
	}
	return nil
}

func stopConnectorProcesses() error {
	names := []string{"Edge_Connector.exe", "ProxySG_Policy_Trace_Editor.exe"}

	// First terminate by image name, including process trees.
	for _, name := range names {
		_, _ = exec.Command("taskkill.exe", "/F", "/T", "/IM", name).CombinedOutput()
	}

	// Then terminate any executable running from the EdgeConnector install
	// directory, even if its file name changes in a future release.
	dirPrefix := strings.TrimRight(connectorDir(), "\\/") + "\\"
	dir := strings.ReplaceAll(dirPrefix, "'", "''")
	ps := "$dir='" + dir + "'; " +
		"Get-CimInstance Win32_Process | Where-Object { " +
		"$_.ExecutablePath -and $_.ExecutablePath.StartsWith($dir,[System.StringComparison]::OrdinalIgnoreCase) " +
		"} | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
	_, _ = exec.Command(
		"powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
		"-Command", ps,
	).CombinedOutput()

	deadline := time.Now().Add(8 * time.Second)
	for time.Now().Before(deadline) {
		running := false
		for _, name := range names {
			if len(processPIDs(name)) > 0 {
				running = true
				break
			}
		}
		if !running {
			// A short grace period prevents replacing the executable while
			// Windows/endpoint security is still releasing the final handle.
			time.Sleep(900 * time.Millisecond)
			return nil
		}
		time.Sleep(200 * time.Millisecond)
	}

	var still []string
	for _, name := range names {
		for _, pid := range processPIDs(name) {
			still = append(still, fmt.Sprintf("%s PID %d", name, pid))
		}
	}
	if len(still) == 0 {
		return nil
	}
	return fmt.Errorf("process still running: %s", strings.Join(still, ", "))
}

func summarizeInstallerOutput(text string) string {
	lines := strings.Split(strings.ReplaceAll(text, "\r", ""), "\n")
	var keep []string

	for _, raw := range lines {
		line := strings.TrimSpace(raw)
		if line == "" {
			continue
		}

		lower := strings.ToLower(line)
		// Drop curl's transfer progress table. Keep installer step and error
		// messages so the extension UI shows a useful diagnosis.
		if strings.Contains(lower, "% total") ||
			strings.Contains(lower, "dload  upload") ||
			strings.Contains(lower, "xferd") ||
			(strings.HasPrefix(line, "0 ") && len(strings.Fields(line)) >= 8) ||
			(strings.HasPrefix(line, "100 ") && len(strings.Fields(line)) >= 8) {
			continue
		}

		keep = append(keep, line)
	}

	if len(keep) > 18 {
		keep = keep[len(keep)-18:]
	}
	out := strings.Join(keep, " | ")
	if len(out) > 1400 {
		out = out[len(out)-1400:]
	}
	return out
}

func waitRunningURL(d time.Duration) (string, int) {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		if url, port := findRunningURL(); url != "" {
			return url, port
		}
		time.Sleep(120 * time.Millisecond)
	}
	return "", 0
}

func findRunningURL() (string, int) {
	pids := append(processPIDs("Edge_Connector.exe"), processPIDs("ProxySG_Policy_Trace_Editor.exe")...)
	for _, pid := range pids {
		if url, port := findURLForPID(pid); url != "" {
			return url, port
		}
	}
	return "", 0
}

func processPIDs(image string) []int {
	out, err := exec.Command("tasklist.exe", "/FI", "IMAGENAME eq "+image, "/FO", "CSV", "/NH").Output()
	if err != nil {
		return nil
	}
	r := csv.NewReader(strings.NewReader(string(out)))
	var pids []int
	for {
		row, err := r.Read()
		if err != nil {
			break
		}
		if len(row) < 2 || strings.HasPrefix(strings.TrimSpace(row[0]), "INFO:") {
			continue
		}
		pid, err := strconv.Atoi(strings.TrimSpace(row[1]))
		if err == nil {
			pids = append(pids, pid)
		}
	}
	return pids
}

func findURLForPID(pid int) (string, int) {
	out, err := exec.Command("netstat.exe", "-ano", "-p", "tcp").Output()
	if err != nil {
		return "", 0
	}
	want := strconv.Itoa(pid)
	lines := strings.Split(string(out), "\n")
	for _, line := range lines {
		fields := strings.Fields(line)
		if len(fields) < 5 {
			continue
		}
		if !strings.EqualFold(fields[0], "TCP") || !strings.EqualFold(fields[3], "LISTENING") || fields[4] != want {
			continue
		}
		local := fields[1]
		if !strings.HasPrefix(local, "127.0.0.1:") {
			continue
		}
		idx := strings.LastIndex(local, ":")
		if idx < 0 {
			continue
		}
		port, err := strconv.Atoi(local[idx+1:])
		if err != nil || port <= 0 {
			continue
		}
		url := fmt.Sprintf("http://127.0.0.1:%d/", port)
		if looksHTTP(url) {
			return url, port
		}
	}
	return "", 0
}

func looksHTTP(url string) bool {
	client := &http.Client{Timeout: 700 * time.Millisecond}
	resp, err := client.Get(url)
	if err != nil {
		return false
	}
	io.Copy(io.Discard, io.LimitReader(resp.Body, 1024))
	resp.Body.Close()
	return true
}
