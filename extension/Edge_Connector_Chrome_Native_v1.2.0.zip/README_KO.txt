Edge Connector Chrome Native v1.2.0

v1.2.0 핵심 변경 - 보안 제품(Symantec SEP 등) 차단 대응
------------------------------------------------------------
이전 버전은 업데이트 시 Chrome -> Native Host -> PowerShell(UAC) -> cmd -> curl/tar/certutil 순서로
프로세스를 연쇄 실행하고 taskkill/tasklist/netstat을 반복 호출했습니다. 이 패턴은 행위 기반 탐지
(SONAR AGR.Terminate!g2, SONAR.PSDownloader!g2)에서 다운로더/드로퍼와 유사하게 판정되어
cmd.exe / powershell.exe / Native Host가 차단되고 Edge_Connector.exe가 격리되었습니다.

v1.2.0에서는:
- PowerShell, cmd.exe, curl, tar, certutil, taskkill, tasklist, netstat을 실행하지 않습니다.
- UAC(관리자 권한) 요청과 -ExecutionPolicy Bypass를 사용하지 않습니다.
- 다운로드 / SHA-256 검증 / ZIP 해제 / 프로세스 종료 / 파일 교체 / 포트 탐지를 Host 내부에서 처리합니다.
- ZIP SHA-256(.sha256)과 exe SHA-256(version.json)을 모두 검증합니다.
- 실패 시 기존 Edge_Connector.exe를 보존합니다 (교체는 이름 변경 방식, 실패하면 복원).
- 버전 마커(edge-connector.version)를 Host가 직접 BOM 없이 기록합니다.
- exe에 버전 정보와 asInvoker 매니페스트를 포함합니다.
- 로그: %LOCALAPPDATA%\Etech\EdgeConnectorChrome\native\host.log

관리자 권한으로 실행 중인 Edge Connector가 남아 있으면 Host가 종료할 수 없으므로
"Close it manually" 안내가 표시됩니다. 작업 관리자에서 종료한 뒤 다시 실행하세요.

보안 제품 예외 등록 (SEP 관리자에게 요청)
------------------------------------------------------------
- %LOCALAPPDATA%\Etech\EdgeConnectorChrome\native\EdgeConnectorNativeHost.exe
- %LOCALAPPDATA%\Etech\EdgeConnector\Edge_Connector.exe
두 파일 모두 코드 서명이 없으면 평판 기반 탐지에 계속 걸릴 수 있습니다. 서명을 권장합니다.

Chrome Extension ID:
afpojmpdnpchpnomphpphmhbdehpbenl

Native Host:
com.etech.edgeconnector

Native Host SHA-256:
3DF12B8AB74C4E67B4A76C9C79C59E406C99382ABF8403A80687E8BCFCD705F8

설치 / 업그레이드
------------------------------------------------------------
1. Install_Edge_Connector_Chrome_Native_v1.2.0.cmd 실행
2. chrome://extensions 에서 ProxySG Edge Connector 새로고침
3. 확장 아이콘 클릭
