@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Edge Connector Chrome Extension + Native Host v1.2.0

set "EXT_ID=afpojmpdnpchpnomphpphmhbdehpbenl"
set "HOST_NAME=com.etech.edgeconnector"
set "EXT_DIR=%ProgramData%\Etech\EdgeConnectorChrome\unpacked"
set "NATIVE_DIR=%LOCALAPPDATA%\Etech\EdgeConnectorChrome\native"
set "NATIVE_EXE=%NATIVE_DIR%\EdgeConnectorNativeHost.exe"
set "HOST_MANIFEST=%NATIVE_DIR%\com.etech.edgeconnector.json"
set "SOURCE_EXT=%~dp0extension"
set "SOURCE_NATIVE=%~dp0native\EdgeConnectorNativeHost.exe"
set "EXPECTED_HOST_SHA=3DF12B8AB74C4E67B4A76C9C79C59E406C99382ABF8403A80687E8BCFCD705F8"

net session >nul 2>&1
if not "%errorlevel%"=="0" (
  echo Requesting administrator privileges...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
    "Start-Process -FilePath $env:ComSpec -ArgumentList '/d','/c','\"%~f0\"' -Verb RunAs"
  exit /b
)

echo.
echo ============================================================
echo  Edge Connector Chrome Extension + Native Host v1.2.0
echo ============================================================
echo.

if not exist "%SOURCE_EXT%\manifest.json" (
  echo [ERROR] extension\manifest.json not found.
  goto :FAIL
)
if not exist "%SOURCE_NATIVE%" (
  echo [ERROR] native\EdgeConnectorNativeHost.exe not found.
  goto :FAIL
)

echo [1/6] Installing Chrome extension files...
if exist "%EXT_DIR%" rmdir /s /q "%EXT_DIR%"
mkdir "%EXT_DIR%" >nul 2>&1
xcopy "%SOURCE_EXT%\*" "%EXT_DIR%\" /E /I /H /Y >nul
if errorlevel 1 goto :FAIL

echo [2/6] Installing Native Messaging Host...
if not exist "%NATIVE_DIR%" mkdir "%NATIVE_DIR%" >nul 2>&1
copy /y "%SOURCE_NATIVE%" "%NATIVE_EXE%" >nul
if errorlevel 1 goto :FAIL

echo [3/6] Verifying Native Host...
set "ACTUAL_HOST_SHA="
for /f "usebackq delims=" %%H in (`powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%NATIVE_EXE%').Hash"`) do set "ACTUAL_HOST_SHA=%%H"
if /I not "%ACTUAL_HOST_SHA%"=="%EXPECTED_HOST_SHA%" (
  echo [ERROR] Native Host SHA-256 mismatch.
  echo EXPECTED: %EXPECTED_HOST_SHA%
  echo ACTUAL  : %ACTUAL_HOST_SHA%
  goto :FAIL
)

echo [4/6] Creating Native Messaging manifest...
set "NATIVE_EXE_JSON=%NATIVE_EXE:\=\\%"
> "%HOST_MANIFEST%" echo {
>>"%HOST_MANIFEST%" echo   "name": "%HOST_NAME%",
>>"%HOST_MANIFEST%" echo   "description": "ProxySG Edge Connector Native Host",
>>"%HOST_MANIFEST%" echo   "path": "%NATIVE_EXE_JSON%",
>>"%HOST_MANIFEST%" echo   "type": "stdio",
>>"%HOST_MANIFEST%" echo   "allowed_origins": [
>>"%HOST_MANIFEST%" echo     "chrome-extension://%EXT_ID%/"
>>"%HOST_MANIFEST%" echo   ]
>>"%HOST_MANIFEST%" echo }

echo [5/6] Registering Native Messaging Host...
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\%HOST_NAME%" /ve /t REG_SZ /d "%HOST_MANIFEST%" /f >nul 2>&1
if errorlevel 1 goto :FAIL

echo [6/6] Opening Chrome extension manager...
echo %EXT_DIR%| clip

set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if defined CHROME (
  start "" "%CHROME%" "chrome://extensions/"
) else (
  start "" "chrome://extensions/" >nul 2>&1
)

echo.
echo ============================================================
echo  Installation completed.
echo ============================================================
echo.
echo Extension path:
echo   %EXT_DIR%
echo.
echo Existing extension users:
echo   - Click Reload on ProxySG Edge Connector in chrome://extensions.
echo   - Or fully close and reopen Chrome.
echo.
echo Every extension launch now does this:
echo   1. Read local Edge Connector version.
echo   2. Fetch repo downloads/version.json with no-cache.
echo   3. If local is older, download and SHA-256 verify the latest ZIP inside the host.
echo   4. Replace Edge_Connector.exe and write edge-connector.version.
echo   5. Start Edge Connector and detect its real localhost port.
echo   6. Open the exact local URL.
echo.
echo No PowerShell, cmd.exe or UAC prompt is used at run time.
echo Log: %NATIVE_DIR%\host.log
echo.
echo If endpoint protection (e.g. Symantec SEP) blocks or quarantines files,
echo ask your administrator to add exceptions for:
echo   %NATIVE_EXE%
echo   %LOCALAPPDATA%\Etech\EdgeConnector\Edge_Connector.exe
echo.
echo.
pause
exit /b 0

:FAIL
echo.
echo [ERROR] Installation failed.
pause
exit /b 1
