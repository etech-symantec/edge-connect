(() => {
  const HOST="com.etech.edgeconnector";
  const statusEl=document.getElementById('status');
  const titleEl=document.getElementById('title');
  const leadEl=document.getElementById('lead');
  const retryBtn=document.getElementById('retryBtn');

  function setStatus(text,type=''){
    statusEl.textContent=text;
    statusEl.className='status'+(type?' '+type:'');
  }

  function nativeMessage(message){
    return new Promise((resolve,reject)=>{
      chrome.runtime.sendNativeMessage(HOST,message,response=>{
        if(chrome.runtime.lastError){
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(response);
      });
    });
  }

  async function run(){
    retryBtn.hidden=true;
    titleEl.textContent='Edge Connector 확인 중';
    leadEl.textContent='설치 버전과 repo 최신 버전을 확인하고 있습니다.';
    setStatus('Native Host 연결 중... 최신 버전이 있으면 자동으로 업데이트합니다. (관리자 권한 불필요)');

    try{
      const before=await nativeMessage({cmd:'status'});
      const beforeVersion=before?.installedVersion || '';

      if(before?.installed){
        setStatus(beforeVersion
          ? `설치 버전 ${beforeVersion} · Repo 최신 버전 확인 중...`
          : 'Edge Connector가 설치되어 있습니다. Repo 최신 버전 확인 중...','install');
      }else{
        titleEl.textContent='Edge Connector 자동 설치';
        leadEl.textContent='설치된 Edge Connector가 없어 repo 최신 버전을 자동으로 설치합니다.';
        setStatus('Repo 최신 버전 확인 및 설치 중입니다.','install');
      }

      const result=await nativeMessage({cmd:'ensure'});
      if(!result?.ok){
        const versions=[
          result?.installedVersion ? `설치 ${result.installedVersion}` : '',
          result?.latestVersion ? `Repo 최신 ${result.latestVersion}` : ''
        ].filter(Boolean).join(' / ');
        const core=result?.error || 'Edge Connector 실행에 실패했습니다.';
        const detail=String(result?.detail || '').replace(/\s+/g,' ').trim();
        throw new Error((versions ? versions+' · ' : '') + core + (detail ? ` · ${detail}` : ''));
      }
      if(!result.url){
        throw new Error('Edge Connector는 실행되었지만 로컬 HTTP 포트를 확인하지 못했습니다.');
      }

      chrome.runtime.sendMessage({
        type:'edgeConnectorSetState',
        state:'installed',
        version:result.installedVersion || result.latestVersion || ''
      },()=>void chrome.runtime.lastError);

      if(result.updated){
        titleEl.textContent='Edge Connector 업데이트 완료';
        if(beforeVersion && result.installedVersion && beforeVersion!==result.installedVersion){
          leadEl.textContent=`${beforeVersion} → ${result.installedVersion} 업데이트 후 실행했습니다.`;
        }else{
          leadEl.textContent=`Repo 최신 버전 ${result.installedVersion || result.latestVersion || ''} 설치 후 실행했습니다.`;
        }
      }else{
        titleEl.textContent='Edge Connector 연결 완료';
        if(result.latestVersion && result.installedVersion){
          leadEl.textContent=`설치 ${result.installedVersion} / Repo 최신 ${result.latestVersion} · 최신 상태입니다.`;
        }else{
          leadEl.textContent=`실제 로컬 포트 ${result.port}가 확인되었습니다.`;
        }
      }

      if(result.warning){
        setStatus(`${result.warning} · ${result.url} 로 이동합니다.`, 'install');
      }else{
        setStatus(`${result.url} 로 이동합니다.`, 'ok');
      }

      setTimeout(()=>location.replace(result.url), result.warning ? 1100 : 500);
    }catch(err){
      titleEl.textContent='Edge Connector 연결 실패';
      leadEl.textContent='Repo 버전 확인, 업데이트 또는 로컬 서비스 실행 상태를 확인해주세요.';
      let msg=String(err?.message || err || '알 수 없는 오류').replace(/\s+/g,' ').trim();
      if(msg.length>900) msg=msg.slice(0,900)+'…';
      const hint=msg.includes('native messaging host')
        ? ' Native Host가 등록되지 않았습니다. v1.1.10 설치 CMD를 다시 실행한 뒤 Chrome을 재시작해주세요.'
        : '';
      setStatus(msg + hint,'error');
      retryBtn.hidden=false;
    }
  }

  retryBtn.addEventListener('click',run);
  run();
})();
