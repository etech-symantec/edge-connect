# ProxySG Edge Connector - Chrome Extension v1.1.0

## 구성
이 확장 프로그램은 기존 Edge Connector 웹 UI를 Chrome Manifest V3 확장 프로그램으로 패키징한 버전입니다.

포함된 기능:
- Edge Connector 설치 / 실행 / 최신 버전 확인 / 삭제
- Local Admin 작업 안내
- Trace 정책 설정
- LIVE Trace / Access Log 조회 흐름
- 세션 분석
- MIB / SNMP 조회
- Sysinfo 확인
- Exception Page 편집
- 한국어 / English 전환
- 2단계 이후 Trace 하위 단계 펼치기 / 접기
- 기존 GitHub Pages 설치/삭제 콜백과 확장 프로그램 설치 상태 동기화

## 중요
Chrome 확장 프로그램 자체가 ProxySG에 SSH 접속하는 구조가 아닙니다.
실제 장비 통신은 Windows에 설치되는 Edge Connector가 수행합니다.

확장 프로그램은 다음 역할을 합니다.
1. Edge Connector 설치 파일 다운로드
2. `edge-connector://run` 프로토콜을 통한 로컬 Edge Connector 실행
3. Repo 최신 버전 확인
4. 설치 / 삭제 콜백 상태 동기화
5. 기능별 사용 절차 표시

## 설치 방법
1. 이 ZIP을 원하는 폴더에 압축 해제합니다.
2. Chrome 주소창에서 `chrome://extensions`를 엽니다.
3. 우측 상단 `개발자 모드`를 켭니다.
4. `압축해제된 확장 프로그램을 로드합니다`를 누릅니다.
5. 압축을 푼 `Edge_Connector_Chrome_Extension_v1.0.0` 폴더를 선택합니다.
6. Chrome 툴바에서 `ProxySG Edge Connector`를 고정합니다.
7. 아이콘을 누르면 Edge Connector가 새 탭으로 열립니다.

## 처음 사용하는 PC
`Edge Connector 설치` 버튼을 누르면 Install_Edge_Connector.cmd가 다운로드됩니다.
CMD를 한 번 실행하면 Windows에 Edge Connector와 `edge-connector://run` 프로토콜이 등록됩니다.

Chrome에서 외부 애플리케이션 실행 확인 창이 나타나면 Edge Connector 실행을 허용합니다.

## 설치 상태 동기화
기존 설치 CMD / 삭제 CMD는 완료 후
`https://etech-symantec.github.io/edge-connect/`
페이지를 다시 엽니다.

이 확장 프로그램은 해당 페이지에만 동작하는 content script를 사용해
`connector=installed` / `connector=uninstalled` 콜백과 버전 정보를 받아
Chrome storage에 저장합니다.

## 권한
- `storage`: Edge Connector 설치 상태 / 버전 저장
- `downloads`: 설치 및 삭제 CMD 다운로드
- `https://etech-symantec.github.io/edge-connect/*`: 버전 조회 및 설치 상태 콜백 동기화

다른 사이트에 대한 접근 권한은 요청하지 않습니다.


## v1.1.0 최초 설치 자동화

확장 프로그램을 처음 설치하면:
1. `Install_And_Run_Edge_Connector.cmd`를 자동으로 다운로드합니다.
2. 최초 설정 탭이 자동으로 열립니다.
3. 사용자는 `설치 및 실행`을 한 번만 누릅니다.
4. bootstrap이 GitHub Pages에서 최신 `Install_Edge_Connector.cmd`를 가져옵니다.
5. 기존 공식 설치 로직을 그대로 실행합니다.
6. 설치가 끝나면 `edge-connector://run`을 호출해 Edge Connector를 자동 실행합니다.

Chrome 보안 정책 때문에 3번의 사용자 클릭은 제거할 수 없습니다.
사내 관리 PC에서 완전 무인 설치가 필요하면 Chrome Extension force-install + Edge Connector 선배포(GPO/Intune/SCCM) 구조를 사용해야 합니다.


## v1.1.5 변경사항

최초 설정 페이지가 Chrome 내부에서 CMD를 다시 다운로드하던 구조를 제거했습니다.
이제 Windows 설치기에서 다음을 먼저 처리합니다.

1. 이미지 없는 Chrome 확장 파일 설치
2. 내장된 `Install_And_Run_Edge_Connector.cmd` 직접 실행
3. 최신 Edge Connector 설치
4. Edge Connector 자동 실행
5. Chrome 확장 폴더 경로 클립보드 복사
6. `chrome://extensions` 자동 오픈
7. 사용자가 최초 1회 `압축해제된 확장 프로그램을 로드합니다` 수행
8. 확장 로드 즉시 메인 Edge Connector UI 오픈

따라서 확장 프로그램 내부에서는 `Install_And_Run_Edge_Connector.cmd` 다운로드를 더 이상 시도하지 않습니다.


## v1.1.7 - Native Messaging 방식

이 버전부터 `http://127.0.0.1/` 고정 포트 확인을 사용하지 않습니다.

확장 프로그램 실행 흐름:
1. Native Messaging Host에 상태 확인 요청
2. `%LOCALAPPDATA%\Etech\EdgeConnector\Edge_Connector.exe` 존재 여부 확인
3. 없으면 최신 `Install_Edge_Connector.cmd` 자동 다운로드 및 실행
4. Edge Connector를 `PROXYSG_NO_BROWSER=1` 환경으로 실행
5. 실제 Edge Connector 프로세스 PID의 TCP LISTEN 포트 확인
6. 실제 `http://127.0.0.1:<포트>/` URL 반환
7. Chrome이 해당 URL로 자동 이동

Native Host name:
`com.etech.edgeconnector`


## v1.1.8 자동 최신화

확장 프로그램 실행 시 Native Host가 매번 `downloads/version.json`을 `no-cache`로 확인합니다.

- 로컬 버전 < repo 최신 버전: 공식 `Install_Edge_Connector.cmd`를 다시 실행하여 업데이트 후 실행
- 로컬 버전 = repo 최신 버전: 설치 없이 즉시 실행
- 버전 마커 없음: 최신 버전으로 재설치하여 버전 상태 복구
- repo 버전 확인 실패 + 기존 설치 존재: 경고를 남기고 기존 버전 실행

비교 대상 로컬 파일:
`%LOCALAPPDATA%\Etech\EdgeConnector\edge-connector.version`

Repo 버전:
`https://etech-symantec.github.io/edge-connect/downloads/version.json`

## v1.2.0 - Native Host 재설계 (보안 제품 오탐/차단 대응)
- Native Host가 더 이상 PowerShell / cmd.exe / curl / tar / certutil / taskkill / tasklist / netstat을 실행하지 않습니다.
- UAC(관리자 권한) 요청과 `-ExecutionPolicy Bypass` 사용을 제거했습니다.
- 다운로드, SHA-256 검증, ZIP 해제, 프로세스 종료, 파일 교체, 포트 탐지를 Host 내부(Go/Win32 API)에서 처리합니다.
- 업데이트 로그: `%LOCALAPPDATA%\Etech\EdgeConnectorChrome\native\host.log`

