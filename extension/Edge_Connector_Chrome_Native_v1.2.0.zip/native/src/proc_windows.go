//go:build windows

package main

import (
	"encoding/binary"
	"strings"
	"syscall"
	"unsafe"
)

const (
	processQueryLimitedInformation = 0x1000
	errorInsufficientBuffer        = 122
	afINET                         = 2
	tcpTableOwnerPIDListener       = 3
)

var (
	modKernel32                 = syscall.NewLazyDLL("kernel32.dll")
	procQueryFullProcessImageNW = modKernel32.NewProc("QueryFullProcessImageNameW")
	modIphlpapi                 = syscall.NewLazyDLL("iphlpapi.dll")
	procGetExtendedTCPTable     = modIphlpapi.NewProc("GetExtendedTcpTable")
)

// processPIDs lists PIDs whose executable name equals image (case-insensitive)
// using a Toolhelp snapshot; no child process is started.
func processPIDs(image string) []int {
	snap, err := syscall.CreateToolhelp32Snapshot(syscall.TH32CS_SNAPPROCESS, 0)
	if err != nil {
		return nil
	}
	defer syscall.CloseHandle(snap)
	var pe syscall.ProcessEntry32
	pe.Size = uint32(unsafe.Sizeof(pe))
	if err := syscall.Process32First(snap, &pe); err != nil {
		return nil
	}
	var pids []int
	for {
		if strings.EqualFold(syscall.UTF16ToString(pe.ExeFile[:]), image) {
			pids = append(pids, int(pe.ProcessID))
		}
		if err := syscall.Process32Next(snap, &pe); err != nil {
			break
		}
	}
	return pids
}

func processImagePath(pid int) string {
	h, err := syscall.OpenProcess(processQueryLimitedInformation, false, uint32(pid))
	if err != nil {
		return ""
	}
	defer syscall.CloseHandle(h)
	buf := make([]uint16, 1024)
	size := uint32(len(buf))
	r, _, _ := procQueryFullProcessImageNW.Call(uintptr(h), 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&size)))
	if r == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:size])
}

// terminatePID ends a process owned by the current user and waits briefly.
// Access denied (e.g. an elevated instance) is returned to the caller.
func terminatePID(pid int) error {
	h, err := syscall.OpenProcess(syscall.PROCESS_TERMINATE|syscall.SYNCHRONIZE, false, uint32(pid))
	if err != nil {
		if err == syscall.Errno(87) { // ERROR_INVALID_PARAMETER: already gone
			return nil
		}
		return err
	}
	defer syscall.CloseHandle(h)
	if err := syscall.TerminateProcess(h, 1); err != nil {
		return err
	}
	_, _ = syscall.WaitForSingleObject(h, 5000)
	return nil
}

// loopbackListenPorts returns TCP ports that pid listens on at 127.0.0.1,
// read from the kernel TCP table (replaces spawning netstat).
func loopbackListenPorts(pid int) []int {
	var size uint32
	var buf []byte
	for i := 0; i < 4; i++ {
		var p uintptr
		if len(buf) > 0 {
			p = uintptr(unsafe.Pointer(&buf[0]))
		}
		r, _, _ := procGetExtendedTCPTable.Call(p, uintptr(unsafe.Pointer(&size)), 0, afINET, tcpTableOwnerPIDListener, 0)
		if r == 0 {
			break
		}
		if r != errorInsufficientBuffer {
			return nil
		}
		buf = make([]byte, size)
	}
	if len(buf) < 4 {
		return nil
	}
	n := int(binary.LittleEndian.Uint32(buf[0:4]))
	var ports []int
	// MIB_TCPROW_OWNER_PID: state, localAddr, localPort, remoteAddr, remotePort, owningPid
	for i := 0; i < n; i++ {
		off := 4 + i*24
		if off+24 > len(buf) {
			break
		}
		addr := buf[off+4 : off+8]
		if addr[0] != 127 || addr[1] != 0 || addr[2] != 0 || addr[3] != 1 {
			continue
		}
		if int(binary.LittleEndian.Uint32(buf[off+20:off+24])) != pid {
			continue
		}
		ports = append(ports, int(binary.BigEndian.Uint16(buf[off+8:off+10])))
	}
	return ports
}
