//go:build !windows

package main

// Non-Windows stubs so the portable logic can be unit-tested on any OS.

func processPIDs(image string) []int    { return nil }
func processImagePath(pid int) string   { return "" }
func terminatePID(pid int) error        { return nil }
func loopbackListenPorts(pid int) []int { return nil }
