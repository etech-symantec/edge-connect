// Edge Connector Chrome Native Messaging Host.
//
// Design rule (since v1.2.0): this process never spawns PowerShell, cmd.exe,
// curl, tar, certutil, taskkill, tasklist or netstat, and never asks for UAC.
// Download, SHA-256 verification, ZIP extraction, process termination and port
// discovery are all done in-process with the Go standard library and Win32 APIs.
// Chrome-launched helpers that chain shells and kill processes look like a
// dropper to behavioural engines (e.g. Symantec SONAR AGR.Terminate / PSDownloader).
package main

import (
	"bufio"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

const hostVersion = "1.2.0"

// downloadsBase is a variable so tests can point it at an httptest server.
var downloadsBase = "https://etech-symantec.github.io/edge-connect/downloads"

type Request struct {
	Cmd string `json:"cmd"`
}

type Response struct {
	HostVersion      string `json:"hostVersion,omitempty"`
	OK               bool   `json:"ok"`
	Installed        bool   `json:"installed"`
	Launched         bool   `json:"launched"`
	Updated          bool   `json:"updated,omitempty"`
	URL              string `json:"url,omitempty"`
	Port             int    `json:"port,omitempty"`
	InstalledVersion string `json:"installedVersion,omitempty"`
	LatestVersion    string `json:"latestVersion,omitempty"`
	Warning          string `json:"warning,omitempty"`
	Error            string `json:"error,omitempty"`
	Detail           string `json:"detail,omitempty"`
}

func main() {
	in := bufio.NewReader(os.Stdin)
	for {
		var n uint32
		if err := binary.Read(in, binary.LittleEndian, &n); err != nil {
			if err == io.EOF {
				return
			}
			send(Response{OK: false, Error: "read length failed", Detail: err.Error()})
			return
		}
		if n == 0 || n > 1024*1024 {
			send(Response{OK: false, Error: "invalid message length"})
			return
		}
		buf := make([]byte, n)
		if _, err := io.ReadFull(in, buf); err != nil {
			send(Response{OK: false, Error: "read message failed", Detail: err.Error()})
			return
		}
		var req Request
		if err := json.Unmarshal(buf, &req); err != nil {
			send(Response{OK: false, Error: "invalid json", Detail: err.Error()})
			continue
		}
		logf("request cmd=%q", req.Cmd)
		switch req.Cmd {
		case "status":
			send(status())
		case "launch":
			send(launch(false))
		case "ensure", "":
			send(launch(true))
		default:
			send(Response{OK: false, Error: "unknown command"})
		}
	}
}

func send(v Response) {
	v.HostVersion = hostVersion
	if !v.OK {
		logf("response error=%q detail=%q", v.Error, v.Detail)
	}
	b, _ := json.Marshal(v)
	_ = binary.Write(os.Stdout, binary.LittleEndian, uint32(len(b)))
	_, _ = os.Stdout.Write(b)
}

func connectorDir() string {
	return filepath.Join(os.Getenv("LOCALAPPDATA"), "Etech", "EdgeConnector")
}

func connectorPath() string {
	return filepath.Join(connectorDir(), "Edge_Connector.exe")
}

func status() Response {
	exe := connectorPath()
	ver := installedVersion()
	if _, err := os.Stat(exe); err != nil {
		return Response{OK: true, Installed: false, InstalledVersion: ver}
	}
	if url, port := findRunningURL(); url != "" {
		return Response{OK: true, Installed: true, Launched: true, URL: url, Port: port, InstalledVersion: ver}
	}
	return Response{OK: true, Installed: true, InstalledVersion: ver}
}

func launch(installIfMissing bool) Response {
	exe := connectorPath()
	_, statErr := os.Stat(exe)
	exists := statErr == nil
	installedVer := installedVersion()

	// Every ensure/launch checks the repository first (no-cache) so a newly
	// published Edge Connector is picked up.
	meta, versionErr := fetchLatestMeta()
	latestVer := ""
	warning := ""
	updated := false
	if versionErr != nil {
		warning = "repo version check failed: " + versionErr.Error()
	} else {
		latestVer = meta.Version
	}

	needInstall := !exists
	if exists && versionErr == nil {
		needInstall = installedVer == "" || compareVersions(installedVer, latestVer) < 0
	}

	if needInstall {
		if !exists && !installIfMissing {
			return Response{OK: false, Installed: false, LatestVersion: latestVer, Error: "Edge Connector is not installed", Detail: warning}
		}
		v, err := installConnector(meta)
		if err != nil {
			return Response{OK: false, Installed: exists, InstalledVersion: installedVer, LatestVersion: latestVer, Error: "install/update failed", Detail: err.Error()}
		}
		exists = true
		updated = true
		installedVer = v
		if latestVer != "" && compareVersions(installedVer, latestVer) < 0 {
			return Response{OK: false, Installed: true, InstalledVersion: installedVer, LatestVersion: latestVer, Updated: true, Error: "update did not reach repo latest version"}
		}
	}

	if !exists {
		return Response{OK: false, Installed: false, InstalledVersion: installedVer, LatestVersion: latestVer, Error: "Edge Connector is not installed", Detail: warning}
	}

	// Reuse an already-running current instance when possible.
	if url, port := waitRunningURL(700 * time.Millisecond); url != "" {
		return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
	}

	cmd := exec.Command(exe)
	cmd.Env = append(os.Environ(), "PROXYSG_NO_BROWSER=1")
	cmd.Dir = filepath.Dir(exe)
	if err := cmd.Start(); err != nil {
		return Response{OK: false, Installed: true, InstalledVersion: installedVer, LatestVersion: latestVer, Updated: updated, Error: "launch failed", Detail: err.Error()}
	}
	pid := cmd.Process.Pid
	_ = cmd.Process.Release()

	deadline := time.Now().Add(12 * time.Second)
	for time.Now().Before(deadline) {
		if url, port := findURLForPID(pid); url != "" {
			return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
		}
		if url, port := findRunningURL(); url != "" {
			return Response{OK: true, Installed: true, Launched: true, Updated: updated, URL: url, Port: port, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning}
		}
		time.Sleep(400 * time.Millisecond)
	}
	return Response{OK: false, Installed: true, Launched: true, Updated: updated, InstalledVersion: installedVer, LatestVersion: latestVer, Warning: warning, Error: "local HTTP listener was not detected within 12 seconds"}
}

// ---------------------------------------------------------------- versions

func installedVersion() string {
	if b, err := os.ReadFile(filepath.Join(connectorDir(), "edge-connector.version")); err == nil {
		if v := normalizeVersion(strings.TrimPrefix(string(b), "\ufeff")); v != "" {
			return v
		}
	}
	if b, err := os.ReadFile(filepath.Join(connectorDir(), "version.json")); err == nil {
		var obj map[string]interface{}
		if json.Unmarshal(b, &obj) == nil {
			for _, key := range []string{"edgeConnectorVersion", "version", "latestVersion"} {
				if raw, ok := obj[key]; ok {
					if v := normalizeVersion(fmt.Sprint(raw)); v != "" {
						return v
					}
				}
			}
		}
	}
	return ""
}

func normalizeVersion(s string) string {
	s = strings.TrimSpace(strings.TrimPrefix(s, "\ufeff"))
	if strings.HasPrefix(strings.ToLower(s), "v") {
		s = strings.TrimSpace(s[1:])
	}
	if s == "" {
		return ""
	}
	var parts []string
	var cur strings.Builder
	flush := func() {
		if cur.Len() > 0 {
			parts = append(parts, cur.String())
			cur.Reset()
		}
	}
	for _, r := range s {
		switch {
		case r >= '0' && r <= '9':
			cur.WriteRune(r)
		case r == '.':
			flush()
		default:
			flush()
			if len(parts) > 0 {
				return strings.Join(parts, ".")
			}
		}
	}
	flush()
	return strings.Join(parts, ".")
}

func versionParts(s string) []int {
	s = normalizeVersion(s)
	if s == "" {
		return nil
	}
	var out []int
	for _, f := range strings.Split(s, ".") {
		if n, err := strconv.Atoi(f); err == nil {
			out = append(out, n)
		}
	}
	return out
}

func compareVersions(a, b string) int {
	pa, pb := versionParts(a), versionParts(b)
	n := len(pa)
	if len(pb) > n {
		n = len(pb)
	}
	for i := 0; i < n; i++ {
		av, bv := 0, 0
		if i < len(pa) {
			av = pa[i]
		}
		if i < len(pb) {
			bv = pb[i]
		}
		if av < bv {
			return -1
		}
		if av > bv {
			return 1
		}
	}
	return 0
}

// ---------------------------------------------------------- port discovery

func waitRunningURL(d time.Duration) (string, int) {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		if url, port := findRunningURL(); url != "" {
			return url, port
		}
		time.Sleep(150 * time.Millisecond)
	}
	return "", 0
}

func findRunningURL() (string, int) {
	pids := append(processPIDs("Edge_Connector.exe"), processPIDs("ProxySG_Policy_Trace_Editor.exe")...)
	for _, pid := range pids {
		if url, port := findURLForPID(pid); url != "" {
			return url, port
		}
	}
	return "", 0
}

func findURLForPID(pid int) (string, int) {
	for _, port := range loopbackListenPorts(pid) {
		url := fmt.Sprintf("http://127.0.0.1:%d/", port)
		if looksHTTP(url) {
			return url, port
		}
	}
	return "", 0
}

func looksHTTP(url string) bool {
	client := &http.Client{Timeout: 700 * time.Millisecond}
	resp, err := client.Get(url)
	if err != nil {
		return false
	}
	io.Copy(io.Discard, io.LimitReader(resp.Body, 1024))
	resp.Body.Close()
	return true
}

// ----------------------------------------------------------------- logging

// logf appends to a small log file. stdout is reserved for the native
// messaging protocol and must never be written to.
func logf(format string, a ...interface{}) {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		return
	}
	dir := filepath.Join(base, "Etech", "EdgeConnectorChrome", "native")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return
	}
	p := filepath.Join(dir, "host.log")
	if st, err := os.Stat(p); err == nil && st.Size() > 256*1024 {
		_ = os.Remove(p)
	}
	f, err := os.OpenFile(p, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	fmt.Fprintf(f, "%s [%s] %s\n", time.Now().Format("2006-01-02 15:04:05"), hostVersion, fmt.Sprintf(format, a...))
}
