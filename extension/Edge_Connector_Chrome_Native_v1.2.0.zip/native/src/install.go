package main

import (
	"archive/zip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"
)

const (
	maxExeBytes = 300 << 20
	maxZipBytes = 300 << 20
)

var legacyProcessNames = []string{"ProxySG_Policy_Trace_Editor.exe"}

const connectorProcessName = "Edge_Connector.exe"

type versionMeta struct {
	Version string
	SHA256  string // SHA-256 of the connector exe, if version.json provides it
}

var hex64 = regexp.MustCompile(`(?i)\b[0-9a-f]{64}\b`)

func httpGetBytes(url string, timeout time.Duration, limit int64) ([]byte, error) {
	resp, err := httpDo(url, timeout)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	return io.ReadAll(io.LimitReader(resp.Body, limit))
}

func httpDo(url string, timeout time.Duration) (*http.Response, error) {
	client := &http.Client{Timeout: timeout}
	sep := "?"
	if strings.Contains(url, "?") {
		sep = "&"
	}
	req, err := http.NewRequest("GET", url+sep+"cb="+strconv.FormatInt(time.Now().UnixMilli(), 10), nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Cache-Control", "no-cache, no-store, max-age=0")
	req.Header.Set("Pragma", "no-cache")
	req.Header.Set("User-Agent", "EdgeConnectorNativeHost/"+hostVersion)
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		resp.Body.Close()
		return nil, fmt.Errorf("HTTP %d for %s", resp.StatusCode, url)
	}
	return resp, nil
}

func fetchLatestMeta() (*versionMeta, error) {
	body, err := httpGetBytes(downloadsBase+"/version.json", 10*time.Second, 64*1024)
	if err != nil {
		return nil, err
	}
	var obj map[string]interface{}
	if err := json.Unmarshal([]byte(strings.TrimPrefix(string(body), "\ufeff")), &obj); err != nil {
		return nil, fmt.Errorf("version.json parse failed: %w", err)
	}
	m := &versionMeta{}
	for _, key := range []string{"edgeConnectorVersion", "version", "latestVersion"} {
		if raw, ok := obj[key]; ok {
			if v := normalizeVersion(fmt.Sprint(raw)); v != "" {
				m.Version = v
				break
			}
		}
	}
	if m.Version == "" {
		return nil, fmt.Errorf("version.json has no supported version field")
	}
	if s, ok := obj["sha256"].(string); ok && hex64.MatchString(s) {
		m.SHA256 = strings.ToLower(strings.TrimSpace(s))
	}
	return m, nil
}

// installConnector downloads, verifies and installs the latest Edge_Connector
// into %LOCALAPPDATA%\Etech\EdgeConnector using only in-process code.
// It needs no elevation. It returns the installed version.
func installConnector(meta *versionMeta) (string, error) {
	dir := connectorDir()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", fmt.Errorf("create install dir: %w", err)
	}
	_ = os.Remove(connectorPath() + ".old")
	_ = os.Remove(connectorPath() + ".new")

	tmp, err := os.MkdirTemp("", "EdgeConnector_")
	if err != nil {
		return "", fmt.Errorf("create temp dir: %w", err)
	}
	defer os.RemoveAll(tmp)

	logf("install: fetching zip hash")
	hb, err := httpGetBytes(downloadsBase+"/Edge_Connector.zip.sha256", 15*time.Second, 4096)
	if err != nil {
		return "", fmt.Errorf("zip sha256 download failed: %w", err)
	}
	expected := strings.ToLower(hex64.FindString(string(hb)))
	if expected == "" {
		return "", fmt.Errorf("zip sha256 file is invalid")
	}

	logf("install: downloading zip")
	zipPath := filepath.Join(tmp, "Edge_Connector.zip")
	actual, err := downloadFile(downloadsBase+"/Edge_Connector.zip", zipPath)
	if err != nil {
		return "", fmt.Errorf("zip download failed: %w", err)
	}
	if actual != expected {
		return "", fmt.Errorf("zip SHA-256 mismatch (expected %s, got %s)", expected, actual)
	}

	newExe := connectorPath() + ".new"
	defer os.Remove(newExe)
	exeName, exeSHA, err := extractConnectorExe(zipPath, newExe)
	if err != nil {
		return "", err
	}
	if meta != nil && meta.SHA256 != "" && exeSHA != meta.SHA256 {
		return "", fmt.Errorf("extracted %s SHA-256 does not match version.json (expected %s, got %s)", exeName, meta.SHA256, exeSHA)
	}

	ver := versionFromExeName(exeName)
	if ver == "" && meta != nil {
		ver = meta.Version
	}
	if ver == "" {
		return "", fmt.Errorf("cannot determine version of %s", exeName)
	}

	logf("install: stopping running connector")
	if err := stopConnectorProcesses(dir); err != nil {
		return "", err
	}
	logf("install: replacing exe with %s (v%s)", exeName, ver)
	if err := replaceFile(newExe, connectorPath()); err != nil {
		return "", err
	}
	if err := os.WriteFile(filepath.Join(dir, "edge-connector.version"), []byte(ver+"\r\n"), 0o644); err != nil {
		return "", fmt.Errorf("write version marker: %w", err)
	}
	logf("install: done v%s", ver)
	return ver, nil
}

func downloadFile(url, dst string) (string, error) {
	resp, err := httpDo(url, 3*time.Minute)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	f, err := os.Create(dst)
	if err != nil {
		return "", err
	}
	h := sha256.New()
	n, err := io.Copy(io.MultiWriter(f, h), io.LimitReader(resp.Body, maxZipBytes+1))
	cerr := f.Close()
	if err != nil {
		return "", err
	}
	if cerr != nil {
		return "", cerr
	}
	if n > maxZipBytes {
		return "", fmt.Errorf("download exceeds %d bytes", maxZipBytes)
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// extractConnectorExe writes the first Edge_Connector*.exe entry of the ZIP to
// dst. Only the entry's base name is used, so archive paths can never escape.
func extractConnectorExe(zipPath, dst string) (name, sum string, err error) {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return "", "", fmt.Errorf("open zip: %w", err)
	}
	defer zr.Close()
	for _, f := range zr.File {
		if f.FileInfo().IsDir() {
			continue
		}
		base := path.Base(strings.ReplaceAll(f.Name, "\\", "/"))
		lower := strings.ToLower(base)
		if !strings.HasPrefix(lower, "edge_connector") || !strings.HasSuffix(lower, ".exe") {
			continue
		}
		if f.UncompressedSize64 > maxExeBytes {
			return "", "", fmt.Errorf("%s is too large", base)
		}
		rc, err := f.Open()
		if err != nil {
			return "", "", err
		}
		out, err := os.Create(dst)
		if err != nil {
			rc.Close()
			return "", "", err
		}
		h := sha256.New()
		n, err := io.Copy(io.MultiWriter(out, h), io.LimitReader(rc, maxExeBytes+1))
		rc.Close()
		cerr := out.Close()
		if err != nil {
			return "", "", err
		}
		if cerr != nil {
			return "", "", cerr
		}
		if n > maxExeBytes {
			return "", "", fmt.Errorf("%s is too large", base)
		}
		return base, hex.EncodeToString(h.Sum(nil)), nil
	}
	return "", "", fmt.Errorf("Edge_Connector*.exe was not found inside the ZIP")
}

func versionFromExeName(name string) string {
	base := strings.TrimSuffix(name, filepath.Ext(name))
	i := strings.LastIndex(strings.ToLower(base), "_v")
	if i < 0 {
		return ""
	}
	return normalizeVersion(base[i+2:])
}

// stopConnectorProcesses ends running Edge Connector instances started by the
// current user. It never elevates: an instance running with higher privileges
// is reported with an actionable message instead of being force-killed via UAC.
func stopConnectorProcesses(dir string) error {
	deadline := time.Now().Add(10 * time.Second)
	killedAny := false
	var lastErr error
	for {
		type target struct {
			pid  int
			name string
		}
		var targets []target
		for _, pid := range processPIDs(connectorProcessName) {
			p := processImagePath(pid)
			if p != "" && !isUnder(p, dir) {
				continue // some other program that happens to share the name
			}
			targets = append(targets, target{pid, connectorProcessName})
		}
		for _, n := range legacyProcessNames {
			for _, pid := range processPIDs(n) {
				targets = append(targets, target{pid, n})
			}
		}
		if len(targets) == 0 {
			if killedAny {
				time.Sleep(700 * time.Millisecond) // let the OS release the file handle
			}
			return nil
		}
		for _, t := range targets {
			if err := terminatePID(t.pid); err != nil {
				lastErr = fmt.Errorf("%s PID %d: %w", t.name, t.pid, err)
			} else {
				killedAny = true
			}
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("could not stop the running Edge Connector (%v). Close it manually (Task Manager, or restart it without administrator rights) and try again", lastErr)
		}
		time.Sleep(250 * time.Millisecond)
	}
}

func isUnder(p, dir string) bool {
	p = strings.ToLower(filepath.Clean(p))
	d := strings.ToLower(filepath.Clean(dir)) + string(filepath.Separator)
	return strings.HasPrefix(p, d)
}

// replaceFile swaps newPath into target. A running image can be renamed but not
// overwritten, so the old file is moved aside first and restored on failure.
// Short retries absorb transient locks from real-time scanners.
func replaceFile(newPath, target string) error {
	old := target + ".old"
	_ = os.Remove(old)
	hadOld := false
	if _, err := os.Stat(target); err == nil {
		var rerr error
		for i := 0; i < 15; i++ {
			if rerr = os.Rename(target, old); rerr == nil {
				hadOld = true
				break
			}
			time.Sleep(300 * time.Millisecond)
		}
		if rerr != nil {
			return fmt.Errorf("cannot replace existing Edge_Connector.exe (still locked?): %w", rerr)
		}
	}
	var err error
	for i := 0; i < 15; i++ {
		if err = os.Rename(newPath, target); err == nil {
			_ = os.Remove(old)
			return nil
		}
		time.Sleep(300 * time.Millisecond)
	}
	if hadOld {
		_ = os.Rename(old, target)
	}
	return fmt.Errorf("cannot place new Edge_Connector.exe: %w", err)
}
