module edgeconnectornativehost

go 1.22
