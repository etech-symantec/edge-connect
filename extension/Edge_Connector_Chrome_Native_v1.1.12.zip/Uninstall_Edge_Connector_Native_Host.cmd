@echo off
setlocal EnableExtensions
title Edge Connector Chrome Native Host Uninstaller
set "HOST_NAME=com.etech.edgeconnector"
set "NATIVE_DIR=%LOCALAPPDATA%\Etech\EdgeConnectorChrome\native"
reg delete "HKCU\Software\Google\Chrome\NativeMessagingHosts\%HOST_NAME%" /f >nul 2>&1
if exist "%NATIVE_DIR%" rmdir /s /q "%NATIVE_DIR%"
echo Native Messaging Host registration removed.
echo The unpacked Chrome extension folder was left in place.
pause
