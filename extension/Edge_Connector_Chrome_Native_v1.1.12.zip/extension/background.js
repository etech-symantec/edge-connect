const STORE_STATE='edgeConnectorState';
const STORE_VERSION='edgeConnectorInstalledVersion';

function updateBadge(state){
  if(state==='installed'){
    chrome.action.setBadgeText({text:'ON'});
    chrome.action.setBadgeBackgroundColor({color:'#23865c'});
  }else{
    chrome.action.setBadgeText({text:''});
  }
}

async function getState(){
  const data=await chrome.storage.local.get([STORE_STATE,STORE_VERSION]);
  return {
    state:data[STORE_STATE]||'uninstalled',
    version:data[STORE_VERSION]||'',
    ts:Date.now()
  };
}

async function setState(state,version=''){
  const normalized=state==='installed'?'installed':'uninstalled';
  const patch={[STORE_STATE]:normalized};
  if(normalized==='installed' && version){
    patch[STORE_VERSION]=version;
    await chrome.storage.local.set(patch);
  }else if(normalized==='uninstalled'){
    await chrome.storage.local.set(patch);
    await chrome.storage.local.remove(STORE_VERSION);
  }else{
    await chrome.storage.local.set(patch);
  }
  updateBadge(normalized);
}

chrome.runtime.onInstalled.addListener(async()=>{
  const data=await getState();
  updateBadge(data.state);
});

chrome.runtime.onStartup.addListener(async()=>{
  const data=await getState();
  updateBadge(data.state);
});

chrome.action.onClicked.addListener(()=>{
  chrome.tabs.create({url:chrome.runtime.getURL('launcher.html')});
});

chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(!message || typeof message!=='object') return;

  if(message.type==='edgeConnectorGetState'){
    getState().then(sendResponse);
    return true;
  }

  if(message.type==='edgeConnectorSetState'){
    setState(message.state,message.version||'').then(()=>sendResponse({ok:true}));
    return true;
  }

  if(message.type==='edgeConnectorStateFromWeb'){
    const senderUrl=sender?.url||'';
    if(!senderUrl.startsWith('https://etech-symantec.github.io/edge-connect/')){
      sendResponse({ok:false});
      return;
    }
    setState(message.state,message.version||'').then(()=>sendResponse({ok:true}));
    return true;
  }
});
