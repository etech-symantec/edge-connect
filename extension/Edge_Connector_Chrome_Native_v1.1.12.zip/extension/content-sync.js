(() => {
  const ALLOWED_ORIGIN='https://etech-symantec.github.io';
  if(location.origin!==ALLOWED_ORIGIN || !location.pathname.startsWith('/edge-connect/')) return;

  function normalizeVersion(v){
    const m=String(v||'').replace(/^v/i,'').match(/(\d+(?:\.\d+){1,3})/);
    return m?m[1]:'';
  }

  function send(state,version='',source='page'){
    chrome.runtime.sendMessage({
      type:'edgeConnectorStateFromWeb',
      state:state==='installed'?'installed':'uninstalled',
      version:normalizeVersion(version),
      source,
      ts:Date.now()
    },()=>void chrome.runtime.lastError);
  }

  function sync(){
    const u=new URL(location.href);
    const callback=u.searchParams.get('connector');
    if(callback==='installed'){
      send('installed',u.searchParams.get('version')||'','installer-callback');
      return;
    }
    if(callback==='uninstalled'){
      send('uninstalled','','uninstaller-callback');
      return;
    }

    try{
      const p=JSON.parse(localStorage.getItem('edgeConnectorState')||'null');
      if(p?.state==='installed' || p?.state==='uninstalled'){
        send(p.state,localStorage.getItem('edgeConnectorInstalledVersion')||'','web-local-storage');
      }
    }catch(_){}
  }

  sync();
  window.addEventListener('storage',e=>{
    if(e.key==='edgeConnectorState' || e.key==='edgeConnectorInstalledVersion') sync();
  });
})();