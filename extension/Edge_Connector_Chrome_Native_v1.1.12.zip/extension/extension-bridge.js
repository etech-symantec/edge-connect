(() => {
  const STATE_KEY = 'edgeConnectorState';
  const VERSION_KEY = 'edgeConnectorInstalledVersion';

  function currentLocalState(){
    try{
      const p=JSON.parse(localStorage.getItem(STATE_KEY)||'null');
      return p?.state || 'uninstalled';
    }catch(_){
      return 'uninstalled';
    }
  }

  function applyRemoteState(data){
    if(!data) return;
    const remoteState=data.state==='installed'?'installed':'uninstalled';
    const localState=currentLocalState();
    const localVersion=localStorage.getItem(VERSION_KEY)||'';
    const remoteVersion=data.version||'';

    let changed=localState!==remoteState || localVersion!==remoteVersion;

    localStorage.setItem(STATE_KEY,JSON.stringify({
      state:remoteState,
      ts:data.ts||Date.now()
    }));

    if(remoteState==='installed' && remoteVersion){
      localStorage.setItem(VERSION_KEY,remoteVersion);
    }else if(remoteState==='uninstalled'){
      localStorage.removeItem(VERSION_KEY);
    }

    if(changed){
      window.dispatchEvent(new Event('pageshow'));
    }
  }

  chrome.runtime.sendMessage({type:'edgeConnectorGetState'},response=>{
    if(chrome.runtime.lastError) return;
    applyRemoteState(response);
  });

  chrome.storage.onChanged.addListener((changes,area)=>{
    if(area!=='local') return;
    if(!changes.edgeConnectorState && !changes.edgeConnectorInstalledVersion) return;
    chrome.runtime.sendMessage({type:'edgeConnectorGetState'},response=>{
      if(chrome.runtime.lastError) return;
      applyRemoteState(response);
    });
  });
})();