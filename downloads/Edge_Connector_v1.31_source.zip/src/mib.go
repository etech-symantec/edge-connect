package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

// ===================================================================== 토큰

type tok struct {
	k byte // i=식별자 n=숫자 s=문자열 p=기호 a=::=
	s string
}

func tokenize(src string) []tok {
	var out []tok
	rs := []rune(src)
	n := len(rs)
	for i := 0; i < n; {
		c := rs[i]
		switch {
		case unicode.IsSpace(c):
			i++
		case c == '-' && i+1 < n && rs[i+1] == '-': // 주석: 줄 끝 또는 다음 '--'
			i += 2
			for i < n && rs[i] != '\n' && rs[i] != '\r' {
				if rs[i] == '-' && i+1 < n && rs[i+1] == '-' {
					i += 2
					break
				}
				i++
			}
		case c == '"':
			j := i + 1
			var sb strings.Builder
			for j < n {
				if rs[j] == '"' {
					if j+1 < n && rs[j+1] == '"' {
						sb.WriteRune('"')
						j += 2
						continue
					}
					break
				}
				sb.WriteRune(rs[j])
				j++
			}
			out = append(out, tok{'s', sb.String()})
			i = j + 1
		case c == '\'':
			j := i + 1
			for j < n && rs[j] != '\'' {
				j++
			}
			j++
			for j < n && (rs[j] == 'H' || rs[j] == 'h' || rs[j] == 'B' || rs[j] == 'b') {
				j++
			}
			if j > n {
				j = n
			}
			out = append(out, tok{'s', string(rs[i:j])})
			i = j
		case c == ':' && i+2 < n && rs[i+1] == ':' && rs[i+2] == '=':
			out = append(out, tok{'a', "::="})
			i += 3
		case c == '.' && i+1 < n && rs[i+1] == '.':
			out = append(out, tok{'p', ".."})
			i += 2
		case strings.ContainsRune("{}()[],;|.", c):
			out = append(out, tok{'p', string(c)})
			i++
		case unicode.IsDigit(c):
			j := i
			for j < n && unicode.IsDigit(rs[j]) {
				j++
			}
			out = append(out, tok{'n', string(rs[i:j])})
			i = j
		case c == '-' && i+1 < n && unicode.IsDigit(rs[i+1]):
			j := i + 1
			for j < n && unicode.IsDigit(rs[j]) {
				j++
			}
			out = append(out, tok{'n', string(rs[i:j])})
			i = j
		case unicode.IsLetter(c) || c == '_':
			j := i
			for j < n && (unicode.IsLetter(rs[j]) || unicode.IsDigit(rs[j]) || rs[j] == '_' ||
				(rs[j] == '-' && !(j+1 < n && rs[j+1] == '-'))) {
				j++
			}
			out = append(out, tok{'i', string(rs[i:j])})
			i = j
		default:
			i++ // 알 수 없는 문자 무시
		}
	}
	return out
}

// ===================================================================== 모델

type EnumItem struct {
	Name  string `json:"name"`
	Value int64  `json:"value"`
}

// Syntax 는 OBJECT-TYPE / TEXTUAL-CONVENTION 의 SYNTAX 정보입니다.
type Syntax struct {
	Base     string     `json:"base"`     // INTEGER, OCTET STRING, Counter32 ... (내장 기본형)
	TypeName string     `json:"typeName"` // 선언된 형식 이름 (DisplayString 등)
	Enums    []EnumItem `json:"enums,omitempty"`
	Range    string     `json:"range,omitempty"`
	SeqOf    string     `json:"seqOf,omitempty"`
	Hint     string     `json:"hint,omitempty"`
}

type comp struct {
	name   string
	module string
	num    int64
	hasNum bool
}

type rawDef struct {
	name, module, kind string
	comps              []comp
	syntax             *Syntax
	access, status     string
	desc, units        string
	index              []string
	augments           string
	objects            []string
}

type typeDef struct {
	name, module string
	syn          Syntax
	hint         string
	isTC         bool
	desc         string
}

type Node struct {
	Name     string
	Module   string
	Kind     string
	Num      uint32
	OID      []uint32
	Parent   *Node
	Children map[uint32]*Node
	Syntax   *Syntax
	Access   string
	Status   string
	Desc     string
	Units    string
	Index    []string
	Augments string
	Objects  []string
}

type MibModule struct {
	Name    string
	File    string
	Imports map[string]string // 심볼 -> 모듈
	Defs    int
}

type MibSet struct {
	Modules  map[string]*MibModule
	Types    map[string]*typeDef // module::Name
	typeBy   map[string][]*typeDef
	Root     *Node
	byName   map[string][]*Node
	byMod    map[string]*Node // module::name
	Warnings []string
	NodeCnt  int
	raws     []*rawDef
}

func oidString(o []uint32) string {
	parts := make([]string, len(o))
	for i, v := range o {
		parts[i] = strconv.FormatUint(uint64(v), 10)
	}
	return strings.Join(parts, ".")
}

var macroKinds = map[string]string{
	"OBJECT-TYPE": "object", "MODULE-IDENTITY": "module", "OBJECT-IDENTITY": "identity",
	"NOTIFICATION-TYPE": "notification", "TRAP-TYPE": "notification", "OBJECT-GROUP": "group",
	"NOTIFICATION-GROUP": "group", "MODULE-COMPLIANCE": "group", "AGENT-CAPABILITIES": "group",
}

var clauseKeys = map[string]bool{
	"SYNTAX": true, "MAX-ACCESS": true, "ACCESS": true, "STATUS": true, "DESCRIPTION": true,
	"REFERENCE": true, "INDEX": true, "AUGMENTS": true, "DEFVAL": true, "UNITS": true,
	"DISPLAY-HINT": true, "OBJECTS": true, "VARIABLES": true, "ENTERPRISE": true,
	"LAST-UPDATED": true, "ORGANIZATION": true, "CONTACT-INFO": true, "REVISION": true,
	"NOTIFICATIONS": true, "MODULE": true, "SUPPORTS": true, "PRODUCT-RELEASE": true,
	"MANDATORY-GROUPS": true, "GROUP": true, "OBJECT": true, "WRITE-SYNTAX": true,
	"MIN-ACCESS": true, "INCLUDES": true, "VARIATION": true, "CREATION-REQUIRES": true,
}

var builtinTypes = map[string]bool{
	"INTEGER": true, "Integer32": true, "Unsigned32": true, "UInteger32": true, "Gauge32": true, "Gauge": true,
	"Counter32": true, "Counter": true, "Counter64": true, "TimeTicks": true, "IpAddress": true, "Opaque": true,
	"OCTET STRING": true, "OBJECT IDENTIFIER": true, "BITS": true, "NetworkAddress": true,
}

// ===================================================================== 파서

type parser struct {
	t    []tok
	mod  *MibModule
	set  *MibSet
	file string
}

func (p *parser) isI(i int, s string) bool {
	return i >= 0 && i < len(p.t) && p.t[i].k == 'i' && p.t[i].s == s
}
func (p *parser) isP(i int, s string) bool {
	return i >= 0 && i < len(p.t) && p.t[i].k == 'p' && p.t[i].s == s
}

// skipGroup: t[i] 가 여는 기호일 때 짝이 맞는 닫는 기호 다음 위치를 돌려줍니다.
func (p *parser) skipGroup(i int, open, close string) int {
	d := 0
	for ; i < len(p.t); i++ {
		if p.isP(i, open) {
			d++
		} else if p.isP(i, close) {
			d--
			if d == 0 {
				return i + 1
			}
		}
	}
	return i
}

func (p *parser) parseComps(i int) ([]comp, int) { // t[i] == '{'
	var out []comp
	i++
	for i < len(p.t) && !p.isP(i, "}") {
		c := p.t[i]
		switch c.k {
		case 'n':
			v, _ := strconv.ParseInt(c.s, 10, 64)
			out = append(out, comp{num: v, hasNum: true})
			i++
		case 'i':
			cm := comp{name: c.s}
			i++
			if p.isP(i, ".") && i+1 < len(p.t) && p.t[i+1].k == 'i' { // 모듈.이름
				cm.module = cm.name
				cm.name = p.t[i+1].s
				i += 2
			}
			if p.isP(i, "(") && i+2 < len(p.t) && p.t[i+1].k == 'n' {
				cm.num, _ = strconv.ParseInt(p.t[i+1].s, 10, 64)
				cm.hasNum = true
				i += 3
			}
			out = append(out, cm)
		default:
			i++
		}
	}
	return out, i + 1
}

func (p *parser) parseList(i int) ([]string, int) { // { a, b, c }
	var out []string
	if !p.isP(i, "{") {
		return nil, i
	}
	end := p.skipGroup(i, "{", "}")
	for j := i + 1; j < end-1; j++ {
		if p.t[j].k == 'i' && !p.isP(j+1, "(") && (j == i+1 || p.isP(j-1, ",")) {
			out = append(out, p.t[j].s)
		} else if p.t[j].k == 'i' && p.isI(j, "IMPLIED") {
			continue
		}
	}
	return out, end
}

func (p *parser) parseSyntax(i int, end int) (*Syntax, int) {
	syn := &Syntax{}
	for p.isP(i, "[") {
		i = p.skipGroup(i, "[", "]")
	}
	if p.isI(i, "IMPLICIT") {
		i++
	}
	if i >= end || i >= len(p.t) {
		return syn, i
	}
	switch {
	case p.isI(i, "SEQUENCE"):
		if p.isI(i+1, "OF") && i+2 < len(p.t) {
			syn.SeqOf = p.t[i+2].s
			syn.Base = "SEQUENCE OF"
			return syn, i + 3
		}
		syn.Base = "SEQUENCE"
		if p.isP(i+1, "{") {
			return syn, p.skipGroup(i+1, "{", "}")
		}
		return syn, i + 1
	case p.isI(i, "CHOICE"):
		syn.Base = "CHOICE"
		if p.isP(i+1, "{") {
			return syn, p.skipGroup(i+1, "{", "}")
		}
		return syn, i + 1
	case p.isI(i, "OCTET") && p.isI(i+1, "STRING"):
		syn.Base, syn.TypeName = "OCTET STRING", "OCTET STRING"
		i += 2
	case p.isI(i, "OBJECT") && p.isI(i+1, "IDENTIFIER"):
		syn.Base, syn.TypeName = "OBJECT IDENTIFIER", "OBJECT IDENTIFIER"
		i += 2
	case p.t[i].k == 'i':
		syn.Base, syn.TypeName = p.t[i].s, p.t[i].s
		i++
		if p.isP(i, ".") && i+1 < len(p.t) && p.t[i+1].k == 'i' { // 모듈.형식
			syn.Base, syn.TypeName = p.t[i+1].s, p.t[i+1].s
			i += 2
		}
	default:
		return syn, i + 1
	}
	for i < end && i < len(p.t) {
		if p.isP(i, "{") {
			e := p.skipGroup(i, "{", "}")
			for j := i + 1; j < e-1; j++ {
				if p.t[j].k == 'i' && p.isP(j+1, "(") && j+2 < len(p.t) && p.t[j+2].k == 'n' {
					v, _ := strconv.ParseInt(p.t[j+2].s, 10, 64)
					syn.Enums = append(syn.Enums, EnumItem{Name: p.t[j].s, Value: v})
				}
			}
			i = e
		} else if p.isP(i, "(") {
			e := p.skipGroup(i, "(", ")")
			var parts []string
			for j := i + 1; j < e-1; j++ {
				parts = append(parts, p.t[j].s)
			}
			syn.Range = strings.Join(parts, "")
			i = e
		} else {
			break
		}
	}
	return syn, i
}

func (p *parser) warn(f string, a ...any) {
	if len(p.set.Warnings) < 300 {
		p.set.Warnings = append(p.set.Warnings, fmt.Sprintf("%s: %s", p.file, fmt.Sprintf(f, a...)))
	}
}

// parse 는 한 MIB 파일 안의 모든 정의를 읽어 set 에 쌓습니다.
func (set *MibSet) parse(file, src string) {
	t := tokenize(src)
	p := &parser{t: t, set: set, file: file}
	// 모듈 이름: <Name> DEFINITIONS ::= BEGIN
	modName := ""
	start := 0
	for i := 0; i+1 < len(t); i++ {
		if t[i].k == 'i' && t[i+1].k == 'i' && t[i+1].s == "DEFINITIONS" {
			modName = t[i].s
			start = i + 2
			break
		}
	}
	if modName == "" {
		set.Warnings = append(set.Warnings, file+": MIB 모듈 정의(DEFINITIONS)를 찾지 못해 건너뜀")
		return
	}
	mod := set.Modules[modName]
	if mod == nil {
		mod = &MibModule{Name: modName, Imports: map[string]string{}}
		set.Modules[modName] = mod
	}
	mod.File = file
	p.mod = mod
	i := start
	for i < len(t) {
		switch {
		case p.isI(i, "IMPORTS"):
			i++
			var names []string
			for i < len(t) && !p.isP(i, ";") {
				if t[i].k == 'i' && t[i].s == "FROM" && i+1 < len(t) {
					for _, nme := range names {
						mod.Imports[nme] = t[i+1].s
					}
					names = nil
					i += 2
					if p.isP(i, "{") {
						i = p.skipGroup(i, "{", "}")
					}
					continue
				}
				if t[i].k == 'i' {
					names = append(names, t[i].s)
				}
				i++
			}
			i++
		case t[i].k == 'i' && p.isI(i+1, "MACRO"):
			for i < len(t) && !p.isI(i, "END") {
				i++
			}
			i++
		case t[i].k == 'i' && p.isI(i+1, "OBJECT") && p.isI(i+2, "IDENTIFIER") && i+3 < len(t) && t[i+3].k == 'a':
			if p.isP(i+4, "{") {
				cs, e := p.parseComps(i + 4)
				set.raws = append(set.raws, &rawDef{name: t[i].s, module: modName, kind: "node", comps: cs})
				mod.Defs++
				i = e
			} else {
				i += 4
			}
		case t[i].k == 'i' && i+1 < len(t) && macroKinds[t[i+1].s] != "":
			i = p.parseMacro(i)
		case t[i].k == 'i' && i+1 < len(t) && t[i+1].k == 'a':
			i = p.parseTypeAssign(i)
		default:
			i++
		}
	}
}

func (p *parser) parseMacro(i int) int {
	name, kw := p.t[i].s, p.t[i+1].s
	d := &rawDef{name: name, module: p.mod.Name, kind: macroKinds[kw]}
	j := i + 2
	// ::= 까지 본문
	bodyEnd := j
	for bodyEnd < len(p.t) && p.t[bodyEnd].k != 'a' {
		bodyEnd++
	}
	for j < bodyEnd {
		tk := p.t[j]
		if tk.k != 'i' || !clauseKeys[tk.s] {
			j++
			continue
		}
		nextKey := func(from int) int {
			k := from
			depth := 0
			for k < bodyEnd {
				if p.isP(k, "{") || p.isP(k, "(") {
					depth++
				} else if p.isP(k, "}") || p.isP(k, ")") {
					depth--
				} else if depth == 0 && p.t[k].k == 'i' && clauseKeys[p.t[k].s] && p.t[k].s != "OBJECT" && p.t[k].s != "GROUP" {
					return k
				}
				k++
			}
			return bodyEnd
		}
		switch tk.s {
		case "SYNTAX":
			e := nextKey(j + 1)
			syn, _ := p.parseSyntax(j+1, e)
			d.syntax = syn
			j = e
		case "MAX-ACCESS", "ACCESS":
			if j+1 < bodyEnd {
				d.access = p.t[j+1].s
			}
			j += 2
		case "STATUS":
			if j+1 < bodyEnd {
				d.status = p.t[j+1].s
			}
			j += 2
		case "DESCRIPTION":
			if j+1 < bodyEnd && p.t[j+1].k == 's' && d.desc == "" {
				d.desc = p.t[j+1].s
			}
			j += 2
		case "UNITS":
			if j+1 < bodyEnd && p.t[j+1].k == 's' {
				d.units = p.t[j+1].s
			}
			j += 2
		case "INDEX":
			d.index, j = p.parseList(j + 1)
		case "AUGMENTS":
			var l []string
			l, j = p.parseList(j + 1)
			if len(l) > 0 {
				d.augments = l[0]
			}
		case "OBJECTS", "VARIABLES":
			d.objects, j = p.parseList(j + 1)
		default:
			j = nextKey(j + 1)
		}
	}
	e := bodyEnd
	if e >= len(p.t) {
		return len(p.t)
	}
	e++ // ::=
	if p.isP(e, "{") {
		cs, ne := p.parseComps(e)
		d.comps = cs
		e = ne
	} else if e < len(p.t) && p.t[e].k == 'n' { // TRAP-TYPE ::= 번호 : 해석 불가, 이름만 보관
		e++
		d.comps = nil
	}
	if len(d.comps) > 0 {
		p.set.raws = append(p.set.raws, d)
		p.mod.Defs++
	}
	return e
}

func (p *parser) parseTypeAssign(i int) int {
	name := p.t[i].s
	j := i + 2
	td := &typeDef{name: name, module: p.mod.Name}
	if p.isI(j, "TEXTUAL-CONVENTION") {
		td.isTC = true
		j++
		for j < len(p.t) && !p.isI(j, "SYNTAX") {
			if p.isI(j, "DISPLAY-HINT") && j+1 < len(p.t) && p.t[j+1].k == 's' {
				td.hint = p.t[j+1].s
			}
			if p.isI(j, "DESCRIPTION") && j+1 < len(p.t) && p.t[j+1].k == 's' {
				td.desc = p.t[j+1].s
			}
			// 다음 문장으로 넘어가 버리는 것을 방지
			if p.t[j].k == 'a' {
				return j
			}
			j++
		}
		if j >= len(p.t) {
			return j
		}
		syn, e := p.parseSyntax(j+1, len(p.t))
		td.syn = *syn
		p.set.addType(td)
		return e
	}
	if p.isI(j, "SEQUENCE") || p.isI(j, "CHOICE") {
		_, e := p.parseSyntax(j, len(p.t))
		return e
	}
	syn, e := p.parseSyntax(j, len(p.t))
	td.syn = *syn
	if td.syn.Base != "" {
		p.set.addType(td)
	}
	if e <= i {
		e = i + 1
	}
	return e
}

func (set *MibSet) addType(td *typeDef) {
	set.Types[td.module+"::"+td.name] = td
	set.typeBy[td.name] = append(set.typeBy[td.name], td)
}

// ===================================================================== OID 해석

func NewMibSet() *MibSet {
	return &MibSet{
		Modules: map[string]*MibModule{}, Types: map[string]*typeDef{}, typeBy: map[string][]*typeDef{},
		byName: map[string][]*Node{}, byMod: map[string]*Node{},
		Root: &Node{Name: "", Kind: "root", Children: map[uint32]*Node{}},
	}
}

func (set *MibSet) child(n *Node, num uint32) *Node {
	c := n.Children[num]
	if c == nil {
		c = &Node{Num: num, Parent: n, Children: map[uint32]*Node{}, Kind: "node"}
		c.OID = append(append([]uint32{}, n.OID...), num)
		n.Children[num] = c
		set.NodeCnt++
	}
	return c
}

func (set *MibSet) lookupNode(module, mod2, name string) *Node {
	if mod2 != "" {
		if n := set.byMod[mod2+"::"+name]; n != nil {
			return n
		}
	}
	if n := set.byMod[module+"::"+name]; n != nil {
		return n
	}
	if m := set.Modules[module]; m != nil {
		if src, ok := m.Imports[name]; ok {
			if n := set.byMod[src+"::"+name]; n != nil {
				return n
			}
		}
	}
	if l := set.byName[name]; len(l) > 0 {
		return l[0]
	}
	return nil
}

// SMIv1 시절의 오래된 정의(RFC1213 등)는 SMIv2 모듈(IF-MIB, SNMPv2-MIB 등)이 같은 OID 를
// 다시 정의하면 그쪽(enum 값이 더 많음)을 우선합니다.
var legacyModules = map[string]bool{"RFC1213-MIB": true, "RFC1155-SMI": true, "RFC-1215": true}

func (set *MibSet) register(n *Node, d *rawDef) {
	if n.Name != "" && d.kind != "node" && legacyModules[n.Module] && !legacyModules[d.module] {
		n.Name, n.Module, n.Kind = d.name, d.module, d.kind
		n.Syntax, n.Access, n.Status, n.Desc, n.Units = d.syntax, d.access, d.status, d.desc, d.units
		n.Index, n.Augments, n.Objects = d.index, d.augments, d.objects
	}
	if n.Name == "" {
		n.Name, n.Module = d.name, d.module
	}
	if n.Kind == "node" || n.Kind == "" || (d.kind != "node" && n.Kind == "node") {
		if d.kind != "node" {
			n.Kind = d.kind
		}
	}
	if d.kind != "node" {
		if n.Syntax == nil {
			n.Syntax = d.syntax
		}
		if d.access != "" {
			n.Access = d.access
		}
		n.Status, n.Desc, n.Units = pick(n.Status, d.status), pick(n.Desc, d.desc), pick(n.Units, d.units)
		if len(d.index) > 0 {
			n.Index = d.index
		}
		n.Augments = pick(n.Augments, d.augments)
		n.Objects = d.objects
	}
	key := d.module + "::" + d.name
	if set.byMod[key] == nil {
		set.byMod[key] = n
		set.byName[d.name] = append(set.byName[d.name], n)
	}
}

func pick(a, b string) string {
	if a != "" {
		return a
	}
	return b
}

// resolve 는 모든 정의의 OID 를 계산해 트리에 붙입니다. 앞선 정의가 필요한 경우 여러 번 반복합니다.
func (set *MibSet) resolve() {
	set.Root.OID = nil
	set.Root.Kind = "root"
	// 내장 루트
	for _, r := range []struct {
		n string
		v uint32
	}{{"ccitt", 0}, {"iso", 1}, {"joint-iso-ccitt", 2}} {
		n := set.child(set.Root, r.v)
		n.Name, n.Module = r.n, "(builtin)"
		set.byMod["(builtin)::"+r.n] = n
		set.byName[r.n] = append(set.byName[r.n], n)
	}
	pending := set.raws
	for len(pending) > 0 {
		var next []*rawDef
		progress := false
		for _, d := range pending {
			if set.place(d) {
				progress = true
			} else {
				next = append(next, d)
			}
		}
		pending = next
		if !progress {
			break
		}
	}
	for i, d := range pending {
		if i >= 40 {
			set.Warnings = append(set.Warnings, fmt.Sprintf("… 그 외 미해석 정의 %d개", len(pending)-40))
			break
		}
		set.Warnings = append(set.Warnings, fmt.Sprintf("%s: '%s' 의 상위 OID 를 찾지 못함 (필요한 MIB 가 없을 수 있음)", d.module, d.name))
	}
	set.raws = nil
}

func (set *MibSet) place(d *rawDef) bool {
	if len(d.comps) == 0 {
		return true
	}
	var cur *Node
	cs := d.comps
	first := cs[0]
	switch {
	case first.name == "" && first.hasNum:
		cur = set.child(set.Root, uint32(first.num))
		cs = cs[1:]
	default:
		if first.hasNum && first.name != "" && set.lookupNode(d.module, first.module, first.name) == nil {
			// 예: { iso(1) org(3) ... } 처럼 번호가 함께 있는 첫 항목
			cur = set.child(set.Root, uint32(first.num))
			if cur.Name == "" {
				cur.Name, cur.Module = first.name, d.module
				set.byMod[d.module+"::"+first.name] = cur
				set.byName[first.name] = append(set.byName[first.name], cur)
			}
		} else {
			cur = set.lookupNode(d.module, first.module, first.name)
			if cur == nil {
				return false
			}
		}
		cs = cs[1:]
	}
	for idx, c := range cs {
		if !c.hasNum {
			return false
		}
		cur = set.child(cur, uint32(c.num))
		if c.name != "" && idx < len(cs)-1 && cur.Name == "" {
			cur.Name, cur.Module = c.name, d.module
			set.byMod[d.module+"::"+c.name] = cur
			set.byName[c.name] = append(set.byName[c.name], cur)
		}
	}
	set.register(cur, d)
	return true
}

// ===================================================================== 형식 해석

func (set *MibSet) findType(module, name string) *typeDef {
	if t := set.Types[module+"::"+name]; t != nil {
		return t
	}
	if m := set.Modules[module]; m != nil {
		if src, ok := m.Imports[name]; ok {
			if t := set.Types[src+"::"+name]; t != nil {
				return t
			}
		}
	}
	if l := set.typeBy[name]; len(l) > 0 {
		for _, t := range l { // TC 를 우선
			if t.isTC {
				return t
			}
		}
		return l[0]
	}
	return nil
}

// ResolveSyntax 는 사용자 정의 형식을 따라가 기본형, enum, hint 를 채운 복사본을 돌려줍니다.
func (set *MibSet) ResolveSyntax(module string, in *Syntax) *Syntax {
	if in == nil {
		return nil
	}
	out := *in
	mod := module
	cur := in
	for depth := 0; depth < 12; depth++ {
		if cur.SeqOf != "" || builtinTypes[cur.Base] || cur.Base == "" || cur.Base == "SEQUENCE" || cur.Base == "CHOICE" {
			break
		}
		td := set.findType(mod, cur.Base)
		if td == nil {
			break
		}
		if out.Hint == "" {
			out.Hint = td.hint
		}
		if len(out.Enums) == 0 {
			out.Enums = td.syn.Enums
		}
		if out.Range == "" {
			out.Range = td.syn.Range
		}
		mod = td.module
		next := td.syn
		out.Base = next.Base
		cur = &next
		if td.name == next.Base { // 자기 참조 방지
			break
		}
	}
	return &out
}

// ===================================================================== 조회

func (set *MibSet) Find(oid []uint32) (*Node, int) { // 가장 깊은 일치 노드와 일치 길이
	n := set.Root
	depth := 0
	for _, v := range oid {
		c := n.Children[v]
		if c == nil {
			break
		}
		n = c
		depth++
	}
	return n, depth
}

// NameOID 는 numeric OID 를 name.instance 형태로 바꿉니다.
func (set *MibSet) NameOID(oid []uint32) (name string, node *Node, instance string) {
	n, depth := set.Find(oid)
	for n != set.Root && n.Name == "" {
		n = n.Parent
		depth--
	}
	if n == set.Root || n.Module == "(builtin)" {
		return oidString(oid), nil, ""
	}
	inst := ""
	if depth < len(oid) {
		inst = oidString(oid[depth:])
	}
	return n.Name, n, inst
}

func (set *MibSet) NodeByName(name string) *Node {
	if i := strings.Index(name, "::"); i > 0 {
		if n := set.byMod[name[:i]+"::"+name[i+2:]]; n != nil {
			return n
		}
		name = name[i+2:]
	}
	if l := set.byName[name]; len(l) > 0 {
		return l[0]
	}
	return nil
}

func (n *Node) SortedChildren() []*Node {
	out := make([]*Node, 0, len(n.Children))
	for _, c := range n.Children {
		out = append(out, c)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Num < out[j].Num })
	return out
}

// Classify 는 화면에 보여줄 종류를 정합니다: table / entry / column / scalar / notification / group / module / node
func (set *MibSet) Classify(n *Node) string {
	switch n.Kind {
	case "object":
		if n.Syntax != nil && n.Syntax.SeqOf != "" {
			return "table"
		}
		if len(n.Index) > 0 || n.Augments != "" {
			return "entry"
		}
		if n.Parent != nil && (len(n.Parent.Index) > 0 || n.Parent.Augments != "") {
			return "column"
		}
		if n.Syntax == nil {
			return "node"
		}
		return "scalar"
	case "":
		return "node"
	}
	return n.Kind
}
