import { JSDOM, VirtualConsole } from "jsdom";
import fs from "fs";
const url = fs.readFileSync("url_mib.txt", "utf8").trim();
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const vc = new VirtualConsole();
vc.on("jsdomError", e => { const t = String(e.message || e); if (!/Not implemented/.test(t)) console.log("JSDOMERR", t.slice(0, 300)); });
const dom = await JSDOM.fromURL(url, { runScripts: "dangerously", resources: "usable", pretendToBeVisual: true, virtualConsole: vc });
const w = dom.window, d = w.document;
w.fetch = (u, o) => fetch(new URL(u, w.location.href), o);
w.Element.prototype.scrollIntoView = () => {}; w.confirm = () => true; w.alert = () => {};
await sleep(500);
const $ = (id) => d.getElementById(id);
const set = (id, v) => { $(id).value = v; $(id).dispatchEvent(new w.Event("input")); $(id).dispatchEvent(new w.Event("change")); };
const waitFor = async (fn, ms = 30000, what = "") => { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return true; } catch {} await sleep(100); } console.log("TIMEOUT waiting:", what); return false; };
const disp = (el) => w.getComputedStyle(el).display;
const pageActive = (n) => $("page-" + n).classList.contains("active");

set("host", "127.0.0.1");
d.querySelector('#sideModeGroup summary').click();
ok(pageActive("mode"), "기능 선택 페이지");
ok(!!$("modeCardMib"), "MIB 카드 존재");
ok(disp($("sideMibGroup")) === "none", "선택 전 MIB 메뉴 숨김");
$("modeCardMib").click();
ok(pageActive("mib") && $("modeBadge").textContent === "MIB", "MIB 카드 -> MIB 페이지, 배지 MIB");
ok(disp($("sideMibGroup")) !== "none" && disp($("sideAdminGroup")) === "none" && disp($("sidePolicyGroup")) === "none", "MIB 모드: STEP 3 = MIB 조회만 표시");
ok($("mibDevicePill").textContent.includes("127.0.0.1"), "장비 pill 공유");

// SNMP 테스트
set("mibPort", "18161"); set("mibTimeout", "2"); set("mibCommunity", "public");
$("mibTestBtn").click();
ok(await waitFor(() => /SNMP v2c 응답/.test($("mibTestStatus").textContent), 15000, "snmp test"), "SNMP 연결 테스트: " + $("mibTestStatus").textContent.replace(/\n/g, " | ").slice(0, 90));

// MIB 업로드 (ZIP)
const buf = fs.readFileSync(process.env.SAMPLE_ZIP);
const file = new w.File([buf], "mibs.zip");
Object.defineProperty($("mibFiles"), "files", { value: [file], configurable: true });
$("mibLoadBtn").click();
ok(await waitFor(() => /모듈 49개/.test($("mibLoadStatus").textContent), 30000, "mib load"), "MIB 업로드: " + $("mibLoadStatus").textContent);
ok($("mibInfoPill").textContent.includes("49 modules"), "MIB 요약 pill: " + $("mibInfoPill").textContent);
ok(await waitFor(() => d.querySelectorAll("#mibTree .mibNode").length > 5, 15000, "tree"), "트리 표시 (internet 까지 자동 펼침): " + d.querySelectorAll("#mibTree .mibNode").length + "개 노드");
ok([...d.querySelectorAll("#mibTree .mibName")].some(x => x.textContent === "internet"), "internet 노드 보임");

// 검색 -> 상세
set("mibSearch", "deviceSensorUnits");
ok(await waitFor(() => d.querySelectorAll("#mibSearchResults .mibNode").length >= 1, 10000, "search"), "검색 결과: " + d.querySelectorAll("#mibSearchResults .mibNode").length);
d.querySelector("#mibSearchResults .mibNode").click();
ok(await waitFor(() => /celsius\(5\)/.test($("mibDetail").textContent), 15000, "detail"), "상세에 enum 값 목록 표시");
ok($("mibOid").value === "1.3.6.1.4.1.3417.2.1.1.1.1.1.3", "OID 입력칸 자동 채움: " + $("mibOid").value);
ok(!!d.querySelector("#mibTree .mibNode.sel"), "트리에서 해당 객체 선택/펼침");

// Get / Walk
set("mibOid", "sysDescr"); $("mibGetBtn").click();
ok(await waitFor(() => /SGOS/.test($("mibResultBody").textContent), 10000, "get"), "Get sysDescr -> " + $("mibResultBody").textContent.slice(0, 60));
set("mibOid", "ifTable"); $("mibWalkBtn").click();
ok(await waitFor(() => d.querySelectorAll("#mibResultBody tr").length === 2, 15000, "walk table"), "Walk ifTable -> 표 2행");
ok(/ifOperStatus/.test($("mibResultHead").textContent) && /dormant\(5\)/.test($("mibResultBody").textContent), "표 헤더/enum 값 표시");
d.querySelector('#mibViewTabs button[data-view="list"]').click();
ok(d.querySelectorAll("#mibResultBody tr").length === 10, "목록 보기 전환: " + d.querySelectorAll("#mibResultBody tr").length + "행");
// 잘못된 community
set("mibCommunity", "bad"); set("mibOid", "sysDescr"); $("mibGetBtn").click();
ok(await waitFor(() => !$("mibErr").classList.contains("adminHidden") && /시간 초과/.test($("mibErr").textContent), 15000, "bad community"), "잘못된 community -> 오류 표시");
// 영어 전환 (멈춤 없이 즉시 전환되어야 함)
const t0 = Date.now(); $("langEnBtn").click(); await sleep(400);
ok(Date.now() - t0 < 3000 && /MIB Browser/.test(d.querySelector("#page-mib .pageTitle").textContent), "English: " + d.querySelector("#page-mib .pageTitle").textContent.trim());
console.log(fails ? `\n${fails} FAILED` : "\nALL MIB E2E OK");
process.exit(fails ? 1 : 0);
