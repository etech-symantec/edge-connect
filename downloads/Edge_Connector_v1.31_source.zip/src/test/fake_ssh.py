#!/usr/bin/env python3
"""ssh.exe 대용 모의 ProxySG CLI (테스트용). 상태는 $MOCK_STATE(JSON) 파일에 저장해 세션 간 공유한다."""
import json, os, sys, re

ST = os.environ["MOCK_STATE"]
ENABLE_PW = os.environ.get("MOCK_ENABLE_PW", "enpw")
PAGER = os.environ.get("MOCK_PAGER") == "1"

def load():
    if os.path.exists(ST):
        return json.load(open(ST, encoding="utf-8"))
    return {"realms": {"test": "sgusers"}, "lists": {"sgusers": ["admin1", "u2"]}, "policy": "", "pw": {}, "cmds": []}

S = load()
def save(): json.dump(S, open(ST, "w", encoding="utf-8"), ensure_ascii=False)

_buf = b""
def read_byte():
    global _buf
    if not _buf:
        _buf = os.read(0, 4096)
        if not _buf: sys.exit(0)
    b, _buf = _buf[:1], _buf[1:]
    return b
def read_line():
    out = b""
    while True:
        b = read_byte()
        if b == b"\n": return out.decode("utf-8", "replace").rstrip("\r")
        out += b
def w(s): sys.stdout.write(s); sys.stdout.flush()

mode, stack = "user", []
def prompt():
    if mode == "user": return "\nP_212> "
    if mode == "enable": return "\nP_212# "
    return "\nP_212#(" + " ".join(["config"] + [x[1] for x in stack]) + ") "

w("\nP_212> ")
while True:
    c = read_line().strip()
    S["cmds"].append(c if not c.startswith("password ") else "password ****"); 
    out = "\n" + c + "\n"; wd = c.split()
    if mode == "pw":
        if c == ENABLE_PW: mode = "enable"; w("\n" + prompt().lstrip("\n"))
        else: mode = "user"; w("\n% Access denied\n" + prompt())
        save(); continue
    if c == "": w(prompt()); continue
    if wd[0] == "enable" and mode == "user": mode = "pw"; w(out + "Enable Password:"); continue
    if c == "exit" and mode in ("user", "enable") : save(); sys.exit(0)
    if c in ("conf t", "configure terminal"):
        if mode != "enable": w(out + "% Invalid input detected at '^' marker.\n" + prompt()); continue
        mode, stack = "config", []; w(out + prompt()); save(); continue
    if c.startswith("show advanced-url /local_policy_source.txt"):
        body = S["policy"]
        if PAGER and len(body.splitlines()) > 3:
            ls = body.split("\n"); w(out + "\n".join(ls[:3]) + "\n--More--"); 
            while read_byte() != b" ": pass
            w("\x08\x08\x08\x08\x08\x08\x08\x08        \x08\x08\x08\x08\x08\x08\x08\x08" + "\n".join(ls[3:]) + "\n" + prompt())
        else:
            w(out + body + ("\n" if body and not body.endswith("\n") else "") + prompt())
        continue
    if wd[:3] == ["inline", "policy", "local"] and mode == "config":
        marker = wd[3]; w("\nEnter configuration, one per line. End with " + marker + "\n"); lines = []
        while True:
            ln = read_line()
            if ln.strip() == marker: break
            lines.append(ln)
        S["policy"] = "\n".join(lines); save(); w("\nok\n" + prompt()); continue
    if c == "exit":
        if stack: stack.pop()
        elif mode == "config": mode = "enable"
        w(out + prompt()); continue
    if mode == "config":
        if wd[:3] == ["security", "local", "create-realm"]: S["realms"].setdefault(wd[3], None)
        elif wd[:3] == ["security", "local", "edit-realm"]:
            if wd[3] in S["realms"]: stack.append(("realm", wd[3]))
            else: out += f'% Realm "{wd[3]}" does not exist\n'
        elif wd[:3] == ["security", "local-user-list", "create"]: S["lists"].setdefault(wd[3], [])
        elif wd[:3] == ["security", "local-user-list", "edit"]:
            if wd[3] in S["lists"]: stack.append(("ul", wd[3]))
            else: out += f'% User list "{wd[3]}" does not exist\n'
        elif wd[0] == "local-user-list" and stack and stack[-1][0] == "realm": S["realms"][stack[-1][1]] = wd[1]
        elif wd[:2] == ["user", "create"] and stack:
            if wd[2] not in S["lists"][stack[-1][1]]: S["lists"][stack[-1][1]].append(wd[2])
        elif wd[:2] == ["user", "edit"] and stack:
            if wd[2] in S["lists"][stack[-1][1]]: stack.append(("user", wd[2]))
            else: out += f'% User "{wd[2]}" does not exist\n'
        elif wd[:2] == ["user", "delete"] and stack:
            lst = stack[-1][1]
            if wd[2] in S["lists"][lst]:
                w(out + "This will permanently delete the object. Proceed with deletion? (y or n) ")
                if read_line().strip() == "y": S["lists"][lst].remove(wd[2])
                out = "\nok\n"
            else: out += f'% User "{wd[2]}" does not exist\n'
        elif wd[0] == "password" and stack and stack[-1][0] == "user": S["pw"][stack[-2][1] + "/" + stack[-1][1]] = wd[1]
        elif wd[:2] == ["group", "create"] or wd[:2] == ["group", "add"]: pass
        elif c == "view" and stack:
            kind, name = stack[-1]
            if kind == "realm": out += f"local-user-list: {S['realms'][name]}\n"
            else:
                out += "Local user list: " + name + "\nUsers:\n"
                for u in sorted(S["lists"][name]):
                    out += f"  {u}\n    Hashed Password:\n$PBKDF2$AAAA{u}BBBBlonghashvalue\n    Groups: sgadmins\n    Enabled: yes\n"
                out += "Groups:\n  sgadmins\n"
        elif c.startswith("show "): out += "% Invalid input detected at '^' marker.\n"
        w(out + prompt()); save(); continue
    w(out + "% Invalid input detected at '^' marker.\n" + prompt())
