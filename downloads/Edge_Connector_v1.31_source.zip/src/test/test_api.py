import subprocess, os, sys, json, time, urllib.request, re, signal
here = os.path.dirname(os.path.abspath(__file__))
state = os.path.join(here, "state.json")
if os.path.exists(state): os.remove(state)
MG = 18082
env = dict(os.environ, EDGE_CONNECTOR_SSH_PATH=os.path.join(here, "fake_ssh.py"), MOCK_STATE=state, EDGE_CONNECTOR_NO_BROWSER="1")
mg = subprocess.Popen([sys.executable, os.path.join(here, "fake_mgmt.py"), str(MG)])
ed = subprocess.Popen([os.path.join(here, "editor")], env=env, stdout=subprocess.PIPE, text=True)
url = ed.stdout.readline().strip(); base = url.rstrip("/")
html = urllib.request.urlopen(url).read().decode()
print("page served, token injected:", "__APP_TOKEN__" not in html)
TOKEN = re.search(r"APP_TOKEN\s*=\s*'([0-9a-f]+)'", html) if "const APP_TOKEN" in html else None
# test index is a stub; get token from the stub text instead
TOKEN = TOKEN.group(1) if TOKEN else re.search(r"<html>([0-9a-f]+)</html>", html).group(1)
ok = fails = 0
def call(path, body=None, token=TOKEN, expect=200):
    req = urllib.request.Request(base + path, data=json.dumps(body or {}).encode(), method="POST",
                                 headers={"X-App-Token": token, "Content-Type": "application/json"})
    try:
        r = urllib.request.urlopen(req); return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
def check(c, m):
    global ok, fails
    print(("PASS " if c else "FAIL ") + m); ok += bool(c); fails += (not c)
C = dict(host="127.0.0.1", port=22, username="admin", password="sshpw", enablePassword="enpw",
         mgmtProtocol="http", mgmtPort=MG, mgmtUsername="admin", mgmtPassword="sshpw", mgmtSkipTLS=True)
try:
    check(call("/api/system", token="bad")[0] == 403, "bad token -> 403")
    s, d = call("/api/system"); check(d.get("sshFound") is True, "system sshFound")
    t0 = time.time(); s, d = call("/api/test-connection", C); check(s == 200 and d.get("prompt", "").endswith("#"), f"test-connection prompt={d.get('prompt')} ({time.time()-t0:.1f}s) {d.get('error','')}")
    s, d = call("/api/test-connection", dict(C, enablePassword="wrong", password="sshpw")); check(s != 200, f"wrong enable pw rejected: {d.get('error')}")
    s, d = call("/api/test-management", C); check(s == 200 and d["files"] == 1, f"test-management {d}")
    s, d = call("/api/list-traces", C); check(d.get("files") == ["trace.html"], f"list-traces {d.get('files')}")
    s, d = call("/api/list-accesslogs", C); check(d.get("logs") == ["main", "ssl_log"], f"list-accesslogs {d.get('logs')}")
    s, d = call("/api/read-trace", dict(C, traceFile="trace.html", offset=0, forceFull=True)); t = d["trace"]
    check(t["mode"] == "full" and "start transaction 1" in t["content"] and t["nextOffset"] == t["totalBytes"], f"read-trace full {t['nextOffset']}")
    s, d = call("/api/read-trace", dict(C, traceFile="trace.html", offset=t["nextOffset"], etag=t["etag"], lastModified=t["lastModified"]))
    t2 = d["trace"]; check(t2["mode"] == "append" and t2["changed"] is False, f"read-trace unchanged {t2['httpStatus']}")
    s, d = call("/api/read-trace", dict(C, traceFile="../x", offset=0)); check(s == 400, "trace name validation")
    s, d = call("/api/read-accesslog", dict(C, logName="main")); check("#Fields" in d.get("content", ""), "read-accesslog")
    # --- policy
    s, d = call("/api/read-policy", C); check(s == 200 and d["policy"]["content"] == "", f"read-policy empty {d.get('error','')}")
    rev0 = d["policy"]["revision"]
    INS = ";===Trace 테스트 정책 설정===\ndefine condition __PE_TRACE_SOURCE\n    client.address=10.1.1.5\nend condition __PE_TRACE_SOURCE\n<Proxy>\ncondition=__PE_TRACE_SOURCE trace.request(yes) trace.destination(\"trace.html\")"
    orig = ";existing\n<Proxy>\nurl.domain=example.com allow"
    s, d = call("/api/preview", {"originalContent": orig, "insertion": INS}); fb = d["finalBlock"]
    check(d["duplicate"] is False and fb.startswith("inline policy local EOF_POLICY_EDITOR_1") and "__PE_TRACE_SOURCE" in fb, "preview final block")
    s, d = call("/api/apply-policy", dict(C, revision=rev0, originalContent="", insertion=INS, finalBlock=fb, manualEdited=False, allowDuplicate=False))
    check(s == 200 and d.get("policy", {}).get("revision") != rev0 and d["removableTraceBlock"] == INS, f"apply-policy {d.get('error','')} {d.get('details','')}")
    cur = json.load(open(state))["policy"]; check("trace.destination" in cur and "existing" in cur, "device policy updated")
    s, d = call("/api/apply-policy", dict(C, revision=rev0, originalContent="", insertion=INS, finalBlock=fb))
    check(s == 409 and d.get("code") == "POLICY_CHANGED", f"stale revision rejected ({d.get('code')})")
    rd = call("/api/read-policy", C)[1]["policy"]
    s, d = call("/api/preview", {"originalContent": rd["content"], "insertion": INS.replace("__PE_TRACE_SOURCE", "__PE_TRACE_SOURCE_2")})
    check(d.get("duplicate") is True, "duplicate detected despite condition rename")
    s, d = call("/api/prepare-remove-trace-policy", dict(C, exactBlock=INS)); rfb = d["finalBlock"]
    check(s == 200 and "trace.destination" not in rfb and "example.com" in rfb, f"prepare-remove {d.get('error','')}")
    s, d = call("/api/apply-policy", dict(C, revision=d["policy"]["revision"], insertion="", finalBlock=rfb, manualEdited=True))
    check(s == 200 and "trace.destination" not in json.load(open(state))["policy"], "removal applied")
    s, d = call("/api/prepare-remove-trace-policy", dict(C, exactBlock=INS)); check(s == 404 and d.get("code") == "TRACE_BLOCK_NOT_FOUND" and d["details"]["differences"], "remove again -> NOT_FOUND with diff")
    s, d = call("/api/delete-trace", dict(C, traceFile="trace.html")); check(d.get("files") == [], "delete-trace")
    # --- admin
    A = dict(C, realm="test", userlist="", newUser="", newPass="", newPass2="", groups="sgadmins")
    s, d = call("/api/admin/list-users", A); check([u["name"] for u in d["users"]] == ["admin1", "u2"] and d["userlist"] == "sgusers", f"admin list {d.get('users')} {d.get('error','')}")
    check("PBKDF2" not in "\n".join(d["log"]), "hash redacted in log")
    s, d = call("/api/admin/plan", dict(A, newUser="admin3", newPass="NewPass123", newPass2="NewPass123", policyEnable=True, policyAuth=True, access="RW"))
    check(s == 200 and 'group="sgadmins" allow' in d["cpl"] and "BEGIN proxysg-admin-tool" in d["finalBlock"], f"admin plan {d.get('error','')}")
    plan = d
    s, d = call("/api/admin/add", dict(A, newUser="admin3", newPass="NewPass123", newPass2="NewPass123", policyEnable=True, policyAuth=True, access="RW", revision=plan["policy"]["revision"], finalBlock=plan["finalBlock"]))
    check(s == 200 and d["policyApplied"] is True and "admin3" in [u["name"] for u in d["users"]], f"admin add {d.get('error','')}")
    check("NewPass123" not in json.dumps(d), "no new password in response/log")
    st = json.load(open(state)); check("authenticate(test)" in st["policy"] and st["pw"].get("sgusers/admin3") == "NewPass123", "device has policy + password")
    s, d = call("/api/admin/password", dict(A, newUser="u2", newPass="Changed#Pw9", newPass2="Changed#Pw9")); check(s == 200 and json.load(open(state))["pw"]["sgusers/u2"] == "Changed#Pw9", f"admin passwd {d.get('error','')}")
    s, d = call("/api/admin/delete", dict(A, newUser="u2")); check(s == 200 and "u2" not in [u["name"] for u in d["users"]], f"admin delete {d.get('error','')}")
    s, d = call("/api/admin/add", dict(A, realm="newrealm", newUser="x1", newPass="pw1234", newPass2="pw1234", groups="g1", createRealm=True, createGroup=True, policyEnable=False))
    st = json.load(open(state)); check(s == 200 and st["realms"].get("newrealm") == "newrealm_users" and "x1" in st["lists"]["newrealm_users"], f"create realm+list+user {d.get('error','')}")
    s, d = call("/api/admin/add", dict(A, newUser="bad name", newPass="a", newPass2="a")); check(s == 400, "name validation")
    s, d = call("/api/shutdown"); 
    time.sleep(1); check(ed.poll() is not None, "shutdown stops server")
finally:
    for p in (ed, mg):
        try: p.kill()
        except Exception: pass
print(f"\n{ok} passed, {fails} failed"); sys.exit(1 if fails else 0)
