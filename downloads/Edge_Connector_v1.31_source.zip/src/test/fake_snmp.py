import socket, sys
def enc_len(n):
    if n < 128: return bytes([n])
    b = n.to_bytes((n.bit_length()+7)//8, 'big'); return bytes([0x80|len(b)])+b
def tlv(t, v): return bytes([t]) + enc_len(len(v)) + v
def enc_int(v):
    n = 1
    while True:
        try: return tlv(2, v.to_bytes(n, 'big', signed=True))
        except OverflowError: n += 1
def enc_uint(t, v):
    b = v.to_bytes(max(1,(v.bit_length()+7)//8), 'big')
    if b[0] & 0x80: b = b'\0'+b
    return tlv(t, b)
def enc_oid(o):
    b = [o[0]*40+o[1]]
    for x in o[2:]:
        parts=[x&0x7f]; x>>=7
        while x: parts.insert(0,(x&0x7f)|0x80); x>>=7
        b += parts
    return tlv(6, bytes(b))
def dec_len(b, i):
    l = b[i]; i += 1
    if l & 0x80:
        n = l & 0x7f; l = int.from_bytes(b[i:i+n], 'big'); i += n
    return l, i
def rd(b, i):
    t = b[i]; l, j = dec_len(b, i+1); return t, b[j:j+l], j+l
def dec_oid(v):
    out=[v[0]//40, v[0]%40]; cur=0
    for c in v[1:]:
        cur=(cur<<7)|(c&0x7f)
        if not c&0x80: out.append(cur); cur=0
    return tuple(out)
def dec_int(v): return int.from_bytes(v,'big',signed=True)

def val(kind, x):
    if kind=='i': return enc_int(x)
    if kind=='s': return tlv(4, x if isinstance(x,bytes) else x.encode())
    if kind=='o': return enc_oid(x)
    if kind=='g': return enc_uint(0x42,x)
    if kind=='c': return enc_uint(0x41,x)
    if kind=='C': return enc_uint(0x46,x)
    if kind=='t': return enc_uint(0x43,x)
    if kind=='a': return tlv(0x40, bytes(x))
D = {}
def add(o, kind, x): D[tuple(int(p) for p in o.split('.'))] = (kind, x)
add('1.3.6.1.2.1.1.1.0','s','ProxySG Series S400, Version: SGOS 7.4.16.2 Proxy Edition')
add('1.3.6.1.2.1.1.2.0','o',(1,3,6,1,4,1,3417,1,1))
add('1.3.6.1.2.1.1.3.0','t',123456789)
add('1.3.6.1.2.1.1.5.0','s','P_212')
for i,(d,mac,st) in enumerate([('lo0',b'',1),('eth0',bytes([0,0x50,0x56,0xab,0xcd,0xef]),5)],1):
    add(f'1.3.6.1.2.1.2.2.1.1.{i}','i',i)
    add(f'1.3.6.1.2.1.2.2.1.2.{i}','s',d)
    add(f'1.3.6.1.2.1.2.2.1.6.{i}','s',mac)
    add(f'1.3.6.1.2.1.2.2.1.8.{i}','i',st)
    add(f'1.3.6.1.2.1.2.2.1.10.{i}','c',4000000000+i)
for i,(u,v) in enumerate([(5,452),(4,1212)],1):
    base='1.3.6.1.4.1.3417.2.1.1.1.1.1'
    add(f'{base}.1.{i}','i',i); add(f'{base}.3.{i}','i',u); add(f'{base}.5.{i}','i',v); add(f'{base}.7.{i}','i',1)
add('1.3.6.1.4.1.3417.2.11.3.1.3.1.0','g',42)
add('1.3.6.1.2.1.31.1.1.1.6.1','C',2**40+5)
add('1.3.6.1.2.1.4.20.1.1.10.0.0.1','a',[10,0,0,1])
KEYS = sorted(D)
def nxt(o):
    for k in KEYS:
        if k > o: return k
    return None
def vb(o, ex=None):
    if ex: return tlv(0x30, enc_oid(o)+bytes([ex,0]))
    k,x = D[o]; return tlv(0x30, enc_oid(o)+val(k,x))
def main(port, comm=b'public'):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.bind(('127.0.0.1', port))
    print('ready', flush=True)
    while True:
        data, addr = s.recvfrom(65535)
        try:
            _, body, _ = rd(data, 0)
            t, v, i = rd(body, 0); t, c, i = rd(body, i)
            if c != comm: continue
            pt, pv, _ = rd(body, i)
            t, rid, j = rd(pv, 0); t, e1, j = rd(pv, j); t, e2, j = rd(pv, j)
            t, vbs, _ = rd(pv, j)
            oids=[]; k=0
            while k < len(vbs):
                t, x, k = rd(vbs, k); _, ov, _ = rd(x, 0); oids.append(dec_oid(ov))
            out=b''
            if pt == 0xA0:
                for o in oids: out += vb(o) if o in D else vb(o, 0x81)
            elif pt == 0xA1:
                for o in oids:
                    n = nxt(o); out += vb(n) if n else vb(o, 0x82)
            elif pt == 0xA5:
                rep = dec_int(e2); cur = oids[0]
                for _ in range(rep):
                    n = nxt(cur)
                    if not n: out += vb(cur, 0x82); break
                    out += vb(n); cur = n
            resp = tlv(0xA2, tlv(2, rid) + enc_int(0) + enc_int(0) + tlv(0x30, out))
            s.sendto(tlv(0x30, enc_int(1) + tlv(4, comm) + resp), addr)
        except Exception as e:
            print('err', e, file=sys.stderr)
main(int(sys.argv[1]))
