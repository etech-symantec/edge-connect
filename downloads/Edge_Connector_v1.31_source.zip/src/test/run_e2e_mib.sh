#!/bin/sh
cd "$(dirname "$0")"
TMPD=$(mktemp -d)
python3 fake_snmp.py 18161 > /dev/null &
AG=$!
LOCALAPPDATA=$TMPD EDGE_CONNECTOR_NO_BROWSER=1 ./editor > url_mib.txt 2> server_err_mib.txt &
ED=$!
sleep 1.5
SAMPLE_ZIP="$PWD/../../mibsrc/r/files/mibs_sg_7.4.16.2-309824.zip" timeout 200 node e2e_mib.mjs > e2e_mib_out.txt 2>&1
kill $ED $AG 2>/dev/null
rm -rf $TMPD
echo DONE >> e2e_mib_out.txt
