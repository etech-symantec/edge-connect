#!/usr/bin/env python3
"""모의 Management Console (HTTP). /policy, /Policy/Trace/<f>(Range/ETag), /Accesslog/..."""
import http.server, sys, json, base64, os, threading, time
PORT = int(sys.argv[1]); USER, PW = "admin", "sshpw"
TRACE = {"trace.html": "<html><body><pre>start transaction 1\nline a\nstop transaction 1\n</pre></body></html>"}
LOG = "#Fields: date time c-ip cs-method cs-host sc-status\n2026-10-15 00:00:01 10.0.0.1 GET example.com 200\n"
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send(self, code, body=b"", hdr=None):
        self.send_response(code)
        for k, v in (hdr or {}).items(): self.send_header(k, v)
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def authed(self):
        a = self.headers.get("Authorization", "")
        return a == "Basic " + base64.b64encode(f"{USER}:{PW}".encode()).decode()
    def do_GET(self):
        if not self.authed(): return self.send(401, b"no")
        p = self.path
        if p == "/policy":
            links = "".join(f'<a href="/Policy/Trace/{n}">{n}</a><br>' for n in sorted(TRACE))
            return self.send(200, f"<html>{links}</html>".encode(), {"Content-Type": "text/html"})
        if p.startswith("/Policy/Trace/"):
            n = p.rsplit("/", 1)[1]
            if n not in TRACE: return self.send(404, b"nf")
            b = TRACE[n].encode(); etag = '"%d"' % len(b)
            rg = self.headers.get("Range")
            if rg:
                off = int(rg.split("=")[1].rstrip("-"))
                if off >= len(b):
                    return self.send(304 if self.headers.get("If-None-Match") == etag else 416, b"", {"Content-Range": f"bytes */{len(b)}", "ETag": etag})
                return self.send(206, b[off:], {"Content-Range": f"bytes {off}-{len(b)-1}/{len(b)}", "ETag": etag})
            return self.send(200, b, {"ETag": etag, "Last-Modified": "Thu, 15 Oct 2026 00:00:00 GMT"})
        if p == "/Accesslog/statistics":
            return self.send(200, b'<html><a href="/Accesslog/statistics/main">main</a><a href="/Accesslog/statistics/ssl_log">ssl_log</a></html>')
        if p.startswith("/Accesslog/tail-f/"):
            return self.send(200, LOG.encode())
        self.send(404, b"nf")
    def do_POST(self):
        if not self.authed(): return self.send(401, b"no")
        n = int(self.headers.get("Content-Length") or 0); self.rfile.read(n)
        if self.path.startswith("/Policy/Delete-Trace/"):
            TRACE.pop(self.path.rsplit("/", 1)[1], None); return self.send(200, b"ok")
        self.send(404, b"nf")
    def do_HEAD(self): self.send(404)
def grow():
    time.sleep(1); 
http.server.ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
