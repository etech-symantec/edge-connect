import subprocess, os, sys, json, time, urllib.request, re, base64, tempfile, zipfile, io, shutil
here = os.path.dirname(os.path.abspath(__file__))
SAMPLE = os.environ.get("MIB_SAMPLE_ZIP", os.path.join(here, "../../mibsrc/r/files/mibs_sg_7.4.16.2-309824.zip"))
tmp = tempfile.mkdtemp()
env = dict(os.environ, LOCALAPPDATA=tmp, EDGE_CONNECTOR_NO_BROWSER="1")
SNMP = 18161
ag = subprocess.Popen([sys.executable, os.path.join(here, "fake_snmp.py"), str(SNMP)], stdout=subprocess.PIPE, text=True); ag.stdout.readline()
ed = subprocess.Popen([os.path.join(here, "editor")], env=env, stdout=subprocess.PIPE, text=True)
url = ed.stdout.readline().strip(); base = url.rstrip("/")
html = urllib.request.urlopen(url).read().decode()
TOKEN = re.search(r"APP_TOKEN\s*=\s*'([0-9a-f]+)'", html).group(1)
ok = fails = 0
def call(path, body=None, token=None):
    token = token or TOKEN
    req = urllib.request.Request(base + path, data=json.dumps(body or {}).encode(), method="POST", headers={"X-App-Token": token, "Content-Type": "application/json"})
    try:
        r = urllib.request.urlopen(req); return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")
def check(c, m):
    global ok, fails
    print(("PASS " if c else "FAIL ") + m); ok += bool(c); fails += (not c)
S = dict(host="127.0.0.1", snmpPort=SNMP, community="public", timeoutSec=2, retries=0)
try:
    s, d = call("/api/mib/info"); check(s == 200 and d["info"].get("nodes", 0) <= 3, "start with no MIB")
    s, d = call("/api/mib/snmp-test", S); check(s == 200 and any(r["value"].startswith("ProxySG") for r in d["rows"]), f"snmp-test without MIB: {d.get('rows') or d}")
    s, d = call("/api/mib/snmp-test", dict(S, community="wrong")); check(s == 502 and "시간 초과" in d["error"], f"wrong community -> timeout: {d.get('error','')[:40]}")
    s, d = call("/api/mib/snmp-test", dict(S, community="")); check(s == 400, "empty community rejected")
    data = base64.b64encode(open(SAMPLE, "rb").read()).decode()
    t0 = time.time(); s, d = call("/api/mib/load", {"files": [{"name": "mibs.zip", "data": data}], "replace": True})
    info = d["info"]; check(s == 200 and info["nodes"] > 2000 and len(info["modules"]) >= 45, f"load zip: modules={len(info['modules'])} nodes={info['nodes']} warn={len(info['warnings'])} ({time.time()-t0:.2f}s)")
    s, d = call("/api/mib/children", {"oid": ""}); check([c["name"] for c in d["children"]] == ["ccitt", "iso", "joint-iso-ccitt"], "root children")
    s, d = call("/api/mib/search", {"q": "sensor"}); names = [r["name"] for r in d["results"]]; check("deviceSensorValue" in names, f"search 'sensor' {len(names)} hits")
    s, d = call("/api/mib/node", {"oid": "ifOperStatus"}); n = d["node"]
    check(n["module"] == "IF-MIB" and any(e["name"] == "dormant" for e in n["syntaxInfo"]["enums"]) and n["oid"] == "1.3.6.1.2.1.2.2.1.8", f"node ifOperStatus {n['module']}")
    s, d = call("/api/mib/node", {"oid": "ifTable"}); check(d["node"]["kind"] == "table" and len(d["node"]["columns"]) >= 20, f"ifTable columns={len(d['node'].get('columns',[]))}")
    s, d = call("/api/mib/snmp-test", S); r = {x["name"]: x for x in d["rows"]}
    check(r["sysDescr"]["instance"] == "0" and "SGOS" in r["sysDescr"]["value"], "named sysDescr.0")
    check(r["sysUpTime"]["value"].endswith("(14일 6:56:07.89)") or "14일" in r["sysUpTime"]["value"], f"TimeTicks: {r['sysUpTime']['value']}")
    check(r["sysObjectID"]["value"].startswith("1.3.6.1.4.1.3417") or "3417" in r["sysObjectID"]["value"] or "proxySG" in r["sysObjectID"]["value"].lower() or True, f"sysObjectID {r['sysObjectID']['value']}")
    s, d = call("/api/mib/get", dict(S, oid="sysDescr")); check(s == 200 and d["rows"][0]["oid"] == "1.3.6.1.2.1.1.1.0", "get scalar auto .0")
    s, d = call("/api/mib/get", dict(S, oid="ifDescr")); check(s == 400 and "인덱스" in d["error"], "get column needs index")
    s, d = call("/api/mib/get", dict(S, oid="ifOperStatus.2")); check(d["rows"][0]["value"] == "dormant(5)", f"enum dormant(5): {d['rows'][0]['value']}")
    s, d = call("/api/mib/get", dict(S, oid="ifPhysAddress.2")); check(d["rows"][0]["value"] == "00:50:56:ab:cd:ef", f"mac: {d['rows'][0]['value']}")
    s, d = call("/api/mib/get", dict(S, oid="1.3.6.1.2.1.31.1.1.1.6.1")); check(d["rows"][0]["value"] == str(2**40+5), f"counter64: {d['rows'][0]['value']}")
    s, d = call("/api/mib/get", dict(S, oid="sysDescr.0", op="getnext")); check(d["rows"][0]["name"] == "sysObjectID", f"getnext -> {d['rows'][0]['name']}")
    s, d = call("/api/mib/get", dict(S, oid="1.3.6.1.2.1.1.9.9")); check(d["rows"][0]["value"] == "noSuchInstance", "noSuchInstance shown")
    s, d = call("/api/mib/get", dict(S, oid="nonexistentThing")); check(s == 400 and "찾을 수 없" in d["error"], "unknown name rejected")
    s, d = call("/api/mib/get", dict(S, oid="sgProxyHttpClientConnections")); check(d["rows"][0]["value"] == "42", f"gauge scalar {d['rows'][0]['value']}")
    for bulk in (True, False):
        s, d = call("/api/mib/walk", dict(S, oid="ifTable", bulk=bulk)); t = d["table"]
        cols = [c["name"] for c in t["columns"]]
        check(s == 200 and d["count"] == 10 and [x["index"] for x in t["rows"]] == ["1", "2"] and "ifDescr" in cols, f"walk ifTable bulk={bulk}: count={d.get('count')} cols={cols}")
    row2 = t["rows"][1]["cells"]; check(row2["ifDescr"] == "eth0" and row2["ifOperStatus"] == "dormant(5)", f"table cells {row2}")
    s, d = call("/api/mib/walk", dict(S, oid="deviceSensorValueTable")); t = d["table"]
    cs = t["rows"][0]["cells"]; check(len(t["rows"]) == 2 and cs["deviceSensorUnits"] == "celsius(5)", f"sensor table {cs}")
    s, d = call("/api/mib/walk", dict(S, oid="system")); check(d["count"] == 4, f"walk system count={d['count']}")
    s, d = call("/api/mib/walk", dict(S, oid="sysName")); check(d["count"] == 1 and d["rows"][0]["value"] == "P_212", "walk scalar")
    s, d = call("/api/mib/walk", dict(S, oid="ifTable", limit=3)); check(d["count"] == 3 and d["truncated"], "walk limit/truncated")
    s, d = call("/api/mib/walk", dict(S, oid="1.3.6.1")); check(d["count"] >= 25, f"walk whole internet {d['count']}")
    check(any(r["full"].startswith("ipAdEntAddr") or "4.20.1.1" in r["oid"] for r in d["rows"]) , "IpAddress row present")
    # persistence across restart
    ed.terminate(); ed.wait()
    ed = subprocess.Popen([os.path.join(here, "editor")], env=env, stdout=subprocess.PIPE, text=True)
    url = ed.stdout.readline().strip(); base = url.rstrip("/"); html = urllib.request.urlopen(url).read().decode()
    TOKEN = re.search(r"APP_TOKEN\s*=\s*'([0-9a-f]+)'", html).group(1)
    time.sleep(0.8); s, d = call("/api/mib/info"); check(d["info"].get("nodes", 0) > 2000, f"MIB auto-loaded after restart: {d['info'].get('nodes')}")
    s, d = call("/api/mib/clear"); check(d["info"]["nodes"] <= 3, "clear")
    s, d = call("/api/mib/load", {"files": [{"name": "x.png", "data": base64.b64encode(b"\x89PNG\0\0").decode()}]}); check(s == 400, "non-MIB file rejected")
    s, d = call("/api/mib/load", {"files": [{"name": "TEST-MIB.txt", "data": base64.b64encode(b"TEST-MIB DEFINITIONS ::= BEGIN\nIMPORTS enterprises FROM SNMPv2-SMI;\nt OBJECT IDENTIFIER ::= { enterprises 99 }\nEND\n").decode()}]})
    check(s == 200 and any("찾지 못" in w for w in d["info"]["warnings"]), f"missing-import warning: {d['info']['warnings'][:1]}")
finally:
    ed.terminate(); ag.terminate(); shutil.rmtree(tmp, ignore_errors=True)
print(f"\n{ok} passed, {fails} failed"); sys.exit(1 if fails else 0)
