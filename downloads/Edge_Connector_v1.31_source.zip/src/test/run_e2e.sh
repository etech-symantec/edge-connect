#!/bin/sh
cd "$(dirname "$0")"
rm -f state.json
python3 fake_mgmt.py 18082 &
MG=$!
EDGE_CONNECTOR_SSH_PATH="$PWD/fake_ssh.py" MOCK_STATE="$PWD/state.json" EDGE_CONNECTOR_NO_BROWSER=1 ./editor > url.txt 2> server_err.txt &
ED=$!
sleep 1.5
timeout 560 node e2e.mjs > e2e_out.txt 2>&1
kill $ED $MG 2>/dev/null
echo DONE >> e2e_out.txt
