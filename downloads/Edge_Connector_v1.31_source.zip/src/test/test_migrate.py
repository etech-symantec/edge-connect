import subprocess, os, sys, tempfile, shutil, time, urllib.request
here = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.mkdtemp()
old = os.path.join(tmp, "ProxySGPolicyEditor"); os.makedirs(os.path.join(old, "mibs"))
open(os.path.join(old, "known_hosts"), "w").write("host key\n")
open(os.path.join(old, "mibs", "X-MIB.txt"), "w").write("X-MIB DEFINITIONS ::= BEGIN\nEND\n")
ed = subprocess.Popen([os.path.join(here, "editor")], env=dict(os.environ, LOCALAPPDATA=tmp, EDGE_CONNECTOR_NO_BROWSER="1"), stdout=subprocess.PIPE, text=True)
url = ed.stdout.readline().strip(); time.sleep(1.0)
html = urllib.request.urlopen(url).read().decode()
new = os.path.join(tmp, "EdgeConnector")
res = [os.path.exists(os.path.join(new, "known_hosts")), os.path.exists(os.path.join(new, "mibs", "X-MIB.txt")), not os.path.exists(old), "<title>Edge Connector</title>" in html, "ProxySG Policy Trace Editor" not in html]
ed.terminate(); shutil.rmtree(tmp, ignore_errors=True)
print("migrate:", res); sys.exit(0 if all(res) else 1)
