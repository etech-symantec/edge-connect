import { JSDOM, VirtualConsole } from "jsdom";
import fs from "fs";
const url = fs.readFileSync("url.txt", "utf8").trim();
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
let fails = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };
const vc = new VirtualConsole();
vc.on("jsdomError", e => { const t = String(e.message || e); if (!/Not implemented/.test(t)) console.log("JSDOMERR", t.slice(0, 300), e.detail ? String(e.detail).slice(0,300) : ""); });
const dom = await JSDOM.fromURL(url, { runScripts: "dangerously", resources: "usable", pretendToBeVisual: true, virtualConsole: vc });
const w = dom.window, d = w.document;
w.fetch = (u, o) => fetch(new URL(u, w.location.href), o);
w.Element.prototype.scrollIntoView = () => {}; w.confirm = () => true; w.alert = () => {};
await sleep(300);
await w.systemCheck();
const $ = (id) => d.getElementById(id);
const set = (id, v) => { $(id).value = v; $(id).dispatchEvent(new w.Event("input")); $(id).dispatchEvent(new w.Event("change")); };
const check = (id, v) => { $(id).checked = v; $(id).dispatchEvent(new w.Event("change")); };
const waitFor = async (fn, ms = 60000, what = "") => { const t = Date.now(); while (Date.now() - t < ms) { try { if (fn()) return true; } catch {} await sleep(120); } console.log("TIMEOUT waiting:", what); return false; };
const disp = (el) => w.getComputedStyle(el).display;
const pageActive = (n) => $("page-" + n).classList.contains("active");
const modalOpen = () => $("adminModal").classList.contains("show");

ok(d.title === "Edge Connector", "title: " + d.title);
ok(await waitFor(() => $("sshState").textContent.includes("준비됨"), 8000, "system"), "OpenSSH 준비됨 표시: " + $("sshState").textContent);
ok(disp($("sidePolicyGroup")) === "none" && disp($("sideTraceGroup")) === "none" && disp($("sideAdminGroup")) === "none", "모드 선택 전에는 3/4단계 메뉴 숨김");
ok(d.querySelector("#sideModeGroup .navKicker").textContent === "STEP 2", "STEP 2 = 기능 선택");

// ---- STEP 1 공통 장비 설정
set("host", "127.0.0.1"); set("port", "22"); set("username", "admin"); set("password", "sshpw");
check("samePw", false); set("enablePassword", "enpw");
set("mgmtProtocol", "http"); set("mgmtPort", "18082");
$("testConnBtn").click();
ok(await waitFor(() => /SSH 연결 성공/.test($("deviceStatus").textContent), 30000, "ssh test"), "STEP1 SSH 연결 확인 -> " + $("deviceStatus").textContent.slice(0, 60));
$("testMgmtBtn").click();
ok(await waitFor(() => /Management 연결 성공/.test($("deviceStatus").textContent), 30000, "mgmt test"), "STEP1 Web Console 연결 확인 -> " + $("deviceStatus").textContent.slice(0, 80));

// ---- STEP 2: 기능 선택 페이지
d.querySelector('#sideModeGroup summary').click();
ok(pageActive("mode") && !pageActive("device"), "STEP 2 클릭 -> 기능 선택 페이지");
ok($("modeDevicePill").textContent.includes("127.0.0.1"), "기능 선택 페이지에 STEP1 장비 표시");

// ---- Admin 모드
$("modeCardAdmin").click();
ok(pageActive("admin") && d.body.dataset.mode === "admin", "Admin 카드 -> Admin 페이지");
ok(disp($("sideAdminGroup")) !== "none" && disp($("sidePolicyGroup")) === "none", "Admin 모드: 관리자 메뉴만 표시");
ok(d.querySelector("#sideAdminGroup .navKicker").textContent === "STEP 3", "Admin 은 STEP 3");
set("adRealm", "test");
$("adListBtn").click();
ok(await waitFor(() => d.querySelectorAll("#adUsers tr.clickable").length === 2 && !$("adListBtn").disabled, 60000, "adlist"), "Admin 사용자 목록 2명");
ok([...d.querySelectorAll("#adUsers tr td:first-child")].map(x => x.textContent).join() === "admin1,u2", "목록: admin1,u2");
ok($("adUsersLabel").textContent.includes("sgusers"), "라벨: " + $("adUsersLabel").textContent);
ok(!$("adLog").textContent.includes("PBKDF2") && !$("adLog").textContent.includes("sshpw"), "로그에 해시/SSH 비밀번호 없음");
ok(!!d.querySelector("#adLog .cmd"), "로그 색상 클래스(cmd)");
d.querySelectorAll("#adUsers tr")[1].click(); ok($("adUser").value === "u2", "행 클릭 -> 사용자명");

// 비밀번호 변경
d.querySelector('#adTabs [data-admode=passwd]').click();
ok($("adRunBtn").textContent === "비밀번호 변경 실행" && $("adGroups").closest("[data-ad]").classList.contains("adminHidden"), "비밀번호 변경 모드 UI");
set("adPass", "Changed#Pw9"); set("adPass2", "Changed#Pw9");
$("adRunBtn").click();
ok(await waitFor(modalOpen, 5000, "pw modal"), "비밀번호 변경 확인창");
$("adminModalOk").click();
ok(await waitFor(() => /비밀번호를 변경했습니다/.test($("adLog").textContent) && !$("adRunBtn").disabled, 60000, "passwd"), "비밀번호 변경 완료");
ok(!$("adLog").textContent.includes("Changed#Pw9"), "로그에 새 비밀번호 없음");

// 관리자 추가 + local policy
d.querySelector('#adTabs [data-admode=add]').click();
set("adUser", "admin3"); set("adPass", "NewPass123"); set("adPass2", "NewPass123"); set("adGroups", "sgadmins");
$("adPreviewBtn").click();
ok(await waitFor(modalOpen, 60000, "preview"), "CPL 미리보기 창");
ok($("adminModalBody").textContent.includes('group="sgadmins" allow') && $("adminModalBody").textContent.includes("authenticate(test)"), "미리보기에 CPL 내용");
$("adminModalOk").click();
await sleep(200);
$("adRunBtn").click();
ok(await waitFor(modalOpen, 60000, "add modal"), "추가 확인창(최종 정책 포함)");
ok($("adminModalBody").textContent.includes("admin3") && $("adminModalBody").textContent.includes("BEGIN proxysg-admin-tool"), "확인창에 요약 + 최종 정책");
ok(!!d.querySelector("#adminModalBody .added"), "새 블록 하이라이트");
$("adminModalOk").click();
ok(await waitFor(() => /Admin 규칙을 설치/.test($("adLog").textContent) && !$("adRunBtn").disabled, 90000, "add done"), "추가 + Admin 규칙 설치 완료");
ok([...d.querySelectorAll("#adUsers tr td:first-child")].map(x => x.textContent).includes("admin3"), "추가 후 목록에 admin3");
ok(!$("adLog").textContent.includes("NewPass123") && $("adPass").value === "", "로그/입력칸에 비밀번호 남지 않음");
await sleep(500); ok(!modalOpen(), "확인창이 다시 뜨지 않음");

// 검증 오류
set("adGroups", ""); set("adPass", "abc"); set("adPass2", "abc"); set("adUser", "admin4");
$("adRunBtn").click();
ok(await waitFor(() => !$("adErr").classList.contains("adminHidden") && /그룹/.test($("adErr").textContent), 60000, "valerr") , "검증 오류: " + $("adErr").textContent);
if (modalOpen()) $("adminModalCancel").click();
await waitFor(() => !modalOpen() && !$("adRunBtn").disabled, 20000, "settle");

// 삭제
d.querySelector('#adTabs [data-admode=delete]').click();
set("adUser", "u2");
ok($("adRunBtn").className.includes("danger"), "삭제 버튼 강조");
$("adRunBtn").click();
ok(await waitFor(modalOpen, 5000, "del modal") && $("adminModalTitle").textContent === "삭제 확인", "삭제 확인창");
$("adminModalOk").click();
ok(await waitFor(() => /삭제했습니다/.test($("adLog").textContent) && !$("adRunBtn").disabled, 60000, "delete"), "삭제 완료");
ok(![...d.querySelectorAll("#adUsers tr td:first-child")].map(x => x.textContent).includes("u2"), "삭제 후 목록에서 u2 사라짐");

// ---- Trace 모드로 전환
d.querySelector('#sideModeGroup summary').click();
$("modeCardTrace").click();
ok(pageActive("policy") && d.body.dataset.mode === "trace", "Trace 카드 -> 정책설정 페이지");
ok(disp($("sidePolicyGroup")) !== "none" && disp($("sideAdminGroup")) === "none", "Trace 모드: 정책/Trace 메뉴 표시, Admin 숨김");
ok(d.querySelector("#sidePolicyGroup .navKicker").textContent === "STEP 3" && d.querySelector("#sideTraceGroup .navKicker").textContent === "STEP 4", "Trace 는 STEP 3/4");
set("sourceIps", "10.1.1.9"); set("destinations", "example.com");
ok($("generatedTrace").value.includes("trace.request(yes)") && $("generatedTrace").value.includes("client.address=10.1.1.9"), "Trace CPL 생성");
$("previewBtn").click();
ok(await waitFor(() => /최종 정책 생성 완료/.test($("policyStatusText").textContent) || /bad/.test($("policyStatus").className), 60000, "trace preview"), "최종 정책 생성: " + $("policyStatusText").textContent.slice(0, 80));
ok($("finalPreview").textContent.includes("inline policy local EOF_POLICY_EDITOR_") && $("finalPreview").textContent.includes("trace.destination"), "최종 정책 미리보기");
ok(!!d.querySelector("#finalPreview .finalAdded"), "추가 CPL 연두색 하이라이트");
check("confirmApply", true);
ok(!$("applyBtn").disabled, "동의 후 적용 버튼 활성화");
$("applyBtn").click();
ok(await waitFor(() => /재검증 완료/.test($("policyStatusText").textContent) || /bad/.test($("policyStatus").className), 90000, "trace apply"), "적용 + 재검증: " + $("policyStatusText").textContent.slice(0, 80));
const st = JSON.parse(fs.readFileSync("state.json", "utf8"));
ok(st.policy.includes("trace.destination") && st.policy.includes("BEGIN proxysg-admin-tool"), "장비 정책: Trace + (Admin 블록 보존)");
ok(!$("removeTracePolicyBtn").disabled, "Trace 제거 버튼 활성화");

// Trace 조회
d.querySelector('#sideTraceGroup summary').click();
ok(pageActive("trace"), "STEP 4 Trace 조회 페이지");
ok(await waitFor(() => d.querySelectorAll("#sideTraceFiles button.sideItem").length >= 1, 30000, "trace list"), "Trace 목록 조회: " + [...d.querySelectorAll("#sideTraceFiles .sideText")].map(x => x.textContent).join());
d.querySelector("#sideTraceFiles button.sideItem").click();
ok(await waitFor(() => $("traceRaw").textContent.includes("start transaction"), 40000, "trace read"), "Trace 파일 선택 -> 원문 조회");
ok(await waitFor(() => Number($("statSessions").textContent) >= 1, 15000, "analysis"), "Trace 분석 세션 수: " + $("statSessions").textContent);

// Trace 제거
d.querySelector('#sidePolicyGroup summary').click();
$("removeTracePolicyBtn").click();
ok(await waitFor(() => /제거한 최종 정책을 생성/.test($("policyStatusText").textContent) || /bad/.test($("policyStatus").className), 60000, "remove prep"), "제거본 생성: " + $("policyStatusText").textContent.slice(0, 80));
ok(!$("finalPreview").textContent.includes("trace.destination") && $("finalPreview").textContent.includes("BEGIN proxysg-admin-tool"), "제거본: Trace 없음, Admin 블록 유지");
check("confirmApply", true); $("applyBtn").click();
ok(await waitFor(() => /재검증 완료/.test($("policyStatusText").textContent) || /bad/.test($("policyStatus").className), 90000, "remove apply"), "제거본 적용");
const st2 = JSON.parse(fs.readFileSync("state.json", "utf8"));
ok(!st2.policy.includes("trace.destination") && st2.policy.includes("authenticate(test)"), "장비 정책에서 Trace 만 제거됨");

// 영어 전환
$("langEnBtn").click(); await sleep(400);
ok(/Select Function/.test(d.querySelector("#sideModeGroup .navLabel").textContent) , "English: " + d.querySelector("#sideModeGroup .navLabel").textContent);
console.log(fails ? `\n${fails} FAILED` : "\nALL E2E OK");
process.exit(fails ? 1 : 0);
