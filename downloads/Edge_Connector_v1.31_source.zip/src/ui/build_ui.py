import json, re
src = open("ui_original_v1.28.html", encoding="utf-8").read()
h = src

def rep(old, new, count=1):
    global h
    assert h.count(old) >= 1, "missing: " + old[:80]
    h = h.replace(old, new, count)

# 1) 제목/버전
rep("<title>ProxySG Policy Trace Editor</title>", "<title>Edge Connector</title>")
rep('<div class="brandTitle">ProxySG Trace</div>', '<div class="brandTitle">Edge Connector</div>')
rep("Policy Trace Editor · v1.28", "Trace · Admin · MIB · v1.31")

# 2) 사이드바: STEP 2 기능 선택 삽입, 기존 2/3 단계를 3/4 단계(Trace 모드)로
rep('<details class="navSection stepSection" id="sidePolicyGroup" data-step="2" open>',
    '''<details class="navSection stepSection" id="sideModeGroup" data-step="2" open>
        <summary class="navBtn" data-page="mode">
          <span class="navStepCircle">2</span>
          <span class="navCopy"><span class="navKicker">STEP 2</span><span class="navMain"><span class="navIcon">🧭</span><span class="navLabel">기능 선택</span></span></span>
          <b class="navBadge" id="modeBadge">-</b>
        </summary>
        <div class="navInlineList">
          <button class="sideItem" id="sideModeTrace" type="button"><span class="sideDot"></span><span class="sideText">🔎 Trace 분석</span></button>
          <button class="sideItem" id="sideModeAdmin" type="button"><span class="sideDot"></span><span class="sideText">🛡️ Admin 관리</span></button>
          <button class="sideItem" id="sideModeMib" type="button"><span class="sideDot"></span><span class="sideText">📡 MIB 조회</span></button>
        </div>
      </details>
      <details class="navSection stepSection modeTrace" id="sidePolicyGroup" data-step="3" open>''')
i = h.index('id="sidePolicyGroup"'); j = h.index("</summary>", i)
seg = h[i:j]
seg2 = seg.replace('<span class="navStepCircle">2</span>', '<span class="navStepCircle">3</span>').replace('STEP 2', 'STEP 3')
assert seg != seg2
h = h[:i] + seg2 + h[j:]
rep('<details class="navSection stepSection" id="sideTraceGroup" data-step="3" open>',
    '<details class="navSection stepSection modeTrace" id="sideTraceGroup" data-step="4" open>')
i = h.index('id="sideTraceGroup"'); j = h.index("</summary>", i)
seg = h[i:j]
seg2 = seg.replace('<span class="navStepCircle">3</span>', '<span class="navStepCircle">4</span>').replace('STEP 3', 'STEP 4')
assert seg != seg2
h = h[:i] + seg2 + h[j:]
# Admin 단계 (3단계)는 Trace 조회 그룹 뒤에 추가
k = h.index('id="sideTraceGroup"'); end = h.index("</details>", k) + len("</details>")
admin_group = '''
      <details class="navSection stepSection modeAdmin" id="sideAdminGroup" data-step="3" open>
        <summary class="navBtn" data-page="admin">
          <span class="navStepCircle">3</span>
          <span class="navCopy"><span class="navKicker">STEP 3</span><span class="navMain"><span class="navIcon">🛡️</span><span class="navLabel">관리자 관리</span></span></span>
        </summary>
      </details>'''
mib_group = '''
      <details class="navSection stepSection modeMib" id="sideMibGroup" data-step="3" open>
        <summary class="navBtn" data-page="mib">
          <span class="navStepCircle">3</span>
          <span class="navCopy"><span class="navKicker">STEP 3</span><span class="navMain"><span class="navIcon">📡</span><span class="navLabel">MIB 조회</span></span></span>
        </summary>
      </details>'''
h = h[:end] + admin_group + mib_group + h[end:]

# 3) 페이지 추가 (</main> 직전)
pages = open("addon_pages.html", encoding="utf-8").read() + open("addon_mib.html", encoding="utf-8").read()
rep("  </main>", pages + "\n  </main>")

# 4) CSS
css = open("addon_css.css", encoding="utf-8").read() + open("addon_mib.css", encoding="utf-8").read()
last = h.rindex("</style>")
h = h[:last] + css + "\n" + h[last:]

# 5) 영어 사전
pairs = json.load(open("addon_i18n.json", encoding="utf-8"))
pairs.update(json.load(open("addon_i18n_mib.json", encoding="utf-8")))
ent = "".join("%s:%s," % (json.dumps(k, ensure_ascii=False), json.dumps(v, ensure_ascii=False)) for k, v in pairs.items())
rep("const E={", "const E={" + ent, 1)

# 6) 스크립트
js = open("addon.js", encoding="utf-8").read() + "\n" + open("addon_mib.js", encoding="utf-8").read()
tail = h.rindex("</body>")
h = h[:tail] + "<script>\n" + js + "\n</script>\n" + h[tail:]

# 7) 가이드 문구(장비설정 페이지): 두 기능 공통 안내
rep("<div class=\"pageDesc\">좌측 + 버튼으로 장비 프로필을 만든 뒤 SSH와 Management Console 정보를 입력하면 자동 저장됩니다.</div>",
    "<div class=\"pageDesc\">좌측 + 버튼으로 장비 프로필을 만든 뒤 SSH와 Management Console 정보를 입력하면 자동 저장됩니다. 이 설정은 STEP 2 에서 선택하는 Trace 분석과 Admin 관리가 함께 사용합니다.</div>")

# 8) 최종 정책 미리보기: 서버가 빈 줄 정리(normalize)한 본문에서도 추가 CPL 을 찾아 연두색으로 표시
rep("const idx=text.indexOf(state.traceCpl);if(idx>=0){box.innerHTML=esc(text.slice(0,idx))+`<span class=\"finalAdded\">${esc(state.traceCpl)}</span>`+esc(text.slice(idx+state.traceCpl.length));return}",
    "const needle=normalizePolicyFormatting(state.traceCpl),idx=text.indexOf(needle);if(idx>=0){box.innerHTML=esc(text.slice(0,idx))+`<span class=\"finalAdded\">${esc(needle)}</span>`+esc(text.slice(idx+needle.length));return}")

# 9) 번역되지 않은 한글 속성(title/placeholder)이 MutationObserver 무한 루프를 일으키지 않도록 방지
rep("if(lang==='en'&&/[가-힣]/.test(v)){translating=true;el.setAttribute(a,translate(v));translating=false}",
    "if(lang==='en'&&/[가-힣]/.test(v)&&translate(v)!==v){translating=true;el.setAttribute(a,translate(v));translating=false}")
# 10) 언어 설정 저장 키: 새 이름 사용(이전 키 값은 한 번 읽어 이어받음)
rep("const LANG_KEY='proxysgPolicyEditorLanguage';","const LANG_KEY='edgeConnectorLanguage';try{if(!localStorage.getItem(LANG_KEY)&&localStorage.getItem('proxysgPolicyEditorLanguage'))localStorage.setItem(LANG_KEY,localStorage.getItem('proxysgPolicyEditorLanguage'))}catch(e){}")
open("web/index.html", "w", encoding="utf-8").write(h)
print("built", len(h))
