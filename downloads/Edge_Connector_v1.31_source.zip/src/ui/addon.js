// ===== v1.29: STEP 2 기능 선택 + Admin 관리 =====
(() => {
  const MODE_COOKIE = 'psg129_mode', AD_COOKIE = 'psg129_admin';
  const g = (id) => document.getElementById(id);
  const val = (id) => (g(id).value || '').trim();
  const escH = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  let adMode = 'add', adBusy = false;

  // ---------- 모드(Trace / Admin) ----------
  const MODE_LABEL = { trace: 'Trace', admin: 'Admin', mib: 'MIB' };
  function setMode(m) {
    if (m !== 'trace' && m !== 'admin' && m !== 'mib') m = '';
    document.body.dataset.mode = m;
    try { cookieSet(MODE_COOKIE, m); } catch {}
    g('modeCardTrace').classList.toggle('selected', m === 'trace');
    g('modeCardAdmin').classList.toggle('selected', m === 'admin');
    g('modeCardMib').classList.toggle('selected', m === 'mib');
    g('modeBadge').textContent = MODE_LABEL[m] || '-';
    g('sideModeTrace').classList.toggle('active', m === 'trace');
    g('sideModeAdmin').classList.toggle('active', m === 'admin');
    g('sideModeMib').classList.toggle('active', m === 'mib');
  }
  const PAGE_STEP = { device: 1, mode: 2, policy: 3, trace: 4, admin: 3, mib: 3 };
  function updateSteps(name) {
    const cur = PAGE_STEP[name] || 1;
    document.querySelectorAll('.stepSection').forEach((x) => {
      const st = Number(x.dataset.step), page = x.querySelector('summary')?.dataset.page;
      x.classList.toggle('current', page === name);
      x.classList.toggle('past', st < cur);
    });
  }
  function syncDevicePills() {
    const h = (g('deviceMini').textContent || '').trim() || '장비 미선택';
    g('modeDevicePill').textContent = h; g('adminDevicePill').textContent = h; g('mibDevicePill').textContent = h;
  }
  const origSwitch = window.switchPage;
  window.switchPage = function (name, skip) {
    if (name === 'policy' || name === 'trace') setMode('trace');
    else if (name === 'admin') setMode('admin');
    else if (name === 'mib') setMode('mib');
    origSwitch(name, skip);
    updateSteps(name);
    syncDevicePills();
    if (name === 'mode') g('modeBadge').textContent = MODE_LABEL[document.body.dataset.mode] || '-';
  };
  g('modeCardTrace').onclick = () => { setMode('trace'); switchPage('policy'); };
  g('modeCardAdmin').onclick = () => { setMode('admin'); switchPage('admin'); };
  g('modeCardMib').onclick = () => { setMode('mib'); switchPage('mib'); };
  g('sideModeMib').onclick = (e) => { e.preventDefault(); e.stopPropagation(); setMode('mib'); switchPage('mib'); };
  g('sideModeTrace').onclick = (e) => { e.preventDefault(); e.stopPropagation(); setMode('trace'); switchPage('policy'); };
  g('sideModeAdmin').onclick = (e) => { e.preventDefault(); e.stopPropagation(); setMode('admin'); switchPage('admin'); };

  // ---------- Admin: 화면 상태 ----------
  function applyAdMode() {
    document.querySelectorAll('#adTabs button').forEach((b) => b.classList.toggle('active', b.dataset.admode === adMode));
    document.querySelectorAll('#page-admin [data-ad]').forEach((el) => {
      el.classList.toggle('adminHidden', !el.dataset.ad.split(' ').includes(adMode));
    });
    const run = g('adRunBtn');
    run.textContent = adMode === 'add' ? '관리자 추가 실행' : adMode === 'passwd' ? '비밀번호 변경 실행' : '관리자 삭제 실행';
    run.className = (adMode === 'delete' ? 'danger' : 'primary') + ' compactAction';
    g('adPassLabel').textContent = adMode === 'passwd' ? '새 비밀번호' : '비밀번호';
    g('adPolicyOpts').classList.toggle('adminHidden', !g('adPolicyOn').checked);
    g('adPreviewBtn').classList.toggle('adminHidden', adMode !== 'add' || !g('adPolicyOn').checked);
    g('adErr').classList.add('adminHidden');
  }
  document.querySelectorAll('#adTabs button').forEach((b) => b.onclick = () => { adMode = b.dataset.admode; applyAdMode(); });
  g('adPolicyOn').onchange = () => { applyAdMode(); saveAd(); };

  const AD_FIELDS = ['adRealm', 'adUserlist', 'adGroups'], AD_CHECKS = ['adCreateGroup', 'adCreateRealm', 'adPolicyOn', 'adPolicyAuth'];
  function saveAd() {
    const o = { access: g('adAccess').value };
    AD_FIELDS.forEach((k) => o[k] = g(k).value); AD_CHECKS.forEach((k) => o[k] = g(k).checked);
    try { jset(AD_COOKIE, o); } catch {}
  }
  function loadAd() {
    let o = {}; try { o = jget(AD_COOKIE, {}) || {}; } catch {}
    AD_FIELDS.forEach((k) => { if (typeof o[k] === 'string') g(k).value = o[k]; });
    AD_CHECKS.forEach((k) => { if (typeof o[k] === 'boolean') g(k).checked = o[k]; });
    if (o.access === 'RO' || o.access === 'RW') g('adAccess').value = o.access;
  }
  [...AD_FIELDS, ...AD_CHECKS, 'adAccess'].forEach((k) => g(k).addEventListener('change', saveAd));
  AD_FIELDS.forEach((k) => g(k).addEventListener('input', saveAd));

  function adParams() {
    return {
      ...conn(), realm: val('adRealm'), userlist: val('adUserlist'), newUser: val('adUser'),
      newPass: g('adPass').value, newPass2: g('adPass2').value, groups: val('adGroups'),
      createGroup: g('adCreateGroup').checked, createRealm: g('adCreateRealm').checked,
      policyEnable: g('adPolicyOn').checked, policyAuth: g('adPolicyAuth').checked, access: g('adAccess').value,
    };
  }
  function setBusy(b) {
    adBusy = b;
    ['adListBtn', 'adPreviewBtn', 'adRunBtn'].forEach((id) => g(id).disabled = b);
    ['adListBtn', 'adRunBtn'].forEach((id) => g(id).classList.toggle('loading', b));
  }
  function showErr(msg) { const e = g('adErr'); e.classList.remove('adminHidden'); e.querySelector('span').textContent = msg; }

  // ---------- 로그 / 사용자 표 ----------
  function adLog(lines) {
    const box = g('adLog');
    const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
    (lines || []).forEach((line) => String(line).split('\n').forEach((ln) => {
      const t = ln.trim(); if (!t && !ln) return;
      const d = document.createElement('div');
      d.className = t.startsWith('>>>') ? 'cmd' : /^\[OK\]/.test(t) ? 'ok' : /^\[!\]/.test(t) ? 'warn' : /^\[X\]|^%/.test(t) ? 'err' : '';
      d.textContent = ln; box.appendChild(d);
    }));
    if (atBottom) box.scrollTop = box.scrollHeight;
  }
  g('adLogClear').onclick = () => { g('adLog').textContent = ''; };
  function showUsers(userlist, users) {
    const tb = g('adUsers'); tb.textContent = '';
    (users || []).forEach((u) => {
      const tr = document.createElement('tr'); tr.className = 'clickable';
      const a = document.createElement('td'), b = document.createElement('td');
      a.textContent = u.name; b.textContent = u.info; tr.append(a, b);
      tr.onclick = () => { g('adUser').value = u.name; };
      tb.appendChild(tr);
    });
    const l = g('adUsersLabel');
    if (users && users.length) { l.textContent = `${userlist} · ${users.length}명`; l.className = 'pill good'; }
    else { l.textContent = `${userlist || '-'} · 사용자를 인식하지 못함`; l.className = 'pill bad'; }
  }

  // ---------- 확인 창 ----------
  const modalHtml = `<div id="adminModal" class="policyModal" aria-hidden="true"><div class="policyModalPanel" role="dialog" aria-modal="true">
    <div class="policyModalHead"><div class="policyModalTitle" id="adminModalTitle"></div></div>
    <div class="adminModalBody" id="adminModalBody"></div>
    <div class="adminModalFoot"><button type="button" id="adminModalCancel" class="ghost">취소</button><button type="button" id="adminModalOk" class="primary">진행</button></div>
  </div></div>`;
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  function adConfirm({ title, html, ok = '진행', cancel = '취소', danger = false }) {
    return new Promise((resolve) => {
      const m = g('adminModal');
      g('adminModalTitle').textContent = title; g('adminModalBody').innerHTML = html;
      g('adminModalOk').textContent = ok; g('adminModalOk').className = danger ? 'danger' : 'primary';
      g('adminModalCancel').textContent = cancel; g('adminModalCancel').classList.toggle('adminHidden', !cancel);
      m.classList.add('show'); m.setAttribute('aria-hidden', 'false');
      const done = (v) => { m.classList.remove('show'); m.setAttribute('aria-hidden', 'true'); g('adminModalOk').onclick = g('adminModalCancel').onclick = null; document.removeEventListener('keydown', onKey); resolve(v); };
      const onKey = (e) => { if (e.key === 'Escape') done(false); };
      document.addEventListener('keydown', onKey);
      g('adminModalOk').onclick = () => done(true); g('adminModalCancel').onclick = () => done(false);
    });
  }
  function highlightPolicy(finalBlock) {
    let inBlock = false;
    return String(finalBlock || '').split('\n').map((ln) => {
      if (ln.startsWith(';; BEGIN proxysg-admin-tool')) inBlock = true;
      const h = inBlock ? `<span class="added">${escH(ln)}</span>` : escH(ln) + '\n';
      if (ln.startsWith(';; END proxysg-admin-tool')) inBlock = false;
      return h;
    }).join('');
  }
  function summaryText(p) {
    let s = `장비: ${p.host}:${p.port}\nRealm: ${p.realm || '-'}${adMode === 'add' && p.createRealm && p.realm ? '  (없으면 새로 생성)' : ''}\nlocal-user-list: ${p.userlist || '(realm 에서 자동 탐지)'}\n`;
    if (adMode === 'add') s += `추가 사용자: ${p.newUser}\n그룹: ${p.groups}\nAdmin 규칙(local policy): ${p.policyEnable ? '설치 - ' + (p.access === 'RO' ? '읽기 전용' : '읽기/쓰기') : '설치 안 함'}\n\nProxySG 설정이 변경됩니다.`;
    if (adMode === 'passwd') s += `대상 사용자: ${p.newUser}\n\n이 사용자의 비밀번호를 변경합니다.`;
    if (adMode === 'delete') s += `삭제할 사용자: ${p.newUser}\n\n이 관리자 계정을 영구 삭제합니다. 되돌릴 수 없습니다.\n(console 계정/시리얼 접속은 영향 없음)`;
    return s;
  }

  // ---------- API 호출 ----------
  async function call(path, p) {
    try { return await api(path, { method: 'POST', body: JSON.stringify(p) }); }
    catch (e) { if (e.details && e.details.log) adLog(e.details.log); throw e; }
  }
  async function adList() {
    if (adBusy) return; g('adErr').classList.add('adminHidden');
    try {
      setBusy(true); adLog(['[*] 사용자 목록 조회 중...']);
      const d = await call('/api/admin/list-users', adParams());
      adLog(d.log); showUsers(d.userlist, d.users);
      if (!document.getElementById('adUserlist').value && d.userlist) { /* 자동 탐지 결과는 입력칸에 채우지 않는다 */ }
    } catch (e) { showErr(e.message); toast(e.message, 'bad'); adLog(['[X] ' + e.message]); }
    finally { setBusy(false); }
  }
  async function adPlan(p) {
    const d = await call('/api/admin/plan', p); return d;
  }
  async function adPreview() {
    if (adBusy) return; g('adErr').classList.add('adminHidden');
    try {
      setBusy(true);
      const p = adParams(); adLog(['[*] Admin 규칙 미리보기를 만드는 중...']);
      const d = await adPlan(p);
      const html = `<b>추가될 Admin 규칙(CPL)</b>\n<span class="added">${escH(d.cpl)}</span>` +
        (d.finalBlock ? `\n<b>적용될 최종 Local Policy</b> (연두색 = 이 도구가 추가/교체하는 블록)\n${highlightPolicy(d.finalBlock)}` : '');
      await adConfirm({ title: 'Admin 규칙 미리보기 (장비는 변경되지 않았습니다)', html, ok: '닫기', cancel: '' });
    } catch (e) { showErr(e.message); toast(e.message, 'bad'); }
    finally { setBusy(false); }
  }
  async function adRun() {
    if (adBusy) return; g('adErr').classList.add('adminHidden');
    const p = adParams();
    try {
      setBusy(true);
      let extra = {}, body = escH(summaryText(p));
      if (adMode === 'add' && p.policyEnable) {
        adLog(['[*] 현재 Local Policy 를 읽어 최종 정책을 만드는 중...']);
        const d = await adPlan(p);
        extra = { revision: d.policy.revision, finalBlock: d.finalBlock };
        body += `\n\n<b>적용될 최종 Local Policy 전체</b> (연두색 = 이 도구가 추가/교체하는 블록)\n${highlightPolicy(d.finalBlock)}`;
      }
      const ok = await adConfirm({ title: adMode === 'delete' ? '삭제 확인' : '실행 확인', html: body, ok: adMode === 'delete' ? '삭제' : '진행', danger: adMode === 'delete' });
      if (!ok) { adLog(['[-] 취소했습니다.']); return; }
      const path = adMode === 'add' ? '/api/admin/add' : adMode === 'passwd' ? '/api/admin/password' : '/api/admin/delete';
      const d = await call(path, { ...p, ...extra });
      adLog(d.log); if (d.users) showUsers(d.userlist, d.users);
      toast(adMode === 'add' ? `관리자 '${p.newUser}' 를 등록했습니다.` : adMode === 'passwd' ? '비밀번호를 변경했습니다.' : `사용자 '${p.newUser}' 를 삭제했습니다.`, 'ok');
      g('adPass').value = ''; g('adPass2').value = '';
      saveAd();
    } catch (e) { showErr(e.message); toast(e.message, 'bad'); adLog(['[X] ' + e.message]); }
    finally { setBusy(false); }
  }
  g('adListBtn').onclick = adList; g('adPreviewBtn').onclick = adPreview; g('adRunBtn').onclick = adRun;

  // ---------- 초기화 ----------
  loadAd(); applyAdMode();
  let m0 = ''; try { m0 = cookieGet(MODE_COOKIE); } catch {}
  setMode(m0); updateSteps('device'); syncDevicePills();
  new MutationObserver(syncDevicePills).observe(g('deviceMini'), { childList: true, characterData: true, subtree: true });
})();
