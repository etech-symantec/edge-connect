// ===== v1.29: MIB 조회 =====
(() => {
  const g = (id) => document.getElementById(id);
  const escH = (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const T = (s) => (window.uiText ? window.uiText(s) : s);
  const COOKIE = 'psg129_mib';
  let busy = false, view = 'table', lastResult = null, selected = null, searchTimer = 0;

  // ---------- 설정 저장(Community 는 체크한 경우에만) ----------
  function saveCfg() {
    const o = { port: g('mibPort').value, timeout: g('mibTimeout').value, remember: g('mibRemember').checked, bulk: g('mibBulk').checked, limit: g('mibLimit').value };
    if (o.remember) o.community = g('mibCommunity').value;
    try { jset(COOKIE, o); } catch {}
  }
  function loadCfg() {
    let o = {}; try { o = jget(COOKIE, {}) || {}; } catch {}
    if (o.port) g('mibPort').value = o.port;
    if (o.timeout) g('mibTimeout').value = o.timeout;
    if (typeof o.bulk === 'boolean') g('mibBulk').checked = o.bulk;
    if (o.limit) g('mibLimit').value = o.limit;
    if (o.remember) { g('mibRemember').checked = true; if (typeof o.community === 'string') g('mibCommunity').value = o.community; }
  }
  ['mibPort', 'mibTimeout', 'mibRemember', 'mibBulk', 'mibLimit', 'mibCommunity'].forEach((id) => g(id).addEventListener('change', saveCfg));

  function snmpParams(extra) {
    return { host: g('host').value.trim(), snmpPort: Number(g('mibPort').value || 161), community: g('mibCommunity').value,
      timeoutSec: Number(g('mibTimeout').value || 3), retries: 1, ...extra };
  }
  const call = (path, p) => api(path, { method: 'POST', body: JSON.stringify(p || {}) });
  function showBox(id, text, type) {
    const b = g(id); b.className = 'status ' + (type || '') ; b.querySelector('span').textContent = T(text);
  }
  const hideBox = (id) => g(id).classList.add('adminHidden');
  function setBusy(v) { busy = v; ['mibTestBtn', 'mibLoadBtn', 'mibGetBtn', 'mibNextBtn', 'mibWalkBtn'].forEach((id) => { g(id).disabled = v; }); }

  // ---------- MIB 불러오기 ----------
  function b64(buf) {
    const bytes = new Uint8Array(buf); let s = ''; const CH = 0x8000;
    for (let i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
    return btoa(s);
  }
  const readBuf = (f) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error(f.name + ' 읽기 실패')); r.readAsArrayBuffer(f); });
  function showInfo(info) {
    const pill = g('mibInfoPill');
    const mods = (info.modules || []).length;
    if (!mods) { pill.textContent = T('없음'); pill.className = 'pill'; }
    else { pill.textContent = `${mods} modules · ${(info.nodes || 0).toLocaleString()} objects`; pill.className = 'pill good'; }
    const w = info.warnings || [];
    g('mibWarnBox').classList.toggle('adminHidden', !w.length);
    g('mibWarnCount').textContent = w.length ? `(${w.length})` : '';
    g('mibWarns').textContent = w.join('\n');
    loadRoot();
  }
  async function loadMibs() {
    const files = [...g('mibFiles').files];
    if (!files.length) { showBox('mibLoadStatus', 'MIB 파일(ZIP / .txt / .mib)을 먼저 선택하세요.', 'bad'); return; }
    if (busy) return;
    try {
      setBusy(true); showBox('mibLoadStatus', 'MIB 를 읽는 중...', '');
      const arr = [];
      for (const f of files) arr.push({ name: f.name, data: b64(await readBuf(f)) });
      const d = await call('/api/mib/load', { files: arr, replace: g('mibReplace').checked });
      showInfo(d.info);
      showBox('mibLoadStatus', `${d.added}개 파일을 불러왔습니다. 모듈 ${(d.info.modules || []).length}개, 객체 ${(d.info.nodes || 0).toLocaleString()}개.`, 'good');
      g('mibFiles').value = '';
    } catch (e) { showBox('mibLoadStatus', e.message, 'bad'); }
    finally { setBusy(false); }
  }
  async function clearMibs() {
    if (!confirm(T('불러온 MIB 를 모두 삭제할까요?'))) return;
    try { const d = await call('/api/mib/clear'); showInfo(d.info); showBox('mibLoadStatus', 'MIB 를 모두 삭제했습니다.', ''); } catch (e) { showBox('mibLoadStatus', e.message, 'bad'); }
  }

  // ---------- 트리 ----------
  const kindLabel = { table: 'table', entry: 'row', column: 'column', scalar: 'scalar', notification: 'trap', group: 'group', module: 'module', identity: 'id' };
  function nodeRow(n, depth) {
    const wrap = document.createElement('div'); wrap.dataset.oid = n.oid;
    const row = document.createElement('div'); row.className = 'mibNode'; row.title = n.oid + (n.syntax ? '  ' + n.syntax : '');
    const tog = document.createElement('span'); tog.className = 'mibTog'; tog.textContent = n.hasChildren ? '▸' : '·';
    const nm = document.createElement('span'); nm.className = 'mibName'; nm.textContent = n.name;
    row.append(tog, nm);
    if (kindLabel[n.kind]) { const k = document.createElement('span'); k.className = 'mibKind ' + n.kind; k.textContent = kindLabel[n.kind]; row.appendChild(k); }
    const kids = document.createElement('div'); kids.className = 'mibKids'; kids.style.display = 'none';
    wrap.append(row, kids);
    const toggle = async (open) => {
      if (!n.hasChildren) return;
      const want = open === undefined ? kids.style.display === 'none' : open;
      if (want && !kids.dataset.loaded) { await fillKids(kids, n.oid); kids.dataset.loaded = '1'; }
      kids.style.display = want ? '' : 'none'; tog.textContent = want ? '▾' : '▸';
    };
    tog.onclick = (e) => { e.stopPropagation(); toggle(); };
    row.onclick = () => { selectNode(n.oid, row); };
    row.ondblclick = () => toggle();
    wrap._toggle = toggle; wrap._row = row; wrap._kids = kids;
    return wrap;
  }
  async function fillKids(box, oid) {
    const d = await call('/api/mib/children', { oid });
    box.textContent = '';
    d.children.forEach((c) => box.appendChild(nodeRow(c)));
  }
  async function loadRoot() {
    const tree = g('mibTree'); tree.textContent = '';
    try {
      const d = await call('/api/mib/children', { oid: '' });
      if (!d.children.length || (d.children.length && !(await hasAnyMib()))) { tree.innerHTML = `<div class="mibEmpty">${escH(T('MIB 를 불러오면 트리가 표시됩니다.'))}</div>`; return; }
      d.children.forEach((c) => tree.appendChild(nodeRow(c)));
      await revealPath('1.3.6.1', false);
    } catch (e) { tree.innerHTML = `<div class="mibEmpty">${escH(e.message)}</div>`; }
  }
  async function hasAnyMib() { const d = await call('/api/mib/info'); return (d.info.modules || []).length > 0; }
  // 조상 노드를 차례로 펼쳐 oid 위치까지 이동
  async function revealPath(oid, select) {
    const parts = oid.split('.'); let cur = '', box = g('mibTree'), target = null;
    for (let i = 0; i < parts.length; i++) {
      cur = cur ? cur + '.' + parts[i] : parts[i];
      const wrap = [...box.children].find((x) => x.dataset && x.dataset.oid === cur);
      if (!wrap) break;
      target = wrap;
      if (i < parts.length - 1 || !select) { await wrap._toggle(true); box = wrap._kids; }
    }
    if (target && select) { selectNode(oid, target._row); target._row.scrollIntoView({ block: 'center' }); }
  }

  // ---------- 상세 ----------
  function selectNode(oid, rowEl) {
    document.querySelectorAll('.mibNode.sel').forEach((x) => x.classList.remove('sel'));
    if (rowEl) rowEl.classList.add('sel');
    selected = oid; g('mibOid').value = oid; showDetail(oid);
  }
  async function showDetail(oid) {
    const box = g('mibDetail');
    try {
      const d = (await call('/api/mib/node', { oid })).node;
      const si = d.syntaxInfo || {};
      const dl = [];
      const add = (k, v) => { if (v !== undefined && v !== '' && v !== null) dl.push(`<dt>${escH(T(k))}</dt><dd>${escH(v)}</dd>`); };
      add('OID', d.oid); add('종류', d.kind); add('모듈', d.module);
      add('형식', d.syntax); add('접근', d.access); add('상태', d.status); add('단위', d.units);
      if (si.range) add('Range', si.range);
      if (si.hint) add('Hint', si.hint);
      if (d.index) add('인덱스', d.index.join(', '));
      if (d.augments) add('AUGMENTS', d.augments);
      if (d.objects) add('OBJECTS', d.objects.join(', '));
      const path = (d.path || []).map((p) => `<a data-oid="${escH(p.oid)}">${escH(p.name)}</a>`).join(' . ');
      let extra = '';
      if (si.enums && si.enums.length) extra += `<dt>${escH(T('값 목록'))}</dt><dd>${si.enums.map((e) => `${escH(e.name)}(${e.value})`).join(', ')}</dd>`;
      if (d.columns && d.columns.length) extra += `<dt>${escH(T('열 목록'))}</dt><dd>${d.columns.map((c) => escH(c.name)).join(', ')}</dd>`;
      box.innerHTML = `<div class="mibPath">${path}</div><div style="font-weight:800;font-size:14px">${escH(d.name)}</div><dl>${dl.join('')}${extra}</dl>` +
        (d.description ? `<div class="mibDesc">${escH(d.description.replace(/\s*\n\s*/g, '\n'))}</div>` : '');
      box.querySelectorAll('.mibPath a').forEach((a) => a.onclick = () => revealPath(a.dataset.oid, true));
    } catch (e) { box.innerHTML = `<div class="mibEmpty">${escH(e.message)}</div>`; }
  }

  // ---------- 검색 ----------
  async function doSearch() {
    const q = g('mibSearch').value.trim(), box = g('mibSearchResults');
    if (!q) { box.classList.add('adminHidden'); box.textContent = ''; return; }
    try {
      const d = await call('/api/mib/search', { q });
      box.classList.remove('adminHidden'); box.textContent = '';
      if (!d.results.length) { box.innerHTML = `<div class="mibEmpty">${escH(T('검색 결과가 없습니다.'))}</div>`; return; }
      d.results.forEach((n) => {
        const row = document.createElement('div'); row.className = 'mibNode'; row.title = n.oid;
        const nm = document.createElement('span'); nm.className = 'mibName'; nm.textContent = n.name;
        const od = document.createElement('span'); od.className = 'mibKind'; od.textContent = n.oid.replace(/^1\.3\.6\.1\./, '…');
        row.append(nm, od); row.onclick = () => revealPath(n.oid, true);
        box.appendChild(row);
      });
      if (d.truncated) { const t = document.createElement('div'); t.className = 'mibEmpty'; t.textContent = '…'; box.appendChild(t); }
    } catch (e) { box.classList.remove('adminHidden'); box.innerHTML = `<div class="mibEmpty">${escH(e.message)}</div>`; }
  }
  g('mibSearch').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(doSearch, 250); });

  // ---------- SNMP ----------
  async function testSnmp() {
    if (busy) return; setBusy(true); showBox('mibTestStatus', 'SNMP 질의 중...', '');
    try {
      const d = await call('/api/mib/snmp-test', snmpParams());
      const lines = d.rows.map((r) => `${r.name === r.oid ? r.oid : r.full}: ${r.value}`);
      showBox('mibTestStatus', d.message + '\n' + lines.join('\n'), 'good');
      g('mibTestStatus').querySelector('span').style.whiteSpace = 'pre-wrap';
    } catch (e) { showBox('mibTestStatus', e.message, 'bad'); }
    finally { setBusy(false); }
  }
  function showErr(msg) { showBox('mibErr', msg, 'bad'); }

  function renderList(rows) {
    const head = g('mibResultHead'), body = g('mibResultBody');
    head.innerHTML = `<tr><th style="width:36%">${escH(T('이름'))}</th><th>${escH(T('값'))}</th><th style="width:20%">${escH(T('형식'))}</th></tr>`;
    body.textContent = '';
    rows.forEach((r) => {
      const tr = document.createElement('tr'); tr.className = 'clickable'; tr.title = r.oid;
      const a = document.createElement('td'); a.textContent = r.full === r.oid ? r.oid : r.full;
      const b = document.createElement('td'); b.textContent = r.value;
      if (/^(noSuch|endOfMib)/.test(r.value)) b.className = 'mibMuted';
      const c = document.createElement('td'); c.className = 'mibMuted'; c.textContent = r.mibType || r.snmpType;
      tr.append(a, b, c); tr.onclick = () => { g('mibOid').value = r.oid; };
      body.appendChild(tr);
    });
  }
  function renderTable(t) {
    const head = g('mibResultHead'), body = g('mibResultBody');
    head.innerHTML = '<tr><th>' + escH(T('인덱스')) + '</th>' + t.columns.map((c) => `<th title="${escH(c.oid)}">${escH(c.name)}</th>`).join('') + '</tr>';
    body.textContent = '';
    t.rows.forEach((r) => {
      const tr = document.createElement('tr');
      const i = document.createElement('td'); i.textContent = r.index; tr.appendChild(i);
      t.columns.forEach((c) => { const td = document.createElement('td'); td.textContent = r.cells[c.name] ?? ''; tr.appendChild(td); });
      body.appendChild(tr);
    });
  }
  function render() {
    if (!lastResult) return;
    const useTable = view === 'table' && lastResult.table && lastResult.table.rows.length;
    if (useTable) renderTable(lastResult.table); else renderList(lastResult.rows);
    g('mibViewTabs').classList.toggle('adminHidden', !lastResult.table);
    document.querySelectorAll('#mibViewTabs button').forEach((b) => b.classList.toggle('active', b.dataset.view === (useTable ? 'table' : 'list')));
  }
  document.querySelectorAll('#mibViewTabs button').forEach((b) => b.onclick = () => { view = b.dataset.view; render(); });

  function setResult(d, label) {
    lastResult = d;
    const lbl = g('mibResultLabel');
    lbl.textContent = label; lbl.className = 'pill good';
    g('mibCsvBtn').classList.toggle('adminHidden', !d.rows.length);
    if (d.table) view = 'table';
    render();
  }
  async function run(kind) {
    if (busy) return; hideBox('mibErr');
    const oid = g('mibOid').value.trim();
    setBusy(true);
    try {
      let d;
      if (kind === 'walk') {
        g('mibResultLabel').textContent = T('Walk 중...');
        d = await call('/api/mib/walk', snmpParams({ oid, bulk: g('mibBulk').checked, limit: Number(g('mibLimit').value) }));
        let label = `${d.count} rows` + (d.truncated ? ' (truncated)' : '');
        if (d.warning) showErr(d.warning);
        setResult(d, label);
        if (!d.count) { g('mibResultBody').innerHTML = `<tr><td style="color:var(--muted)">${escH(T('결과 없음'))}</td></tr>`; }
      } else {
        d = await call('/api/mib/get', snmpParams({ oid, op: kind === 'next' ? 'getnext' : 'get' }));
        setResult(d, kind === 'next' ? 'GetNext' : 'Get');
        view = 'list'; render();
      }
    } catch (e) { showErr(e.message); }
    finally { setBusy(false); }
  }
  g('mibTestBtn').onclick = testSnmp; g('mibLoadBtn').onclick = loadMibs; g('mibClearBtn').onclick = clearMibs;
  g('mibGetBtn').onclick = () => run('get'); g('mibNextBtn').onclick = () => run('next'); g('mibWalkBtn').onclick = () => run('walk');
  g('mibOid').addEventListener('keydown', (e) => { if (e.key === 'Enter') run('get'); });

  // ---------- CSV ----------
  function csvCell(v) { v = String(v ?? ''); return /[",\r\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  g('mibCsvBtn').onclick = () => {
    if (!lastResult) return;
    const useTable = view === 'table' && lastResult.table && lastResult.table.rows.length;
    let lines;
    if (useTable) {
      const t = lastResult.table;
      lines = [['index', ...t.columns.map((c) => c.name)].map(csvCell).join(',')];
      t.rows.forEach((r) => lines.push([r.index, ...t.columns.map((c) => r.cells[c.name] ?? '')].map(csvCell).join(',')));
    } else {
      lines = [['oid', 'name', 'value', 'type'].join(',')];
      lastResult.rows.forEach((r) => lines.push([r.oid, r.full, r.value, r.mibType || r.snmpType].map(csvCell).join(',')));
    }
    const blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
    a.download = `mib_${(g('mibOid').value || 'result').replace(/[^A-Za-z0-9._-]/g, '_')}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  // ---------- 초기화 ----------
  loadCfg();
  const reloadInfo = async () => { try { const d = await call('/api/mib/info'); if (d.info && d.info.modules) showInfo(d.info); } catch {} };
  window.mibRefresh = reloadInfo;
  setTimeout(reloadInfo, 400);
})();
