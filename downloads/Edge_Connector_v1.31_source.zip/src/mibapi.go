package main

import (
	"archive/zip"
	"bytes"
	"encoding/base64"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ---------------------------------------------------------------- MIB 저장소

var (
	mibMu   sync.RWMutex
	mibSet  = NewMibSet()
	mibAll  []*Node
	mibInfo = map[string]any{}
)

func mibDir() string {
	d := filepath.Join(filepath.Dir(knownHostsPath()), "mibs")
	os.MkdirAll(d, 0o700)
	return d
}

var mibNameRe = regexp.MustCompile(`[^A-Za-z0-9._-]`)

// rebuildMibs 는 저장된 MIB 파일 전체를 다시 읽어 트리를 만듭니다.
func rebuildMibs() {
	set := NewMibSet()
	ents, _ := os.ReadDir(mibDir())
	sort.Slice(ents, func(i, j int) bool { return ents[i].Name() < ents[j].Name() })
	files := 0
	for _, e := range ents {
		if e.IsDir() {
			continue
		}
		b, err := os.ReadFile(filepath.Join(mibDir(), e.Name()))
		if err != nil {
			continue
		}
		files++
		set.parse(e.Name(), string(b))
	}
	set.resolve()
	var all []*Node
	var walk func(n *Node)
	walk = func(n *Node) {
		if n.Name != "" {
			all = append(all, n)
		}
		for _, c := range n.SortedChildren() {
			walk(c)
		}
	}
	walk(set.Root)
	mods := make([]map[string]any, 0)
	names := make([]string, 0, len(set.Modules))
	for k := range set.Modules {
		names = append(names, k)
	}
	sort.Strings(names)
	for _, k := range names {
		m := set.Modules[k]
		mods = append(mods, map[string]any{"name": m.Name, "file": m.File, "defs": m.Defs})
	}
	warns := append([]string{}, set.Warnings...)
	if len(warns) > 60 {
		warns = append(warns[:60:60], "… (경고 일부 생략)")
	}
	mibMu.Lock()
	mibSet, mibAll = set, all
	mibInfo = map[string]any{"files": files, "modules": mods, "nodes": len(all), "warnings": warns}
	mibMu.Unlock()
}

type mibFileIn struct {
	Name string `json:"name"`
	Data string `json:"data"` // base64
}

func addMibFile(name string, data []byte, saved *[]string) {
	base := filepath.Base(strings.ReplaceAll(name, "\\", "/"))
	ext := strings.ToLower(filepath.Ext(base))
	switch ext {
	case ".txt", ".mib", ".my", ".smi", ".asn", ".asn1", "":
	default:
		return
	}
	if len(data) == 0 || len(data) > 16<<20 || bytes.IndexByte(data[:min(len(data), 4096)], 0) >= 0 {
		return
	}
	clean := mibNameRe.ReplaceAllString(base, "_")
	if clean == "" || clean[0] == '.' {
		return
	}
	if os.WriteFile(filepath.Join(mibDir(), clean), data, 0o600) == nil {
		*saved = append(*saved, clean)
	}
}

func apiMibLoad(r *http.Request) (any, error) {
	var req struct {
		Files   []mibFileIn `json:"files"`
		Replace bool        `json:"replace"`
	}
	if err := decodeBody(r, &req); err != nil {
		return nil, err
	}
	if len(req.Files) == 0 {
		return nil, fail(400, "MIB 파일을 선택하세요.")
	}
	var saved []string
	var staged []struct {
		name string
		data []byte
	}
	var total int64
	for _, f := range req.Files {
		raw, err := base64.StdEncoding.DecodeString(f.Data)
		if err != nil {
			return nil, fail(400, f.Name+": 파일 내용을 읽을 수 없습니다.")
		}
		if strings.HasSuffix(strings.ToLower(f.Name), ".zip") || bytes.HasPrefix(raw, []byte("PK\x03\x04")) {
			zr, err := zip.NewReader(bytes.NewReader(raw), int64(len(raw)))
			if err != nil {
				return nil, fail(400, f.Name+": ZIP 파일을 열 수 없습니다.")
			}
			if len(zr.File) > 3000 {
				return nil, fail(400, "ZIP 안의 파일이 너무 많습니다.")
			}
			for _, zf := range zr.File {
				if zf.FileInfo().IsDir() || zf.UncompressedSize64 > 16<<20 {
					continue
				}
				rc, err := zf.Open()
				if err != nil {
					continue
				}
				b, _ := io.ReadAll(io.LimitReader(rc, 16<<20))
				rc.Close()
				total += int64(len(b))
				if total > 128<<20 {
					return nil, fail(400, "압축을 풀면 용량이 너무 큽니다.")
				}
				staged = append(staged, struct {
					name string
					data []byte
				}{zf.Name, b})
			}
		} else {
			staged = append(staged, struct {
				name string
				data []byte
			}{f.Name, raw})
		}
	}
	if req.Replace {
		ents, _ := os.ReadDir(mibDir())
		for _, e := range ents {
			if !e.IsDir() {
				os.Remove(filepath.Join(mibDir(), e.Name()))
			}
		}
	}
	for _, s := range staged {
		addMibFile(s.name, s.data, &saved)
	}
	if len(saved) == 0 {
		return nil, fail(400, "읽을 수 있는 MIB 파일(.txt / .mib)이 없습니다.")
	}
	rebuildMibs()
	mibMu.RLock()
	defer mibMu.RUnlock()
	return map[string]any{"added": len(saved), "info": mibInfo}, nil
}

func apiMibInfo(r *http.Request) (any, error) {
	mibMu.RLock()
	defer mibMu.RUnlock()
	return map[string]any{"info": mibInfo}, nil
}

func apiMibClear(r *http.Request) (any, error) {
	ents, _ := os.ReadDir(mibDir())
	for _, e := range ents {
		if !e.IsDir() {
			os.Remove(filepath.Join(mibDir(), e.Name()))
		}
	}
	rebuildMibs()
	return map[string]any{"info": mibInfo}, nil
}

// ---------------------------------------------------------------- 트리/노드

func syntaxShort(set *MibSet, n *Node) string {
	if n.Syntax == nil {
		return ""
	}
	if n.Syntax.SeqOf != "" {
		return "SEQUENCE OF " + n.Syntax.SeqOf
	}
	rs := set.ResolveSyntax(n.Module, n.Syntax)
	if rs.TypeName != "" && rs.TypeName != rs.Base {
		return rs.TypeName + " (" + rs.Base + ")"
	}
	return rs.Base
}

func briefNode(set *MibSet, n *Node) map[string]any {
	name := n.Name
	if name == "" {
		name = strconv.Itoa(int(n.Num))
	}
	return map[string]any{
		"name": name, "oid": oidString(n.OID), "num": n.Num, "kind": set.Classify(n),
		"hasChildren": len(n.Children) > 0, "syntax": syntaxShort(set, n), "access": n.Access, "module": n.Module,
	}
}

// parseTarget 은 "sysDescr.0", "BLUECOAT-MIB::name.3", "1.3.6.1.2.1.1.1.0" 형식을 OID 로 바꿉니다.
func parseTarget(set *MibSet, s string) ([]uint32, *Node, string, error) {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(s, ".")
	if s == "" {
		return nil, nil, "", fail(400, "OID 또는 객체 이름을 입력하세요.")
	}
	numeric := func(x string) ([]uint32, bool) {
		var out []uint32
		for _, p := range strings.Split(x, ".") {
			v, err := strconv.ParseUint(p, 10, 32)
			if err != nil {
				return nil, false
			}
			out = append(out, uint32(v))
		}
		return out, true
	}
	if o, ok := numeric(s); ok {
		n, d := set.Find(o)
		if d == len(o) {
			return o, n, "", nil
		}
		return o, n, "", nil
	}
	name, rest := s, ""
	if i := strings.Index(s, "::"); i >= 0 {
		if j := strings.Index(s[i+2:], "."); j >= 0 {
			name, rest = s[:i+2+j], s[i+3+j:]
		}
	} else if i := strings.Index(s, "."); i >= 0 {
		name, rest = s[:i], s[i+1:]
	}
	n := set.NodeByName(name)
	if n == nil {
		return nil, nil, "", fail(400, "MIB 에서 '"+name+"' 을(를) 찾을 수 없습니다. MIB 파일을 먼저 올렸는지, 이름이 맞는지 확인하세요.")
	}
	o := append([]uint32{}, n.OID...)
	if rest != "" {
		inst, ok := numeric(rest)
		if !ok {
			return nil, nil, "", fail(400, "인스턴스 부분은 숫자여야 합니다 (예: sysDescr.0)")
		}
		o = append(o, inst...)
	}
	return o, n, rest, nil
}

func apiMibChildren(r *http.Request) (any, error) {
	var req struct {
		OID string `json:"oid"`
	}
	if err := decodeBody(r, &req); err != nil {
		return nil, err
	}
	mibMu.RLock()
	defer mibMu.RUnlock()
	n := mibSet.Root
	if strings.TrimSpace(req.OID) != "" {
		o, _, _, err := parseTarget(mibSet, req.OID)
		if err != nil {
			return nil, err
		}
		nn, d := mibSet.Find(o)
		if d != len(o) {
			return nil, fail(404, "해당 OID 를 트리에서 찾을 수 없습니다.")
		}
		n = nn
	}
	out := []map[string]any{}
	for _, c := range n.SortedChildren() {
		out = append(out, briefNode(mibSet, c))
	}
	return map[string]any{"children": out}, nil
}

func nodeDetail(set *MibSet, n *Node) map[string]any {
	d := briefNode(set, n)
	d["status"], d["description"], d["units"] = n.Status, n.Desc, n.Units
	if n.Syntax != nil {
		rs := set.ResolveSyntax(n.Module, n.Syntax)
		d["syntaxInfo"] = rs
	}
	if len(n.Index) > 0 {
		d["index"] = n.Index
	}
	if n.Augments != "" {
		d["augments"] = n.Augments
	}
	if len(n.Objects) > 0 {
		d["objects"] = n.Objects
	}
	var path []map[string]any
	for p := n; p != nil && p != set.Root; p = p.Parent {
		nm := p.Name
		if nm == "" {
			nm = strconv.Itoa(int(p.Num))
		}
		path = append([]map[string]any{{"name": nm, "oid": oidString(p.OID)}}, path...)
	}
	d["path"] = path
	cls := set.Classify(n)
	if cls == "table" || cls == "entry" {
		entry := n
		if cls == "table" {
			for _, c := range n.SortedChildren() {
				entry = c
				break
			}
		}
		var cols []map[string]any
		if entry != nil {
			for _, c := range entry.SortedChildren() {
				cols = append(cols, briefNode(set, c))
			}
		}
		d["columns"] = cols
	}
	return d
}

func apiMibNode(r *http.Request) (any, error) {
	var req struct {
		OID string `json:"oid"`
	}
	if err := decodeBody(r, &req); err != nil {
		return nil, err
	}
	mibMu.RLock()
	defer mibMu.RUnlock()
	o, _, _, err := parseTarget(mibSet, req.OID)
	if err != nil {
		return nil, err
	}
	n, dpt := mibSet.Find(o)
	if dpt != len(o) || n == mibSet.Root {
		return nil, fail(404, "해당 OID 는 로드된 MIB 에 없습니다.")
	}
	return map[string]any{"node": nodeDetail(mibSet, n)}, nil
}

func apiMibSearch(r *http.Request) (any, error) {
	var req struct {
		Q     string `json:"q"`
		Limit int    `json:"limit"`
	}
	if err := decodeBody(r, &req); err != nil {
		return nil, err
	}
	q := strings.ToLower(strings.TrimSpace(strings.TrimPrefix(req.Q, ".")))
	if q == "" {
		return map[string]any{"results": []any{}}, nil
	}
	if req.Limit <= 0 || req.Limit > 300 {
		req.Limit = 120
	}
	mibMu.RLock()
	defer mibMu.RUnlock()
	var exact, pre, sub []map[string]any
	for _, n := range mibAll {
		nm := strings.ToLower(n.Name)
		oid := oidString(n.OID)
		switch {
		case nm == q || oid == q:
			exact = append(exact, briefNode(mibSet, n))
		case strings.HasPrefix(nm, q) || strings.HasPrefix(oid, q+"."):
			pre = append(pre, briefNode(mibSet, n))
		case strings.Contains(nm, q):
			sub = append(sub, briefNode(mibSet, n))
		}
	}
	out := append(append(exact, pre...), sub...)
	trunc := false
	if len(out) > req.Limit {
		out, trunc = out[:req.Limit], true
	}
	return map[string]any{"results": out, "truncated": trunc}, nil
}

// ---------------------------------------------------------------- SNMP 조회

type snmpReq struct {
	Host       string `json:"host"`
	SnmpPort   int    `json:"snmpPort"`
	Community  string `json:"community"`
	TimeoutSec int    `json:"timeoutSec"`
	Retries    int    `json:"retries"`
	OID        string `json:"oid"`
	Op         string `json:"op"`
	Bulk       *bool  `json:"bulk"`
	Limit      int    `json:"limit"`
}

func (q *snmpReq) client() (*SnmpClient, error) {
	q.Host = strings.TrimSpace(q.Host)
	if q.Host == "" {
		return nil, fail(400, "STEP 1 에서 장비 IP 를 먼저 입력하세요.")
	}
	if !hostRe.MatchString(q.Host) {
		return nil, fail(400, "장비 IP / Hostname 형식이 올바르지 않습니다.")
	}
	if q.Community == "" {
		return nil, fail(400, "SNMP community 를 입력하세요.")
	}
	if len(q.Community) > 255 || strings.ContainsAny(q.Community, "\r\n\x00") {
		return nil, fail(400, "SNMP community 형식이 올바르지 않습니다.")
	}
	if q.SnmpPort == 0 {
		q.SnmpPort = 161
	}
	if q.SnmpPort < 1 || q.SnmpPort > 65535 {
		return nil, fail(400, "SNMP Port 범위가 올바르지 않습니다.")
	}
	if q.TimeoutSec <= 0 {
		q.TimeoutSec = 3
	}
	if q.TimeoutSec > 30 {
		q.TimeoutSec = 30
	}
	if q.Retries < 0 || q.Retries > 3 {
		q.Retries = 1
	}
	return &SnmpClient{Host: q.Host, Port: q.SnmpPort, Community: q.Community, Timeout: time.Duration(q.TimeoutSec) * time.Second, Retries: q.Retries}, nil
}

func snmpFail(err error) error {
	if err == nil {
		return nil
	}
	if ae, ok := err.(*apiError); ok {
		return ae
	}
	return fail(502, err.Error())
}

func rowFor(set *MibSet, vb VarBind) map[string]any {
	name, node, inst := set.NameOID(vb.OID)
	var syn *Syntax
	kind := ""
	if node != nil {
		kind = set.Classify(node)
		if node.Syntax != nil && node.Syntax.SeqOf == "" {
			syn = set.ResolveSyntax(node.Module, node.Syntax)
		}
	}
	mt := ""
	if syn != nil {
		mt = syn.TypeName
		if mt == "" {
			mt = syn.Base
		}
	}
	full := name
	if inst != "" {
		full = name + "." + inst
	}
	return map[string]any{
		"oid": oidString(vb.OID), "name": name, "instance": inst, "full": full, "kind": kind,
		"snmpType": vb.Val.typeName(), "mibType": mt, "value": set.formatValue(vb.Val, syn),
	}
}

func apiMibSnmpTest(r *http.Request) (any, error) {
	var q snmpReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	c, err := q.client()
	if err != nil {
		return nil, err
	}
	defer c.Close()
	oids := [][]uint32{{1, 3, 6, 1, 2, 1, 1, 1, 0}, {1, 3, 6, 1, 2, 1, 1, 2, 0}, {1, 3, 6, 1, 2, 1, 1, 3, 0}, {1, 3, 6, 1, 2, 1, 1, 5, 0}}
	vbs, err := c.request(pduGet, oids, 0)
	if err != nil {
		return nil, snmpFail(err)
	}
	mibMu.RLock()
	defer mibMu.RUnlock()
	rows := []map[string]any{}
	for _, vb := range vbs {
		rows = append(rows, rowFor(mibSet, vb))
	}
	return map[string]any{"rows": rows, "message": "SNMP v2c 응답을 받았습니다."}, nil
}

func apiMibGet(r *http.Request) (any, error) {
	var q snmpReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	c, err := q.client()
	if err != nil {
		return nil, err
	}
	defer c.Close()
	mibMu.RLock()
	defer mibMu.RUnlock()
	oid, node, _, err := parseTarget(mibSet, q.OID)
	if err != nil {
		return nil, err
	}
	var vb VarBind
	if q.Op == "getnext" {
		vb, err = c.GetNext(oid)
	} else {
		if node != nil && len(oid) == len(node.OID) {
			switch mibSet.Classify(node) {
			case "scalar":
				oid = append(append([]uint32{}, oid...), 0)
			case "column":
				return nil, fail(400, "테이블 열(column)은 인덱스가 필요합니다. 예: "+node.Name+".1  (전체를 보려면 Walk 를 쓰세요)")
			case "table", "entry":
				return nil, fail(400, "테이블은 Get 할 수 없습니다. Walk 를 사용하세요.")
			}
		}
		vb, err = c.Get(oid)
	}
	if err != nil {
		return nil, snmpFail(err)
	}
	return map[string]any{"rows": []map[string]any{rowFor(mibSet, vb)}}, nil
}

func apiMibWalk(r *http.Request) (any, error) {
	var q snmpReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	c, err := q.client()
	if err != nil {
		return nil, err
	}
	defer c.Close()
	if q.Limit <= 0 {
		q.Limit = 2000
	}
	if q.Limit > 20000 {
		q.Limit = 20000
	}
	bulk := q.Bulk == nil || *q.Bulk
	mibMu.RLock()
	defer mibMu.RUnlock()
	oid, node, _, err := parseTarget(mibSet, q.OID)
	if err != nil {
		return nil, err
	}
	cls := ""
	if node != nil {
		cls = mibSet.Classify(node)
	}
	var vbs []VarBind
	truncated := false
	if cls == "scalar" && len(oid) == len(node.OID) {
		vb, err := c.Get(append(append([]uint32{}, oid...), 0))
		if err != nil {
			return nil, snmpFail(err)
		}
		vbs = []VarBind{vb}
	} else {
		vbs, truncated, err = c.Walk(oid, bulk, q.Limit, 60*time.Second)
		if err != nil && len(vbs) == 0 {
			return nil, snmpFail(err)
		}
	}
	rows := make([]map[string]any, 0, len(vbs))
	for _, vb := range vbs {
		rows = append(rows, rowFor(mibSet, vb))
	}
	res := map[string]any{"rows": rows, "count": len(rows), "truncated": truncated, "tableLike": cls == "table" || cls == "entry"}
	if err != nil {
		res["warning"] = err.Error()
	}
	if cls == "table" || cls == "entry" {
		res["table"] = groupTable(mibSet, node, vbs)
	}
	return res, nil
}

// groupTable 은 테이블 walk 결과를 (인덱스 × 열) 표로 묶습니다.
func groupTable(set *MibSet, node *Node, vbs []VarBind) map[string]any {
	type colInfo struct {
		name string
		num  uint32
		oid  string
	}
	cols := map[string]colInfo{}
	rowsByIdx := map[string]map[string]string{}
	var order []string
	for _, vb := range vbs {
		n, depth := set.Find(vb.OID)
		for n != set.Root && n.Name == "" {
			n = n.Parent
			depth--
		}
		if n == set.Root || set.Classify(n) != "column" {
			continue
		}
		idx := oidString(vb.OID[depth:])
		cols[n.Name] = colInfo{n.Name, n.Num, oidString(n.OID)}
		rm := rowsByIdx[idx]
		if rm == nil {
			rm = map[string]string{}
			rowsByIdx[idx] = rm
			order = append(order, idx)
		}
		var syn *Syntax
		if n.Syntax != nil {
			syn = set.ResolveSyntax(n.Module, n.Syntax)
		}
		rm[n.Name] = set.formatValue(vb.Val, syn)
	}
	cl := make([]colInfo, 0, len(cols))
	for _, c := range cols {
		cl = append(cl, c)
	}
	sort.Slice(cl, func(i, j int) bool { return cl[i].num < cl[j].num })
	outCols := []map[string]any{}
	for _, c := range cl {
		outCols = append(outCols, map[string]any{"name": c.name, "oid": c.oid})
	}
	sort.SliceStable(order, func(i, j int) bool { return cmpIdx(order[i], order[j]) < 0 })
	outRows := []map[string]any{}
	for _, idx := range order {
		outRows = append(outRows, map[string]any{"index": idx, "cells": rowsByIdx[idx]})
	}
	return map[string]any{"columns": outCols, "rows": outRows}
}

func cmpIdx(a, b string) int {
	pa, pb := strings.Split(a, "."), strings.Split(b, ".")
	for i := 0; i < len(pa) && i < len(pb); i++ {
		x, _ := strconv.ParseUint(pa[i], 10, 64)
		y, _ := strconv.ParseUint(pb[i], 10, 64)
		if x != y {
			if x < y {
				return -1
			}
			return 1
		}
	}
	return len(pa) - len(pb)
}
