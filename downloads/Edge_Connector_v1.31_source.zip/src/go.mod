module edgeconnector

go 1.21
