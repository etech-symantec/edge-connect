package main

import (
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"math/big"
	"net"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

// ---------------------------------------------------------------- BER 기본

const (
	tInteger   = 0x02
	tOctet     = 0x04
	tNull      = 0x05
	tOID       = 0x06
	tSequence  = 0x30
	tIPAddr    = 0x40
	tCounter32 = 0x41
	tGauge32   = 0x42
	tTimeTicks = 0x43
	tOpaque    = 0x44
	tCounter64 = 0x46
	tNoSuchObj = 0x80
	tNoSuchIns = 0x81
	tEndOfMib  = 0x82
	pduGet     = 0xA0
	pduNext    = 0xA1
	pduResp    = 0xA2
	pduBulk    = 0xA5
)

func berLen(n int) []byte {
	if n < 128 {
		return []byte{byte(n)}
	}
	var b []byte
	for x := n; x > 0; x >>= 8 {
		b = append([]byte{byte(x)}, b...)
	}
	return append([]byte{0x80 | byte(len(b))}, b...)
}

func berTLV(t byte, v []byte) []byte {
	out := []byte{t}
	out = append(out, berLen(len(v))...)
	return append(out, v...)
}

func berInt(v int64) []byte {
	var b []byte
	for {
		b = append([]byte{byte(v & 0xff)}, b...)
		v >>= 8
		if (v == 0 && b[0]&0x80 == 0) || (v == -1 && b[0]&0x80 != 0) {
			break
		}
	}
	return berTLV(tInteger, b)
}

func berOID(oid []uint32) ([]byte, error) {
	if len(oid) < 2 || oid[0] > 2 || (oid[0] < 2 && oid[1] >= 40) {
		return nil, errors.New("OID 는 최소 2개 이상의 올바른 숫자여야 합니다 (예: 1.3.6.1.2.1.1.1.0)")
	}
	b := []byte{}
	for i, v := range append([]uint32{oid[0]*40 + oid[1]}, oid[2:]...) {
		_ = i
		var enc []byte
		enc = append(enc, byte(v&0x7f))
		for v >>= 7; v > 0; v >>= 7 {
			enc = append([]byte{byte(v&0x7f) | 0x80}, enc...)
		}
		b = append(b, enc...)
	}
	return berTLV(tOID, b), nil
}

type tlv struct {
	t byte
	v []byte
}

func readTLV(b []byte) (tlv, []byte, error) {
	if len(b) < 2 {
		return tlv{}, nil, errors.New("SNMP 응답이 잘렸습니다")
	}
	t := b[0]
	l := int(b[1])
	off := 2
	if l&0x80 != 0 {
		n := l & 0x7f
		if n == 0 || n > 4 || len(b) < 2+n {
			return tlv{}, nil, errors.New("SNMP 응답 길이 형식 오류")
		}
		l = 0
		for i := 0; i < n; i++ {
			l = l<<8 | int(b[2+i])
		}
		off = 2 + n
	}
	if l < 0 || len(b) < off+l {
		return tlv{}, nil, errors.New("SNMP 응답이 잘렸습니다")
	}
	return tlv{t, b[off : off+l]}, b[off+l:], nil
}

func decInt(v []byte) int64 {
	if len(v) == 0 {
		return 0
	}
	var x int64
	if v[0]&0x80 != 0 {
		x = -1
	}
	for _, c := range v {
		x = x<<8 | int64(c)
	}
	return x
}

func decUint(v []byte) *big.Int { return new(big.Int).SetBytes(v) }

func decOID(v []byte) []uint32 {
	if len(v) == 0 {
		return nil
	}
	out := []uint32{}
	first := uint32(v[0])
	switch {
	case first < 40:
		out = append(out, 0, first)
	case first < 80:
		out = append(out, 1, first-40)
	default:
		out = append(out, 2, first-80)
	}
	var cur uint32
	for _, c := range v[1:] {
		cur = cur<<7 | uint32(c&0x7f)
		if c&0x80 == 0 {
			out = append(out, cur)
			cur = 0
		}
	}
	return out
}

// ---------------------------------------------------------------- 값

type SnmpValue struct {
	T   byte
	Int int64
	Big *big.Int
	Raw []byte
	OID []uint32
}

type VarBind struct {
	OID []uint32
	Val SnmpValue
}

func (v SnmpValue) isException() bool {
	return v.T == tNoSuchObj || v.T == tNoSuchIns || v.T == tEndOfMib
}

func (v SnmpValue) typeName() string {
	switch v.T {
	case tInteger:
		return "INTEGER"
	case tOctet:
		return "OCTET STRING"
	case tNull:
		return "NULL"
	case tOID:
		return "OBJECT IDENTIFIER"
	case tIPAddr:
		return "IpAddress"
	case tCounter32:
		return "Counter32"
	case tGauge32:
		return "Gauge32"
	case tTimeTicks:
		return "TimeTicks"
	case tOpaque:
		return "Opaque"
	case tCounter64:
		return "Counter64"
	case tNoSuchObj:
		return "noSuchObject"
	case tNoSuchIns:
		return "noSuchInstance"
	case tEndOfMib:
		return "endOfMibView"
	}
	return fmt.Sprintf("type0x%02x", v.T)
}

func parseVarBinds(b []byte) ([]VarBind, error) {
	seq, _, err := readTLV(b)
	if err != nil || seq.t != tSequence {
		return nil, errors.New("varbind 목록 형식 오류")
	}
	var out []VarBind
	rest := seq.v
	for len(rest) > 0 {
		var vb tlv
		vb, rest, err = readTLV(rest)
		if err != nil || vb.t != tSequence {
			return nil, errors.New("varbind 형식 오류")
		}
		name, r2, err := readTLV(vb.v)
		if err != nil || name.t != tOID {
			return nil, errors.New("varbind OID 형식 오류")
		}
		val, _, err := readTLV(r2)
		if err != nil {
			return nil, err
		}
		sv := SnmpValue{T: val.t, Raw: val.v}
		switch val.t {
		case tInteger:
			sv.Int = decInt(val.v)
		case tCounter32, tGauge32, tTimeTicks, tCounter64:
			sv.Big = decUint(val.v)
		case tOID:
			sv.OID = decOID(val.v)
		}
		out = append(out, VarBind{OID: decOID(name.v), Val: sv})
	}
	return out, nil
}

// ---------------------------------------------------------------- 클라이언트

type SnmpClient struct {
	Host      string
	Port      int
	Community string
	Timeout   time.Duration
	Retries   int
	conn      net.Conn
}

var snmpErrNames = map[int64]string{
	1: "tooBig", 2: "noSuchName", 3: "badValue", 4: "readOnly", 5: "genErr", 6: "noAccess",
	7: "wrongType", 8: "wrongLength", 9: "wrongEncoding", 10: "wrongValue", 11: "noCreation",
	12: "inconsistentValue", 13: "resourceUnavailable", 14: "commitFailed", 15: "undoFailed",
	16: "authorizationError", 17: "notWritable", 18: "inconsistentName",
}

func (c *SnmpClient) dial() error {
	if c.conn != nil {
		return nil
	}
	cn, err := net.DialTimeout("udp", net.JoinHostPort(c.Host, strconv.Itoa(c.Port)), c.Timeout)
	if err != nil {
		return fmt.Errorf("SNMP 대상에 연결할 수 없습니다: %v", err)
	}
	c.conn = cn
	return nil
}

func (c *SnmpClient) Close() {
	if c.conn != nil {
		c.conn.Close()
		c.conn = nil
	}
}

func randID() int32 {
	var b [4]byte
	rand.Read(b[:])
	return int32(binary.BigEndian.Uint32(b[:]) & 0x3fffffff)
}

// request 는 GET / GETNEXT / GETBULK 요청을 보내고 varbind 를 돌려줍니다.
func (c *SnmpClient) request(op byte, oids [][]uint32, maxRep int) ([]VarBind, error) {
	if err := c.dial(); err != nil {
		return nil, err
	}
	var vbs []byte
	for _, o := range oids {
		eo, err := berOID(o)
		if err != nil {
			return nil, err
		}
		vbs = append(vbs, berTLV(tSequence, append(eo, 0x05, 0x00))...)
	}
	id := int64(randID())
	var pdu []byte
	pdu = append(pdu, berInt(id)...)
	if op == pduBulk {
		pdu = append(pdu, berInt(0)...)
		pdu = append(pdu, berInt(int64(maxRep))...)
	} else {
		pdu = append(pdu, berInt(0)...)
		pdu = append(pdu, berInt(0)...)
	}
	pdu = append(pdu, berTLV(tSequence, vbs)...)
	msg := append(berInt(1), berTLV(tOctet, []byte(c.Community))...)
	msg = append(msg, berTLV(op, pdu)...)
	pkt := berTLV(tSequence, msg)

	buf := make([]byte, 65535)
	var lastErr error
	for attempt := 0; attempt <= c.Retries; attempt++ {
		if _, err := c.conn.Write(pkt); err != nil {
			return nil, fmt.Errorf("SNMP 요청 전송 실패: %v", err)
		}
		deadline := time.Now().Add(c.Timeout)
		for {
			c.conn.SetReadDeadline(deadline)
			n, err := c.conn.Read(buf)
			if err != nil {
				var ne net.Error
				if errors.As(err, &ne) && ne.Timeout() {
					lastErr = fmt.Errorf("SNMP 응답 시간 초과 (%s). 장비의 SNMP 활성화, community, 이 PC 의 접근 허용(UDP 161)을 확인하세요", c.Timeout)
				} else {
					lastErr = fmt.Errorf("SNMP 수신 실패: %v", err)
				}
				break
			}
			vb, rid, errStatus, errIdx, perr := parseResponse(buf[:n])
			if perr != nil {
				lastErr = perr
				continue
			}
			if rid != id {
				continue // 이전 요청의 늦은 응답
			}
			if errStatus != 0 {
				nm := snmpErrNames[errStatus]
				if nm == "" {
					nm = strconv.FormatInt(errStatus, 10)
				}
				return vb, &snmpStatusErr{Status: errStatus, Name: nm, Index: errIdx}
			}
			return vb, nil
		}
	}
	return nil, lastErr
}

type snmpStatusErr struct {
	Status int64
	Name   string
	Index  int64
}

func (e *snmpStatusErr) Error() string {
	return fmt.Sprintf("SNMP 오류: %s (error-index %d)", e.Name, e.Index)
}

func parseResponse(b []byte) ([]VarBind, int64, int64, int64, error) {
	top, _, err := readTLV(b)
	if err != nil || top.t != tSequence {
		return nil, 0, 0, 0, errors.New("SNMP 응답 형식 오류")
	}
	ver, r, err := readTLV(top.v)
	if err != nil || ver.t != tInteger {
		return nil, 0, 0, 0, errors.New("SNMP 응답 버전 오류")
	}
	_, r, err = readTLV(r) // community
	if err != nil {
		return nil, 0, 0, 0, err
	}
	p, _, err := readTLV(r)
	if err != nil || p.t != pduResp {
		return nil, 0, 0, 0, errors.New("SNMP 응답 PDU 가 아닙니다")
	}
	rid, r, err := readTLV(p.v)
	if err != nil {
		return nil, 0, 0, 0, err
	}
	es, r, err := readTLV(r)
	if err != nil {
		return nil, 0, 0, 0, err
	}
	ei, r, err := readTLV(r)
	if err != nil {
		return nil, 0, 0, 0, err
	}
	vbs, err := parseVarBinds(r)
	if err != nil {
		return nil, 0, 0, 0, err
	}
	return vbs, decInt(rid.v), decInt(es.v), decInt(ei.v), nil
}

func (c *SnmpClient) Get(oid []uint32) (VarBind, error) {
	vb, err := c.request(pduGet, [][]uint32{oid}, 0)
	if err != nil {
		return VarBind{}, err
	}
	if len(vb) == 0 {
		return VarBind{}, errors.New("빈 응답")
	}
	return vb[0], nil
}

func (c *SnmpClient) GetNext(oid []uint32) (VarBind, error) {
	vb, err := c.request(pduNext, [][]uint32{oid}, 0)
	if err != nil {
		return VarBind{}, err
	}
	if len(vb) == 0 {
		return VarBind{}, errors.New("빈 응답")
	}
	return vb[0], nil
}

func hasPrefix(oid, prefix []uint32) bool {
	if len(oid) < len(prefix) {
		return false
	}
	for i := range prefix {
		if oid[i] != prefix[i] {
			return false
		}
	}
	return true
}

func cmpOID(a, b []uint32) int {
	for i := 0; i < len(a) && i < len(b); i++ {
		if a[i] != b[i] {
			if a[i] < b[i] {
				return -1
			}
			return 1
		}
	}
	return len(a) - len(b)
}

// Walk 는 root 아래의 모든 값을 읽습니다. bulk 가 true 이면 GETBULK 를 씁니다.
func (c *SnmpClient) Walk(root []uint32, bulk bool, limit int, total time.Duration) ([]VarBind, bool, error) {
	var out []VarBind
	cur := root
	end := time.Now().Add(total)
	for {
		if time.Now().After(end) {
			return out, true, nil
		}
		var vbs []VarBind
		var err error
		if bulk {
			vbs, err = c.request(pduBulk, [][]uint32{cur}, 20)
		} else {
			var one VarBind
			one, err = c.GetNext(cur)
			vbs = []VarBind{one}
		}
		if err != nil {
			var se *snmpStatusErr
			if errors.As(err, &se) && se.Status == 2 { // noSuchName = SNMPv1 방식의 끝
				return out, false, nil
			}
			return out, false, err
		}
		if len(vbs) == 0 {
			return out, false, nil
		}
		for _, vb := range vbs {
			if vb.Val.T == tEndOfMib || !hasPrefix(vb.OID, root) {
				return out, false, nil
			}
			if len(out) > 0 && cmpOID(vb.OID, out[len(out)-1].OID) <= 0 {
				return out, false, errors.New("장비가 증가하지 않는 OID 를 반환해 중단했습니다")
			}
			if vb.Val.isException() {
				continue
			}
			out = append(out, vb)
			cur = vb.OID
			if len(out) >= limit {
				return out, true, nil
			}
		}
	}
}

// ---------------------------------------------------------------- 값 표시

func printable(b []byte) bool {
	if !utf8.Valid(b) {
		return false
	}
	for _, r := range string(b) {
		if r < 0x20 && r != '\n' && r != '\r' && r != '\t' || r == 0x7f {
			return false
		}
	}
	return true
}

func hexJoin(b []byte, sep string) string {
	parts := make([]string, len(b))
	for i, c := range b {
		parts[i] = fmt.Sprintf("%02X", c)
	}
	return strings.Join(parts, sep)
}

func ticksText(t uint64) string {
	cs := t % 100
	s := t / 100
	d, h, m, sec := s/86400, (s/3600)%24, (s/60)%60, s%60
	if d > 0 {
		return fmt.Sprintf("%d일 %d:%02d:%02d.%02d", d, h, m, sec, cs)
	}
	return fmt.Sprintf("%d:%02d:%02d.%02d", h, m, sec, cs)
}

func dateAndTime(b []byte) string {
	if len(b) != 8 && len(b) != 11 {
		return ""
	}
	s := fmt.Sprintf("%04d-%02d-%02d %02d:%02d:%02d.%d", int(b[0])<<8|int(b[1]), b[2], b[3], b[4], b[5], b[6], b[7])
	if len(b) == 11 {
		s += fmt.Sprintf(" %c%02d:%02d", b[8], b[9], b[10])
	}
	return s
}

// formatValue 는 MIB 의 형식 정보(enum, hint)를 반영해 값을 사람이 읽기 좋게 바꿉니다.
func (set *MibSet) formatValue(v SnmpValue, syn *Syntax) string {
	switch v.T {
	case tNoSuchObj:
		return "noSuchObject"
	case tNoSuchIns:
		return "noSuchInstance"
	case tEndOfMib:
		return "endOfMibView"
	case tNull:
		return "NULL"
	case tIPAddr:
		if len(v.Raw) == 4 {
			return net.IP(v.Raw).String()
		}
	case tOID:
		nm, _, inst := set.NameOID(v.OID)
		if inst != "" && !strings.Contains(nm, ".") && nm != oidString(v.OID) {
			return nm + "." + inst
		}
		return nm
	case tCounter32, tGauge32, tCounter64:
		return v.Big.String()
	case tTimeTicks:
		return fmt.Sprintf("%s (%s)", v.Big.String(), ticksText(v.Big.Uint64()))
	case tInteger:
		if syn != nil {
			for _, e := range syn.Enums {
				if e.Value == v.Int {
					return fmt.Sprintf("%s(%d)", e.Name, v.Int)
				}
			}
			if strings.HasPrefix(syn.Hint, "d-") {
				if n, err := strconv.Atoi(syn.Hint[2:]); err == nil && n > 0 && n < 10 {
					neg := v.Int < 0
					a := v.Int
					if neg {
						a = -a
					}
					s := strconv.FormatInt(a, 10)
					for len(s) <= n {
						s = "0" + s
					}
					s = s[:len(s)-n] + "." + s[len(s)-n:]
					if neg {
						s = "-" + s
					}
					return s
				}
			}
		}
		return strconv.FormatInt(v.Int, 10)
	case tOctet, tOpaque:
		b := v.Raw
		if syn != nil {
			if syn.Base == "BITS" {
				var names []string
				for _, e := range syn.Enums {
					idx := int(e.Value)
					if idx/8 < len(b) && b[idx/8]&(0x80>>uint(idx%8)) != 0 {
						names = append(names, fmt.Sprintf("%s(%d)", e.Name, e.Value))
					}
				}
				if len(names) == 0 {
					return "(none) [" + hexJoin(b, " ") + "]"
				}
				return strings.Join(names, ", ")
			}
			switch {
			case syn.TypeName == "DateAndTime" || strings.HasPrefix(syn.Hint, "2d-1d-1d,1d:1d:1d"):
				if s := dateAndTime(b); s != "" {
					return s
				}
			case syn.TypeName == "MacAddress" || syn.TypeName == "PhysAddress" || strings.HasPrefix(syn.Hint, "1x:"):
				if len(b) > 0 {
					return strings.ToLower(hexJoin(b, ":"))
				}
				return ""
			case strings.HasSuffix(syn.Hint, "a"):
				if printable(b) {
					return strings.TrimRight(string(b), "\x00")
				}
			}
		}
		if len(b) == 0 {
			return ""
		}
		if printable(b) {
			return string(b)
		}
		return hexJoin(b, " ")
	}
	return fmt.Sprintf("%x", v.Raw)
}
