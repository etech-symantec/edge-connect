package main

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

func TestSampleMibs(t *testing.T) {
	dir := os.Getenv("MIB_SAMPLE_DIR")
	if dir == "" {
		t.Skip("MIB_SAMPLE_DIR not set")
	}
	set := NewMibSet()
	files, _ := filepath.Glob(dir + "/*/*.txt")
	for _, f := range files {
		b, _ := os.ReadFile(f)
		set.parse(filepath.Base(f), string(b))
	}
	set.resolve()
	fmt.Println("files", len(files), "modules", len(set.Modules), "nodes", set.NodeCnt, "warnings", len(set.Warnings))
	for _, w := range set.Warnings {
		fmt.Println("WARN", w)
	}
	for _, name := range []string{"sysDescr", "ifDescr", "ifOperStatus", "blueCoatMgmt", "deviceSensorValue", "sgProxyHttpClientConnections", "ifPhysAddress", "sysUpTime", "deviceSensorUnits"} {
		n := set.NodeByName(name)
		if n == nil {
			fmt.Println("MISSING", name)
			continue
		}
		rs := set.ResolveSyntax(n.Module, n.Syntax)
		fmt.Printf("%s %s %s kind=%s syn=%+v\n", name, n.Module, oidString(n.OID), set.Classify(n), rs)
	}
}
