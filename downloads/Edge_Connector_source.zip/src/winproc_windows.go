//go:build windows

package main

import (
	"os/exec"
	"syscall"
)

// hideWindow 는 ssh.exe 실행 시 콘솔 창이 뜨지 않게 합니다.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}
