package main

// ProxySG Admin Tool: Local realm / local-user-list 의 관리자 계정 관리.
// 근거 KB: https://knowledge.broadcom.com/external/article/165595
//   Local realm 은 local-user-list 를 import 하므로, realm 에 사용자를 추가한다는 것은
//   해당 local-user-list 에 user 생성 -> password 설정 -> group 추가를 뜻한다.

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"
)

var nameRe = regexp.MustCompile(`^[A-Za-z0-9._@-]+$`)
var alnumRe = regexp.MustCompile(`[A-Za-z0-9]`)

type adminReq struct {
	Conn
	Realm       string `json:"realm"`
	UserList    string `json:"userlist"`
	NewUser     string `json:"newUser"`
	NewPass     string `json:"newPass"`
	NewPass2    string `json:"newPass2"`
	Groups      string `json:"groups"`
	CreateGroup bool   `json:"createGroup"`
	CreateRealm bool   `json:"createRealm"`
	PolicyOn    bool   `json:"policyEnable"`
	PolicyAuth  bool   `json:"policyAuth"`
	Access      string `json:"access"`
	Revision    string `json:"revision"`
	FinalBlock  string `json:"finalBlock"`
}

func (q *adminReq) groupList() []string {
	var out []string
	for _, g := range strings.Split(q.Groups, ",") {
		if g = strings.TrimSpace(g); g != "" {
			out = append(out, g)
		}
	}
	return out
}

func (q *adminReq) validate(kind string) error {
	q.Realm, q.UserList, q.NewUser = strings.TrimSpace(q.Realm), strings.TrimSpace(q.UserList), strings.TrimSpace(q.NewUser)
	if q.Realm == "" && q.UserList == "" {
		return fail(400, "Realm 이름 또는 local-user-list 중 하나는 입력해야 합니다.")
	}
	for _, v := range []struct{ l, s string }{{"Realm", q.Realm}, {"local-user-list", q.UserList}, {"사용자명", q.NewUser}} {
		if v.s != "" && (!nameRe.MatchString(v.s) || !alnumRe.MatchString(v.s)) {
			return fail(400, v.l+"에는 영문/숫자/._@- 만 사용할 수 있습니다.")
		}
	}
	for _, g := range q.groupList() {
		if !nameRe.MatchString(g) || !alnumRe.MatchString(g) {
			return fail(400, "그룹명 '"+g+"' 에는 영문/숫자/._@- 만 사용할 수 있습니다.")
		}
	}
	if kind == "list" {
		return nil
	}
	if q.NewUser == "" {
		return fail(400, "사용자명은 필수입니다.")
	}
	if kind == "add" || kind == "passwd" {
		if q.NewPass == "" {
			return fail(400, "비밀번호는 필수입니다.")
		}
		if q.NewPass != q.NewPass2 {
			return fail(400, "비밀번호 확인이 일치하지 않습니다.")
		}
		if strings.ContainsAny(q.NewPass, " \t\r\n") {
			return fail(400, "비밀번호에는 공백을 사용할 수 없습니다.")
		}
	}
	if kind == "add" {
		if len(q.groupList()) == 0 {
			return fail(400, "그룹을 하나 이상 입력하세요. (예: 관리자 그룹 sgadmins)")
		}
		if q.PolicyOn && q.Realm == "" {
			return fail(400, "Admin 규칙(CPL)을 만들려면 Realm 이름이 필요합니다.")
		}
		if q.Access != "RO" {
			q.Access = "RW"
		}
	}
	return nil
}

var adminErrRe = regexp.MustCompile(`(?im)^\s*%|\binvalid\b|\bnot found\b|\berror\b|does not exist`)

// hasErr 는 명령 echo 줄을 제외한 출력에 오류 표시가 있는지 봅니다.
func hasErr(out, cmd string) bool {
	return adminErrRe.MatchString(stripFirstEcho(strings.TrimSpace(out), cmd))
}

const (
	blockBegin = ";; BEGIN proxysg-admin-tool"
	blockEnd   = ";; END proxysg-admin-tool"
)

func buildAdminCPL(realm string, groups []string, access string, withAuth bool) string {
	lines := []string{fmt.Sprintf("%s realm=%s", blockBegin, realm)}
	if withAuth {
		lines = append(lines, "<Admin>", fmt.Sprintf("  authenticate(%s)", realm))
	}
	cond := ""
	if access == "RO" {
		cond = " admin.access=READ_ONLY"
	}
	lines = append(lines, "<Admin>")
	for _, g := range groups {
		lines = append(lines, fmt.Sprintf(`  group="%s"%s allow`, g, cond))
	}
	lines = append(lines, blockEnd)
	return strings.Join(lines, "\n") + "\n"
}

func stripAdminBlock(text, realm string) string {
	re := regexp.MustCompile(`(?ms)^` + regexp.QuoteMeta(blockBegin) + ` realm=` + regexp.QuoteMeta(realm) + `\s*\n.*?^` + regexp.QuoteMeta(blockEnd) + `[ \t]*\n?`)
	return re.ReplaceAllString(text, "")
}

// ---------------------------------------------------------------- 세션 도우미

type adminFn func(s *sshSession) (map[string]any, error)

// adminSession 은 접속 -> enable -> conf t 까지 하고 fn 을 실행합니다. 결과/오류에 마스킹된 로그를 붙입니다.
func adminSession(q *adminReq, needConfig bool, fn adminFn) (any, error) {
	s, err := startSSH(&q.Conn, q.NewPass)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	s.logf("[*] %s:%d 에 SSH 접속했습니다.", q.Host, q.Port)
	var res map[string]any
	err = s.ensurePrivileged(q.EnablePassword)
	if err == nil && needConfig {
		var out string
		out, err = s.run("conf t", runOpts{})
		if err == nil && !strings.Contains(lastLine(out), "(config") {
			err = fail(502, "Config 모드 진입에 실패했습니다. 권한(enable)을 확인하세요.")
		}
	}
	if err == nil {
		res, err = fn(s)
	}
	if needConfig {
		s.leaveConfig()
	}
	if err != nil {
		ae, ok := err.(*apiError)
		if !ok {
			ae = fail(502, err.Error())
		}
		if ae.Details == nil {
			ae.Details = map[string]any{}
		}
		ae.Details["log"] = s.Log
		return nil, ae
	}
	if res == nil {
		res = map[string]any{}
	}
	res["log"] = s.Log
	return res, nil
}

func realmLookup(s *sshSession, realm string) (bool, string) {
	cmd := "security local edit-realm " + realm
	out, _ := s.run(cmd, runOpts{})
	if hasErr(out, cmd) {
		return false, "" // 없는 realm 은 하위 모드에 들어가지 않으므로 exit 하지 않는다
	}
	view, _ := s.run("view", runOpts{})
	s.run("exit", runOpts{})
	return true, view
}

var userlistRe = regexp.MustCompile(`(?i)user[\s_-]*list\s*[:=]?\s*([A-Za-z0-9._@-]+)`)

func parseUserlist(view string) string {
	if m := userlistRe.FindStringSubmatch(view); m != nil {
		return m[1]
	}
	return ""
}

func ensureUserlist(s *sshSession, name string, allowCreate bool) error {
	cmd := "security local-user-list edit " + name
	out, _ := s.run(cmd, runOpts{})
	if hasErr(out, cmd) {
		if !allowCreate {
			return fail(404, fmt.Sprintf("local-user-list '%s' 가 없습니다. (생성 옵션을 켜면 새로 만듭니다)", name))
		}
		s.logf("[*] local-user-list '%s' 가 없어 새로 만듭니다.", name)
		cc := "security local-user-list create " + name
		out, _ = s.run(cc, runOpts{})
		if hasErr(out, cc) {
			return fail(502, fmt.Sprintf("local-user-list '%s' 생성에 실패했습니다.", name))
		}
		out, _ = s.run(cmd, runOpts{})
		if hasErr(out, cmd) {
			return fail(502, fmt.Sprintf("local-user-list '%s' 편집 모드 진입에 실패했습니다.", name))
		}
	}
	s.run("exit", runOpts{})
	return nil
}

// resolveExistingUserlist: 이미 있는 realm/user-list 에서 대상 user-list 를 정한다. (생성하지 않음)
func resolveExistingUserlist(s *sshSession, q *adminReq) (string, error) {
	ul := q.UserList
	if q.Realm != "" {
		ok, view := realmLookup(s, q.Realm)
		if !ok {
			return "", fail(404, fmt.Sprintf("realm '%s' 이(가) 없습니다.", q.Realm))
		}
		if ul == "" {
			ul = parseUserlist(view)
			if ul == "" {
				return "", fail(400, "realm 설정에서 local-user-list 이름을 자동으로 찾지 못했습니다. 'local-user-list' 칸에 직접 입력해 주세요.")
			}
			s.logf("[*] 탐지된 local-user-list: %s", ul)
		} else if !strings.Contains(view, ul) {
			s.logf("[!] 경고: realm '%s' 설정에서 '%s' 가 확인되지 않습니다.", q.Realm, ul)
		}
	}
	return ul, nil
}

func editUserlist(s *sshSession, ul string) error {
	cmd := "security local-user-list edit " + ul
	out, _ := s.run(cmd, runOpts{})
	if hasErr(out, cmd) {
		return fail(404, fmt.Sprintf("local-user-list '%s' 를 찾을 수 없습니다.", ul))
	}
	return nil
}

// ---------------------------------------------------------------- view 파싱 (들여쓰기 기반)

var userSkip = map[string]bool{"users": true, "user": true, "groups": true, "group": true, "lockout": true, "enabled": true,
	"disabled": true, "password": true, "failed": true, "last": true, "name": true, "local": true, "list": true,
	"view": true, "ok": true, "none": true, "status": true, "realm": true, "total": true, "hashed": true}

func indentOf(l string) int {
	l = strings.ReplaceAll(l, "\t", "        ")
	return len(l) - len(strings.TrimLeft(l, " "))
}

type adminUser struct {
	Name string `json:"name"`
	Info string `json:"info"`
}

var (
	usersHeadRe = regexp.MustCompile(`(?i)^\s*users?\s*:?\s*$`)
	groupsOnly  = regexp.MustCompile(`(?i)^groups?$`)
	kvRe        = regexp.MustCompile(`(?i)^(enabled|last activity)\s*:\s*(.+)$`)
	groupsKvRe  = regexp.MustCompile(`(?i)^groups?\s*:\s*(.*)$`)
	splitRe     = regexp.MustCompile(`[\s,]+`)
	tokSplitRe  = regexp.MustCompile(`[\s,:(]+`)
	userLineRe  = regexp.MustCompile(`(?i)^\s*user(?:\s*name)?\s*[:=]\s*"?([A-Za-z0-9._@-]+)"?`)
)

func userDetail(block []string) string {
	info := map[string]string{}
	var groups []string
	inGroups, gind := false, 0
	for _, ln := range block[1:] {
		st, ind := strings.TrimSpace(ln), indentOf(ln)
		if inGroups && ind > gind && !strings.HasSuffix(st, ":") {
			for _, g := range splitRe.Split(st, -1) {
				if g != "" {
					groups = append(groups, g)
				}
			}
			continue
		}
		inGroups = false
		if m := kvRe.FindStringSubmatch(st); m != nil {
			info[strings.ToLower(m[1])] = strings.TrimSpace(m[2])
			continue
		}
		if m := groupsKvRe.FindStringSubmatch(st); m != nil {
			if strings.TrimSpace(m[1]) != "" {
				for _, g := range splitRe.Split(m[1], -1) {
					if g != "" {
						groups = append(groups, g)
					}
				}
			} else {
				inGroups, gind = true, ind
			}
		}
	}
	var parts []string
	if v, ok := info["enabled"]; ok {
		parts = append(parts, "활성: "+v)
	}
	if len(groups) > 0 {
		parts = append(parts, "그룹: "+strings.Join(groups, ", "))
	}
	if v, ok := info["last activity"]; ok {
		parts = append(parts, "마지막 활동: "+v)
	}
	if len(parts) == 0 {
		return strings.TrimSpace(block[0])
	}
	return strings.Join(parts, " / ")
}

func parseUsers(view string) []adminUser {
	var lines []string
	for _, ln := range strings.Split(strings.ReplaceAll(view, "\r", ""), "\n") {
		ln = strings.TrimRight(ln, " \t")
		if strings.TrimSpace(ln) == "" || promptRe.MatchString("\n"+ln) || strings.TrimSpace(ln) == "view" {
			continue
		}
		lines = append(lines, ln)
	}
	users := []adminUser{}
	for i, head := range lines {
		if !usersHeadRe.MatchString(head) {
			continue
		}
		hind := indentOf(head)
		uind := -1
		var cur []string
		curName := ""
		flush := func() {
			if curName != "" {
				users = append(users, adminUser{curName, userDetail(cur)})
			}
			curName, cur = "", nil
		}
		for _, ln := range lines[i+1:] {
			st, ind := strings.TrimSpace(ln), indentOf(ln)
			if !alnumRe.MatchString(st) {
				continue
			}
			if ind <= hind && (strings.HasSuffix(st, ":") || groupsOnly.MatchString(st)) {
				break
			}
			tok := tokSplitRe.Split(strings.Trim(st, `"`), 2)[0]
			tok = strings.Trim(tok, `"`)
			valid := nameRe.MatchString(tok) && !userSkip[strings.ToLower(tok)]
			if uind < 0 {
				if strings.HasSuffix(st, ":") || !valid {
					continue
				}
				uind = ind
			}
			if ind == uind {
				flush()
				if valid {
					curName, cur = tok, []string{ln}
				}
			} else if ind > uind && curName != "" {
				cur = append(cur, ln)
			}
		}
		flush()
		if len(users) > 0 {
			return users
		}
	}
	seen := map[string]bool{}
	for _, ln := range lines {
		if m := userLineRe.FindStringSubmatch(ln); m != nil && !seen[m[1]] {
			seen[m[1]] = true
			users = append(users, adminUser{m[1], strings.TrimSpace(ln)})
		}
	}
	return users
}

func containsName(text, name string) bool {
	re := regexp.MustCompile(`(?:^|[^\w.@-])` + regexp.QuoteMeta(name) + `(?:[^\w.@-]|$)`)
	return re.MatchString(text)
}

// ---------------------------------------------------------------- API

func apiAdminList(r *http.Request) (any, error) {
	var q adminReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if err := q.validate("list"); err != nil {
		return nil, err
	}
	return adminSession(&q, true, func(s *sshSession) (map[string]any, error) {
		ul, err := resolveExistingUserlist(s, &q)
		if err != nil {
			return nil, err
		}
		if err := editUserlist(s, ul); err != nil {
			return nil, err
		}
		view, _ := s.run("view", runOpts{})
		s.run("exit", runOpts{})
		users := parseUsers(view)
		if len(users) > 0 {
			names := make([]string, len(users))
			for i, u := range users {
				names[i] = u.Name
			}
			s.logf("\n[OK] '%s' 에 등록된 사용자 %d명: %s", ul, len(users), strings.Join(names, ", "))
		} else {
			s.logf("\n[!] 사용자 이름을 인식하지 못했습니다. 위 'view' 원문을 확인해 주세요.")
		}
		return map[string]any{"userlist": ul, "users": users}, nil
	})
}

// apiAdminPlan: 장비를 변경하지 않고 Admin 규칙(CPL)과 합쳐진 최종 Local Policy 를 미리 만든다.
func apiAdminPlan(r *http.Request) (any, error) {
	var q adminReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if err := q.validate("add"); err != nil {
		return nil, err
	}
	block := buildAdminCPL(q.Realm, q.groupList(), q.Access, q.PolicyAuth)
	res := map[string]any{"cpl": block}
	if !q.PolicyOn {
		return res, nil
	}
	s, err := openPrivileged(&q.Conn, q.NewPass)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	cur, err := readLocalPolicy(s)
	if err != nil {
		return nil, err
	}
	merged := mergeAdminBlock(cur, q.Realm, block)
	marker := chooseApplyMarker(merged)
	res["policy"] = policyInfo(cur)
	res["finalBlock"] = buildFinalBlock(merged, marker)
	res["applyMarker"] = marker
	return res, nil
}

func mergeAdminBlock(cur, realm, block string) string {
	base := normalizePolicyFormatting(stripAdminBlock(cur, realm))
	if base == "" {
		return normalizePolicyFormatting(block)
	}
	return normalizePolicyFormatting(base + "\n\n" + block)
}

func backupPolicy(host, text string) (string, error) {
	dir := filepath.Join(filepath.Dir(knownHostsPath()), "backups")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	name := fmt.Sprintf("local_policy_%s_%s.txt", regexp.MustCompile(`[^A-Za-z0-9._-]`).ReplaceAllString(host, "_"), time.Now().Format("20060102_150405"))
	p := filepath.Join(dir, name)
	return p, os.WriteFile(p, []byte(text), 0o600)
}

func apiAdminAdd(r *http.Request) (any, error) {
	var q adminReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if err := q.validate("add"); err != nil {
		return nil, err
	}
	groups := q.groupList()
	var marker, content string
	if q.PolicyOn {
		var err error
		if marker, content, err = parseFinalBlock(q.FinalBlock); err != nil {
			return nil, fail(400, "Admin 규칙 미리보기를 먼저 생성하고 확인하세요. ("+err.Error()+")")
		}
	}
	return adminSession(&q, true, func(s *sshSession) (map[string]any, error) {
		ul := q.UserList
		if q.Realm != "" {
			exists, view := realmLookup(s, q.Realm)
			if exists {
				if ul == "" {
					if ul = parseUserlist(view); ul == "" {
						return nil, fail(400, "realm 설정에서 local-user-list 이름을 자동으로 찾지 못했습니다. 'local-user-list' 칸에 직접 입력해 주세요.")
					}
					s.logf("[*] 탐지된 local-user-list: %s", ul)
				} else if !strings.Contains(view, ul) {
					s.logf("[!] 경고: realm '%s' 설정에서 '%s' 가 확인되지 않습니다. 다른 user-list 를 수정하면 realm 에 반영되지 않을 수 있습니다.", q.Realm, ul)
				}
			} else {
				if !q.CreateRealm {
					return nil, fail(404, fmt.Sprintf("realm '%s' 이(가) 없습니다. (생성 옵션을 켜면 새로 만듭니다)", q.Realm))
				}
				if ul == "" {
					ul = q.Realm + "_users"
					s.logf("[*] local-user-list 이름이 비어 있어 '%s' 로 사용합니다.", ul)
				}
				if err := ensureUserlist(s, ul, true); err != nil {
					return nil, err
				}
				s.logf("[*] realm '%s' 이(가) 없어 새로 만들고 '%s' 를 연결합니다.", q.Realm, ul)
				if out, _ := s.run("security local create-realm "+q.Realm, runOpts{}); hasErr(out, "security local create-realm "+q.Realm) {
					return nil, fail(502, fmt.Sprintf("realm '%s' 생성에 실패했습니다.", q.Realm))
				}
				if out, _ := s.run("security local edit-realm "+q.Realm, runOpts{}); hasErr(out, "security local edit-realm "+q.Realm) {
					return nil, fail(502, fmt.Sprintf("realm '%s' 편집 모드 진입에 실패했습니다.", q.Realm))
				}
				out, _ := s.run("local-user-list "+ul, runOpts{})
				linkErr := hasErr(out, "local-user-list "+ul)
				s.run("exit", runOpts{})
				if linkErr {
					return nil, fail(502, fmt.Sprintf("realm 에 local-user-list '%s' 연결에 실패했습니다.", ul))
				}
			}
		}
		if err := ensureUserlist(s, ul, q.CreateRealm); err != nil {
			return nil, err
		}
		if err := editUserlist(s, ul); err != nil {
			return nil, err
		}
		if q.CreateGroup {
			for _, g := range groups {
				s.run("group create "+g, runOpts{}) // 이미 있으면 오류가 나와도 무시
			}
		}
		s.run("user create "+q.NewUser, runOpts{}) // 이미 있으면 무시하고 edit 로 진행
		cmd := "user edit " + q.NewUser
		if out, _ := s.run(cmd, runOpts{}); hasErr(out, cmd) {
			return nil, fail(502, fmt.Sprintf("사용자 '%s' 편집 모드 진입에 실패했습니다.", q.NewUser))
		}
		if out, _ := s.run("password "+q.NewPass, runOpts{Hide: true}); hasErr(out, "password "+q.NewPass) {
			return nil, fail(502, "비밀번호 설정에 실패했습니다.")
		}
		for _, g := range groups {
			if out, _ := s.run("group add "+g, runOpts{}); hasErr(out, "group add "+g) {
				s.logf("[!] 그룹 '%s' 추가 실패 (그룹이 없다면 '그룹이 없으면 생성'을 체크하세요)", g)
			}
		}
		s.run("exit", runOpts{}) // user 편집 종료
		view, _ := s.run("view", runOpts{})
		s.run("exit", runOpts{}) // user-list 편집 종료
		users := parseUsers(view)
		userOK := containsName(view, q.NewUser)
		if userOK {
			s.logf("\n[OK] 사용자 '%s' 가 '%s' 에 등록된 것을 확인했습니다.", q.NewUser, ul)
		} else {
			s.logf("\n[!] 명령은 실행했지만 view 결과에서 사용자를 확인하지 못했습니다. 장비에서 직접 확인해 주세요.")
		}
		res := map[string]any{"userlist": ul, "users": users, "userVerified": userOK, "policyApplied": false}

		if q.PolicyOn {
			// user-list 편집을 마친 상태 = (config). 한 단계만 나가 enable(#) 모드로 돌아간다.
			if out, _ := s.run("exit", runOpts{}); strings.Contains(lastLine(out), "(config") {
				s.run("exit", runOpts{})
			}
			cur, err := readLocalPolicy(s)
			if err != nil {
				return nil, fail(502, "사용자는 등록했지만 현재 Local Policy 를 읽지 못해 Admin 규칙은 적용하지 않았습니다: "+err.Error())
			}
			if q.Revision != "" && revisionOf(cur) != q.Revision {
				return nil, failCode(409, "POLICY_CHANGED", "사용자는 등록했지만, 미리보기 이후 장비의 Local Policy가 변경되어 Admin 규칙은 적용하지 않았습니다. 미리보기를 다시 생성하세요.", nil)
			}
			if strings.TrimSpace(cur) != "" {
				if p, err := backupPolicy(q.Host, cur); err == nil {
					s.logf("[*] 기존 local policy 백업: %s", p)
					res["backup"] = p
				} else {
					s.logf("[!] 백업 저장 실패: %v", err)
				}
			}
			out, err := installLocalPolicy(s, marker, content)
			if err != nil || adminErrRe.MatchString(out) {
				return nil, fail(502, "local policy 설치 중 장비가 오류를 반환했습니다: "+extractApplyMessages(out))
			}
			after, err := readLocalPolicy(s)
			if err != nil {
				return nil, fail(502, "Admin 규칙 적용 후 재검증용 조회에 실패했습니다: "+err.Error())
			}
			if mm, ok := linesEqual(nonBlankLines(content), nonBlankLines(after)); !ok {
				return nil, fail(500, fmt.Sprintf("Admin 규칙 적용 후 재검증에 실패했습니다. (불일치 %d줄) 장비 Local Policy 를 확인하세요.", mm))
			}
			s.logf("[OK] local policy 에 Admin 규칙을 설치하고 재검증했습니다.")
			res["policyApplied"] = true
			res["policy"] = policyInfo(after)
		} else {
			s.logf("     (Admin 정책을 넣지 않았으므로 VPM 등에 Admin Access/Authentication 규칙이 있어야 관리 콘솔 권한이 적용됩니다.)")
		}
		return res, nil
	})
}

func apiAdminPassword(r *http.Request) (any, error) {
	var q adminReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if err := q.validate("passwd"); err != nil {
		return nil, err
	}
	return adminSession(&q, true, func(s *sshSession) (map[string]any, error) {
		ul, err := resolveExistingUserlist(s, &q)
		if err != nil {
			return nil, err
		}
		if err := editUserlist(s, ul); err != nil {
			return nil, err
		}
		cmd := "user edit " + q.NewUser
		if out, _ := s.run(cmd, runOpts{}); hasErr(out, cmd) {
			return nil, fail(404, fmt.Sprintf("사용자 '%s' 가 '%s' 에 없습니다.", q.NewUser, ul))
		}
		if out, _ := s.run("password "+q.NewPass, runOpts{Hide: true}); hasErr(out, "password "+q.NewPass) {
			return nil, fail(502, "비밀번호 변경에 실패했습니다.")
		}
		s.run("exit", runOpts{})
		s.run("exit", runOpts{})
		s.logf("\n[OK] 사용자 '%s' 의 비밀번호를 변경했습니다. (다음 로그인부터 적용)", q.NewUser)
		return map[string]any{"userlist": ul}, nil
	})
}

func apiAdminDelete(r *http.Request) (any, error) {
	var q adminReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if err := q.validate("delete"); err != nil {
		return nil, err
	}
	return adminSession(&q, true, func(s *sshSession) (map[string]any, error) {
		ul, err := resolveExistingUserlist(s, &q)
		if err != nil {
			return nil, err
		}
		if err := editUserlist(s, ul); err != nil {
			return nil, err
		}
		before, _ := s.run("view", runOpts{})
		if !containsName(before, q.NewUser) {
			s.logf("[!] view 결과에서 '%s' 를 확인하지 못했습니다. 그래도 삭제를 시도합니다.", q.NewUser)
		}
		cmd := "user delete " + q.NewUser
		out, _ := s.run(cmd, runOpts{Patterns: []string{"y or n"}})
		if strings.Contains(tailN(out, 100), "y or n") {
			out, _ = s.run("y", runOpts{})
		}
		if hasErr(out, "y") {
			return nil, fail(502, fmt.Sprintf("사용자 '%s' 삭제에 실패했습니다. (없는 사용자일 수 있습니다)", q.NewUser))
		}
		after, _ := s.run("view", runOpts{})
		s.run("exit", runOpts{})
		users := parseUsers(after)
		if containsName(after, q.NewUser) {
			return nil, fail(500, fmt.Sprintf("삭제 명령은 실행했지만 view 에 '%s' 가 아직 보입니다. 장비에서 확인해 주세요.", q.NewUser))
		}
		s.logf("\n[OK] 사용자 '%s' 를 '%s' 에서 삭제했습니다.", q.NewUser, ul)
		s.logf("     (그룹/local policy 규칙은 그대로입니다. 이 계정으로의 관리 콘솔 로그인은 더 이상 되지 않습니다.)")
		return map[string]any{"userlist": ul, "users": users}, nil
	})
}
