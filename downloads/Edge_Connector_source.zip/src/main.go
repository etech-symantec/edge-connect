// ProxySG Policy Trace Editor + Admin Tool (v1.29)
//
// 로컬(127.0.0.1) 전용 웹 서버입니다. 화면(HTML)은 exe 에 내장되어 있고,
// 장비 접속은 Windows OpenSSH Client(ssh.exe)와 Management HTTPS 로 수행합니다.
package main

import (
	"crypto/rand"
	"crypto/subtle"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

//go:embed web/index.html
var indexHTML string

const appVersion = "1.29"

// apiError 는 화면(api())이 e.message / e.code / e.details 로 읽는 오류 형식입니다.
type apiError struct {
	Status  int
	Message string
	Code    string
	Details map[string]any
}

func (e *apiError) Error() string { return e.Message }

func fail(status int, msg string) *apiError { return &apiError{Status: status, Message: msg} }
func failCode(status int, code, msg string, details map[string]any) *apiError {
	return &apiError{Status: status, Message: msg, Code: code, Details: details}
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	b, err := json.Marshal(v)
	if err != nil {
		status = 500
		b = []byte(`{"ok":false,"error":"encode error"}`)
	}
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	w.Write(b)
}

func writeErr(w http.ResponseWriter, err error) {
	if ae, ok := err.(*apiError); ok {
		body := map[string]any{"ok": false, "error": ae.Message}
		if ae.Code != "" {
			body["code"] = ae.Code
		}
		if ae.Details != nil {
			body["details"] = ae.Details
		}
		writeJSON(w, ae.Status, body)
		return
	}
	writeJSON(w, 500, map[string]any{"ok": false, "error": err.Error()})
}

type server struct {
	token string
	port  int
	quit  chan struct{}
}

func (s *server) hostOK(r *http.Request) bool {
	h := strings.ToLower(r.Host)
	return h == fmt.Sprintf("127.0.0.1:%d", s.port) || h == fmt.Sprintf("localhost:%d", s.port)
}

func (s *server) tokenOK(r *http.Request) bool {
	return subtle.ConstantTimeCompare([]byte(r.Header.Get("X-App-Token")), []byte(s.token)) == 1
}

type handlerFunc func(r *http.Request) (any, error)

func (s *server) api(h handlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !s.hostOK(r) || !s.tokenOK(r) {
			writeJSON(w, 403, map[string]any{"ok": false, "error": "forbidden"})
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 4<<20)
		res, err := h(r)
		if err != nil {
			writeErr(w, err)
			return
		}
		out := map[string]any{"ok": true}
		if m, ok := res.(map[string]any); ok {
			for k, v := range m {
				out[k] = v
			}
		}
		writeJSON(w, 200, out)
	}
}

func (s *server) routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		if !s.hostOK(r) {
			http.Error(w, "forbidden", 403)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("Content-Security-Policy", "default-src 'self' 'unsafe-inline' data:; connect-src 'self'; frame-ancestors 'none'")
		fmt.Fprint(w, strings.Replace(indexHTML, "__APP_TOKEN__", s.token, 1))
	})
	mux.HandleFunc("/api/system", s.api(apiSystem))
	mux.HandleFunc("/api/shutdown", s.api(func(r *http.Request) (any, error) {
		go func() { time.Sleep(300 * time.Millisecond); close(s.quit) }()
		return map[string]any{}, nil
	}))
	// --- 공통 접속 확인
	mux.HandleFunc("/api/test-connection", s.api(apiTestConnection))
	mux.HandleFunc("/api/test-management", s.api(apiTestManagement))
	// --- Trace Editor
	mux.HandleFunc("/api/read-policy", s.api(apiReadPolicy))
	mux.HandleFunc("/api/preview", s.api(apiPreview))
	mux.HandleFunc("/api/apply-policy", s.api(apiApplyPolicy))
	mux.HandleFunc("/api/prepare-remove-trace-policy", s.api(apiPrepareRemove))
	mux.HandleFunc("/api/list-traces", s.api(apiListTraces))
	mux.HandleFunc("/api/read-trace", s.api(apiReadTrace))
	mux.HandleFunc("/api/delete-trace", s.api(apiDeleteTrace))
	mux.HandleFunc("/api/list-accesslogs", s.api(apiListAccessLogs))
	mux.HandleFunc("/api/read-accesslog", s.api(apiReadAccessLog))
	// --- Admin Tool
	mux.HandleFunc("/api/admin/list-users", s.api(apiAdminList))
	mux.HandleFunc("/api/admin/plan", s.api(apiAdminPlan))
	mux.HandleFunc("/api/admin/add", s.api(apiAdminAdd))
	mux.HandleFunc("/api/admin/password", s.api(apiAdminPassword))
	mux.HandleFunc("/api/admin/delete", s.api(apiAdminDelete))
	return mux
}

func openBrowser(url string) {
	switch runtime.GOOS {
	case "windows":
		exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		exec.Command("open", url).Start()
	default:
		exec.Command("xdg-open", url).Start()
	}
}

func main() {
	// ssh.exe 가 SSH_ASKPASS 로 이 프로그램을 다시 실행하면 비밀번호만 출력하고 끝낸다.
	if os.Getenv("PROXYSG_ASKPASS_MODE") == "1" {
		fmt.Print(os.Getenv("PROXYSG_ASKPASS_PASSWORD"))
		return
	}
	tb := make([]byte, 24)
	rand.Read(tb)
	s := &server{token: hex.EncodeToString(tb), quit: make(chan struct{})}
	addr := "127.0.0.1:0"
	if p := os.Getenv("PROXYSG_PORT"); p != "" {
		addr = "127.0.0.1:" + p
	}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintln(os.Stderr, "listen:", err)
		os.Exit(1)
	}
	s.port = ln.Addr().(*net.TCPAddr).Port
	url := fmt.Sprintf("http://127.0.0.1:%d/", s.port)
	srv := &http.Server{Handler: s.routes(), ReadHeaderTimeout: 10 * time.Second}
	go srv.Serve(ln)
	if os.Getenv("PROXYSG_NO_BROWSER") == "1" {
		fmt.Println(url)
		os.Stdout.Sync()
	} else {
		openBrowser(url)
	}
	<-s.quit
	srv.Close()
}
