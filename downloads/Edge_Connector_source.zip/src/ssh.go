package main

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Conn 은 화면(conn())이 모든 API 요청에 실어 보내는 장비 접속 정보입니다.
type Conn struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	Username       string `json:"username"`
	Password       string `json:"password"`
	EnablePassword string `json:"enablePassword"`
	MgmtProtocol   string `json:"mgmtProtocol"`
	MgmtPort       int    `json:"mgmtPort"`
	MgmtUsername   string `json:"mgmtUsername"`
	MgmtPassword   string `json:"mgmtPassword"`
	MgmtSkipTLS    bool   `json:"mgmtSkipTLS"`
}

var (
	hostRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._:-]{0,252}$`)
	userRe = regexp.MustCompile(`^[A-Za-z0-9_][A-Za-z0-9._@\\-]{0,127}$`)

	ansiRe   = regexp.MustCompile(`\x1b\[[0-9;?]*[A-Za-z]|\x1b[()][A-Za-z0-9]|\x1b\][^\x07]*\x07`)
	moreRe   = regexp.MustCompile(`--More--[\x08 \r]*`)
	promptRe = regexp.MustCompile(`(?:^|\n)[^\s<;][^\s]*[>#](?:\([^)\n]*\))?[ \t]*$`)
)

func (c *Conn) validateSSH() error {
	c.Host = strings.TrimSpace(c.Host)
	c.Username = strings.TrimSpace(c.Username)
	if c.Port == 0 {
		c.Port = 22
	}
	if c.Host == "" || c.Username == "" || c.Password == "" {
		return fail(400, "장비 IP, SSH 계정, SSH 비밀번호를 입력하세요.")
	}
	if !hostRe.MatchString(c.Host) {
		return fail(400, "장비 IP / Hostname 형식이 올바르지 않습니다.")
	}
	if !userRe.MatchString(c.Username) {
		return fail(400, "SSH 계정 형식이 올바르지 않습니다.")
	}
	if c.Port < 1 || c.Port > 65535 {
		return fail(400, "SSH Port 범위가 올바르지 않습니다.")
	}
	if strings.ContainsAny(c.Password, "\r\n") || strings.ContainsAny(c.EnablePassword, "\r\n") {
		return fail(400, "비밀번호에 줄바꿈을 사용할 수 없습니다.")
	}
	if c.EnablePassword == "" {
		c.EnablePassword = c.Password
	}
	return nil
}

func findSSH() (string, error) {
	if p := os.Getenv("PROXYSG_SSH_PATH"); p != "" { // 테스트/예외 상황용
		return p, nil
	}
	if p, err := exec.LookPath("ssh"); err == nil {
		return p, nil
	}
	if runtime.GOOS == "windows" {
		root := os.Getenv("SystemRoot")
		if root == "" {
			root = `C:\Windows`
		}
		p := filepath.Join(root, "System32", "OpenSSH", "ssh.exe")
		if _, err := os.Stat(p); err == nil {
			return p, nil
		}
	}
	return "", errors.New("Windows OpenSSH Client(ssh.exe)를 찾지 못했습니다.")
}

func knownHostsPath() string {
	base := os.Getenv("LOCALAPPDATA")
	if base == "" {
		base, _ = os.UserConfigDir()
	}
	if base == "" {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "ProxySGPolicyEditor")
	os.MkdirAll(dir, 0o700)
	return filepath.Join(dir, "known_hosts")
}

// sshSession 은 ssh.exe 를 자식 프로세스로 띄워 ProxySG CLI 를 조작합니다.
type sshSession struct {
	cmd     *exec.Cmd
	stdin   io.WriteCloser
	mu      sync.Mutex
	buf     []byte
	errBuf  bytes.Buffer
	last    time.Time
	exited  bool
	secrets []string
	Log     []string // 마스킹된 명령/출력 로그
}

type lockedWriter struct {
	s   *sshSession
	err bool
}

func (w lockedWriter) Write(p []byte) (int, error) {
	w.s.mu.Lock()
	defer w.s.mu.Unlock()
	if w.err {
		w.s.errBuf.Write(p)
	} else {
		w.s.buf = append(w.s.buf, p...)
		w.s.last = time.Now()
	}
	return len(p), nil
}

func (s *sshSession) mask(t string) string {
	for _, sec := range s.secrets {
		if sec != "" {
			t = strings.ReplaceAll(t, sec, "********")
		}
	}
	return t
}

func (s *sshSession) logf(format string, a ...any) {
	s.Log = append(s.Log, s.mask(fmt.Sprintf(format, a...)))
}

func cleanTerminal(t string) string {
	t = ansiRe.ReplaceAllString(t, "")
	t = moreRe.ReplaceAllString(t, "")
	t = strings.ReplaceAll(t, "\x08", "")
	t = strings.ReplaceAll(t, "\r", "")
	return t
}

func startSSH(c *Conn, extraSecrets ...string) (*sshSession, error) {
	if err := c.validateSSH(); err != nil {
		return nil, err
	}
	sshPath, err := findSSH()
	if err != nil {
		return nil, fail(500, err.Error()+" Windows 선택적 기능에서 'OpenSSH Client'를 설치하세요.")
	}
	self, _ := os.Executable()
	args := []string{
		"-tt", "-p", strconv.Itoa(c.Port), "-l", c.Username,
		"-o", "StrictHostKeyChecking=accept-new",
		"-o", "UserKnownHostsFile=" + knownHostsPath(),
		"-o", "ConnectTimeout=15",
		"-o", "ServerAliveInterval=10", "-o", "ServerAliveCountMax=3",
		"-o", "NumberOfPasswordPrompts=1",
		"-o", "PreferredAuthentications=password,keyboard-interactive",
		"-o", "PubkeyAuthentication=no",
		"-o", "KbdInteractiveAuthentication=yes",
		"-o", "LogLevel=ERROR",
		c.Host,
	}
	cmd := exec.Command(sshPath, args...)
	cmd.Env = append(os.Environ(),
		"SSH_ASKPASS="+self, "SSH_ASKPASS_REQUIRE=force", "DISPLAY=proxysg-editor:0",
		"PROXYSG_ASKPASS_MODE=1", "PROXYSG_ASKPASS_PASSWORD="+c.Password,
	)
	hideWindow(cmd)
	s := &sshSession{cmd: cmd, secrets: append([]string{c.Password, c.EnablePassword}, extraSecrets...)}
	cmd.Stdout = lockedWriter{s: s}
	cmd.Stderr = lockedWriter{s: s, err: true}
	if s.stdin, err = cmd.StdinPipe(); err != nil {
		return nil, fail(500, err.Error())
	}
	if err = cmd.Start(); err != nil {
		return nil, fail(500, "ssh 실행 실패: "+err.Error())
	}
	go func() {
		cmd.Wait()
		s.mu.Lock()
		s.exited = true
		s.mu.Unlock()
	}()
	// 첫 프롬프트(sg> 또는 sg#)까지 대기
	if _, err = s.waitPrompt(nil, 30*time.Second); err != nil {
		s.Close()
		return nil, s.connErr(err)
	}
	return s, nil
}

// connErr 는 ssh 의 stderr 를 읽어 사용자가 이해할 수 있는 메시지로 바꿉니다.
func (s *sshSession) connErr(err error) error {
	s.mu.Lock()
	e := strings.TrimSpace(s.errBuf.String())
	s.mu.Unlock()
	low := strings.ToLower(e)
	switch {
	case strings.Contains(low, "remote host identification has changed"), strings.Contains(low, "host key verification failed"):
		return fail(502, "장비 SSH Host Key가 이전 연결과 다릅니다. 보안을 위해 연결을 중단했습니다. 장비 또는 Host Key가 변경되었는지 확인하세요.")
	case strings.Contains(low, "permission denied"):
		return fail(401, "SSH 인증에 실패했습니다. 계정/비밀번호를 확인하세요.")
	case strings.Contains(low, "timed out"), strings.Contains(low, "connection refused"), strings.Contains(low, "no route"), strings.Contains(low, "could not resolve"):
		return fail(502, "장비에 SSH로 연결하지 못했습니다: "+s.mask(firstLine(e)))
	}
	if e != "" {
		return fail(502, "SSH 연결 실패: "+s.mask(firstLine(e)))
	}
	return fail(502, "SSH 연결 실패: "+err.Error())
}

func firstLine(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return strings.TrimSpace(s[:i])
	}
	return s
}

var errTimeout = errors.New("장비 응답 대기 시간이 초과되었습니다.")

// waitPrompt 는 출력이 잠시 멈추고 프롬프트(또는 지정한 패턴)로 끝날 때까지 읽습니다.
func (s *sshSession) waitPrompt(patterns []string, timeout time.Duration) (string, error) {
	deadline := time.Now().Add(timeout)
	const quiet = 200 * time.Millisecond
	for {
		s.mu.Lock()
		raw := string(s.buf)
		since := time.Since(s.last)
		exited := s.exited
		s.mu.Unlock()

		clean := cleanTerminal(raw)
		tail := raw
		if len(tail) > 40 {
			tail = tail[len(tail)-40:]
		}
		if strings.Contains(tail, "--More--") && since > 30*time.Millisecond {
			s.mu.Lock()
			s.buf = moreRe.ReplaceAll(s.buf, nil)
			s.mu.Unlock()
			io.WriteString(s.stdin, " ")
			continue
		}
		if since >= quiet {
			if promptRe.MatchString(clean) {
				s.take()
				return clean, nil
			}
			for _, p := range patterns {
				ct := clean
				if len(ct) > 80 {
					ct = ct[len(ct)-80:]
				}
				if strings.Contains(ct, p) {
					s.take()
					return clean, nil
				}
			}
		}
		if exited {
			s.take()
			return clean, errors.New("ssh 연결이 종료되었습니다.")
		}
		if time.Now().After(deadline) {
			s.take()
			return clean, errTimeout
		}
		time.Sleep(15 * time.Millisecond)
	}
}

func (s *sshSession) take() {
	s.mu.Lock()
	s.buf = nil
	s.mu.Unlock()
}

// run 은 명령 하나를 보내고 다음 프롬프트까지의 출력을 돌려줍니다.
// hide 이면 명령(비밀번호 포함)을 로그에 남기지 않고, quiet 이면 출력을 로그에 싣지 않습니다.
func (s *sshSession) run(cmd string, o runOpts) (string, error) {
	s.take()
	if _, err := io.WriteString(s.stdin, cmd+"\n"); err != nil {
		return "", errors.New("ssh 연결이 종료되었습니다.")
	}
	if o.Timeout == 0 {
		o.Timeout = 30 * time.Second
	}
	out, err := s.waitPrompt(o.Patterns, o.Timeout)
	if o.Hide {
		s.logf(">>> ********")
	} else {
		s.logf(">>> %s", cmd)
	}
	if o.Quiet {
		s.logf("(출력 %d줄, 로그 생략)", len(strings.Split(strings.TrimSpace(out), "\n")))
	} else if body := strings.TrimSpace(redactHashes(s.mask(out))); body != "" {
		s.Log = append(s.Log, stripFirstEcho(body, cmd))
	}
	return out, err
}

type runOpts struct {
	Patterns []string
	Hide     bool
	Quiet    bool
	Timeout  time.Duration
}

func stripFirstEcho(body, cmd string) string {
	lines := strings.Split(body, "\n")
	if len(lines) > 0 && strings.TrimSpace(lines[0]) == strings.TrimSpace(cmd) {
		lines = lines[1:]
	}
	return strings.Join(lines, "\n")
}

// enable 로 특권 모드(#)에 들어갑니다.
func (s *sshSession) ensurePrivileged(enablePass string) error {
	probe, err := s.run("", runOpts{})
	if err != nil {
		return err
	}
	if lastLine(probe) != "" && strings.Contains(lastLine(probe), "#") {
		return nil
	}
	out, err := s.run("enable", runOpts{Patterns: []string{"assword:"}})
	if err != nil {
		return err
	}
	if strings.Contains(tailN(out, 40), "assword") {
		out, err = s.run(enablePass, runOpts{Hide: true})
		if err != nil {
			return err
		}
		if regexp.MustCompile(`(?i)assword:|denied|incorrect|fail`).MatchString(tailN(out, 80)) {
			return fail(401, "Enable 비밀번호가 맞지 않습니다.")
		}
	}
	if !strings.Contains(lastLine(out), "#") {
		probe, _ = s.run("", runOpts{})
		if !strings.Contains(lastLine(probe), "#") {
			return fail(502, "Enable(특권) 모드 진입에 실패했습니다.")
		}
	}
	return nil
}

func lastLine(t string) string {
	t = strings.TrimRight(t, " \t\r\n")
	if i := strings.LastIndexByte(t, '\n'); i >= 0 {
		return strings.TrimSpace(t[i+1:])
	}
	return strings.TrimSpace(t)
}

func tailN(t string, n int) string {
	if len(t) > n {
		return t[len(t)-n:]
	}
	return t
}

func (s *sshSession) leaveConfig() {
	for i := 0; i < 4; i++ {
		if _, err := io.WriteString(s.stdin, "exit\n"); err != nil {
			return
		}
		time.Sleep(150 * time.Millisecond)
	}
}

func (s *sshSession) Close() {
	if s.stdin != nil {
		io.WriteString(s.stdin, "exit\n")
		s.stdin.Close()
	}
	if s.cmd != nil && s.cmd.Process != nil {
		done := make(chan struct{})
		go func() {
			for i := 0; i < 20; i++ {
				s.mu.Lock()
				ex := s.exited
				s.mu.Unlock()
				if ex {
					break
				}
				time.Sleep(50 * time.Millisecond)
			}
			close(done)
		}()
		<-done
		s.cmd.Process.Kill()
	}
}

// inlinePolicyLocal 은 config 모드에서 'inline policy local <marker>' 로 정책 전체를 교체합니다.
func (s *sshSession) inlinePolicyLocal(marker, content string) (string, error) {
	s.take()
	if _, err := io.WriteString(s.stdin, "inline policy local "+marker+"\n"); err != nil {
		return "", errors.New("ssh 연결이 종료되었습니다.")
	}
	time.Sleep(700 * time.Millisecond)
	s.take()
	for _, ln := range strings.Split(content, "\n") {
		io.WriteString(s.stdin, ln+"\n")
		time.Sleep(12 * time.Millisecond)
	}
	io.WriteString(s.stdin, marker+"\n")
	out, err := s.waitPrompt(nil, 90*time.Second)
	s.logf(">>> inline policy local %s  ...(CPL %d줄)...  %s", marker, len(strings.Split(content, "\n")), marker)
	if body := strings.TrimSpace(s.mask(out)); body != "" {
		s.Log = append(s.Log, body)
	}
	return out, err
}

var hashLineRe = regexp.MustCompile(`\$PBKDF2\S*`)

// redactHashes 는 로그에 비밀번호 해시가 그대로 나오지 않게 가립니다.
func redactHashes(text string) string {
	var out []string
	inHash := false
	for _, ln := range strings.Split(text, "\n") {
		st := strings.TrimSpace(ln)
		if inHash && st != "" && !strings.ContainsAny(st, " \t") && !strings.HasSuffix(st, ":") {
			out = append(out, "        ********(해시 숨김)")
			continue
		}
		inHash = false
		if strings.Contains(ln, "$PBKDF2") {
			ln = hashLineRe.ReplaceAllString(ln, "********(해시 숨김)")
			inHash = true
		} else if strings.HasSuffix(st, "Hashed Password:") {
			inHash = true
		}
		out = append(out, ln)
	}
	return strings.Join(out, "\n")
}
