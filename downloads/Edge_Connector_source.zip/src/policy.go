package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"sort"
	"strings"
	"time"
)

// ---------------------------------------------------------------- 공통 유틸

func decodeBody(r *http.Request, v any) error {
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		return fail(400, "잘못된 요청입니다.")
	}
	return nil
}

var (
	sectionRe = regexp.MustCompile(`^\s*(?:;\s*<|<)`)
	trailWs   = regexp.MustCompile(`[ \t]+$`)
)

// normalizePolicyFormatting 은 화면(JS)의 normalizePolicyFormatting 과 동일하게 동작합니다.
// 빈 줄을 없애고, 섹션(<...>) 앞에만 빈 줄을 하나 둡니다.
func normalizePolicyFormatting(v string) string {
	v = strings.ReplaceAll(strings.ReplaceAll(v, "\r\n", "\n"), "\r", "\n")
	var out []string
	for _, raw := range strings.Split(v, "\n") {
		line := trailWs.ReplaceAllString(raw, "")
		if strings.TrimSpace(line) == "" {
			continue
		}
		if len(out) > 0 && sectionRe.MatchString(line) && out[len(out)-1] != "" {
			out = append(out, "")
		}
		out = append(out, line)
	}
	return strings.Join(out, "\n")
}

func revisionOf(content string) string {
	h := sha256.Sum256([]byte(normalizePolicyFormatting(content)))
	return hex.EncodeToString(h[:])
}

func nonBlankLines(t string) []string {
	var out []string
	for _, ln := range strings.Split(strings.ReplaceAll(t, "\r", ""), "\n") {
		ln = trailWs.ReplaceAllString(ln, "")
		if strings.TrimSpace(ln) != "" {
			out = append(out, ln)
		}
	}
	return out
}

func policyInfo(content string) map[string]any {
	c := normalizePolicyFormatting(content)
	n := 0
	if c != "" {
		n = len(nonBlankLines(c))
	}
	return map[string]any{"revision": revisionOf(c), "content": c, "lineCount": n}
}

var markerRe = regexp.MustCompile(`^[A-Za-z0-9._-]{1,128}$`)

func chooseApplyMarker(content string) string {
	lines := map[string]bool{}
	for _, ln := range strings.Split(content, "\n") {
		lines[strings.TrimSpace(ln)] = true
	}
	for i := 1; i < 1000; i++ {
		m := fmt.Sprintf("EOF_POLICY_EDITOR_%d", i)
		if !lines[m] {
			return m
		}
	}
	return "EOF_POLICY_EDITOR_X"
}

func buildFinalBlock(content, marker string) string {
	return "inline policy local " + marker + "\n" + content + "\n" + marker
}

var inlineHeadRe = regexp.MustCompile(`(?i)^\s*inline\s+policy\s+local\s+([A-Za-z0-9._-]{1,128})\s*$`)

// parseFinalBlock 은 'inline policy local X ... X' 형식을 검증하고 본문을 돌려줍니다.
func parseFinalBlock(block string) (marker, content string, err error) {
	lines := strings.Split(strings.ReplaceAll(strings.ReplaceAll(block, "\r\n", "\n"), "\r", "\n"), "\n")
	for len(lines) > 0 && strings.TrimSpace(lines[0]) == "" {
		lines = lines[1:]
	}
	for len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) == "" {
		lines = lines[:len(lines)-1]
	}
	if len(lines) < 3 {
		return "", "", fail(400, "최종 정책 형식이 올바르지 않습니다.")
	}
	m := inlineHeadRe.FindStringSubmatch(lines[0])
	if m == nil {
		return "", "", fail(400, "첫 줄은 inline policy local EOF 형식이어야 합니다.")
	}
	marker = m[1]
	if strings.TrimSpace(lines[len(lines)-1]) != marker {
		return "", "", fail(400, fmt.Sprintf("마지막 delimiter가 %s와 일치하지 않습니다.", marker))
	}
	body := lines[1 : len(lines)-1]
	for _, b := range body {
		if strings.TrimSpace(b) == marker {
			return "", "", fail(400, fmt.Sprintf("본문에 delimiter(%s)와 같은 단독 행이 있습니다.", marker))
		}
	}
	content = normalizePolicyFormatting(strings.Join(body, "\n"))
	if content == "" {
		return "", "", fail(400, "최종 정책이 비어 있습니다.")
	}
	if regexp.MustCompile(`(?i)\bclient\.address\s*=\s*x\.x\.x\.x\b`).MatchString(content) {
		return "", "", fail(400, "x.x.x.x를 실제 IP/Subnet으로 변경하세요.")
	}
	return marker, content, nil
}

// ---------------------------------------------------------------- 장비에서 local policy 읽기/쓰기

var cmdRejectedRe = regexp.MustCompile(`(?im)^\s*%\s*(invalid|ambiguous|incomplete|unrecognized|error)`)

func openPrivileged(c *Conn, extraSecrets ...string) (*sshSession, error) {
	s, err := startSSH(c, extraSecrets...)
	if err != nil {
		return nil, err
	}
	if err := s.ensurePrivileged(c.EnablePassword); err != nil {
		s.Close()
		return nil, err
	}
	return s, nil
}

// readLocalPolicy 는 'show advanced-url /local_policy_source.txt' 로 현재 Local Policy 를 읽습니다.
func readLocalPolicy(s *sshSession) (string, error) {
	out, err := s.run("show advanced-url /local_policy_source.txt", runOpts{Quiet: true, Timeout: 120 * time.Second})
	if err != nil {
		return "", fail(502, "Local Policy 조회 중 오류: "+err.Error())
	}
	lines := strings.Split(strings.ReplaceAll(out, "\r", ""), "\n")
	// 명령 echo 와 마지막 프롬프트 줄 제거
	for len(lines) > 0 && strings.TrimSpace(lines[0]) == "" {
		lines = lines[1:]
	}
	if len(lines) > 0 && strings.Contains(lines[0], "show advanced-url") {
		lines = lines[1:]
	}
	if len(lines) > 0 && promptRe.MatchString("\n"+lines[len(lines)-1]) {
		lines = lines[:len(lines)-1]
	}
	text := strings.Join(lines, "\n")
	head := text
	if len(head) > 600 {
		head = head[:600]
	}
	if cmdRejectedRe.MatchString(head) {
		return "", fail(502, "장비가 'show advanced-url /local_policy_source.txt' 명령을 거부했습니다. 계정 권한(enable)과 SGOS 버전을 확인하세요.")
	}
	return normalizePolicyFormatting(text), nil
}

var applyMsgRe = regexp.MustCompile(`(?i)(^\s*%)|\berror\b|\bwarning\b|syntax error|invalid`)

func extractApplyMessages(out string) string {
	var msgs []string
	for _, ln := range strings.Split(out, "\n") {
		t := strings.TrimSpace(ln)
		if t == "" || strings.Contains(t, "inline policy local") {
			continue
		}
		if applyMsgRe.MatchString(t) {
			msgs = append(msgs, t)
		}
	}
	return strings.Join(msgs, "\n")
}

// installLocalPolicy 는 config 모드에서 정책을 교체하고 (출력, 오류)를 돌려줍니다.
func installLocalPolicy(s *sshSession, marker, content string) (string, error) {
	out, err := s.run("configure terminal", runOpts{})
	if err != nil {
		return "", fail(502, "configure terminal 실패: "+err.Error())
	}
	if !strings.Contains(lastLine(out), "(config") {
		return out, fail(502, "Config 모드 진입에 실패했습니다. 권한(enable)을 확인하세요.")
	}
	res, err := s.inlinePolicyLocal(marker, content)
	s.run("exit", runOpts{})
	if err != nil {
		return res, fail(502, "정책 적용 중 장비 응답 오류: "+err.Error())
	}
	return res, nil
}

// ---------------------------------------------------------------- Trace 중복 판단

var (
	defCondRe = regexp.MustCompile(`(?i)^\s*define\s+condition\s+(\S+)\s*$`)
	endCondRe = regexp.MustCompile(`(?i)^\s*end\s+condition\b`)
	layerRe   = regexp.MustCompile(`^\s*<([A-Za-z0-9_-]+)(?:\s+[^>]*)?>\s*$`)
	condRefRe = regexp.MustCompile(`(?i)^condition=(\S+)$`)
	wsRe      = regexp.MustCompile(`\s+`)
)

// traceSignatures 는 정책 텍스트에서 trace.request(yes) 를 가진 <Proxy> 규칙을
// condition 이름과 공백에 무관한 서명으로 바꿉니다.
func traceSignatures(text string) []string {
	conds := map[string]string{}
	var cur string
	var body []string
	type pending struct{ line string }
	var rules []string
	layer := ""
	inCond := false
	for _, raw := range strings.Split(strings.ReplaceAll(text, "\r", ""), "\n") {
		ln := strings.TrimSpace(raw)
		if ln == "" || strings.HasPrefix(ln, ";") {
			continue
		}
		if m := defCondRe.FindStringSubmatch(ln); m != nil {
			cur, body, inCond = m[1], nil, true
			continue
		}
		if inCond {
			if endCondRe.MatchString(ln) {
				sort.Strings(body)
				conds[cur] = strings.Join(body, "|")
				inCond = false
				continue
			}
			body = append(body, strings.ToLower(wsRe.ReplaceAllString(ln, "")))
			continue
		}
		if m := layerRe.FindStringSubmatch(ln); m != nil {
			layer = strings.ToLower(m[1])
			continue
		}
		if layer == "proxy" && strings.Contains(strings.ToLower(ln), "trace.request(yes)") {
			rules = append(rules, ln)
		}
	}
	var sigs []string
	for _, r := range rules {
		var guards, acts []string
		for _, tok := range strings.Fields(r) {
			if m := condRefRe.FindStringSubmatch(tok); m != nil {
				guards = append(guards, "{"+conds[m[1]]+"}")
			} else {
				acts = append(acts, strings.ToLower(tok))
			}
		}
		sort.Strings(guards)
		sort.Strings(acts)
		sigs = append(sigs, strings.Join(guards, "&")+"#"+strings.Join(acts, " "))
	}
	return sigs
}

func hasDuplicateTrace(policy, insertion string) bool {
	ins := traceSignatures(insertion)
	if len(ins) == 0 {
		return false
	}
	have := map[string]bool{}
	for _, s := range traceSignatures(policy) {
		have[s] = true
	}
	for _, s := range ins {
		if have[s] {
			return true
		}
	}
	return false
}

func mergeInsertion(original, insertion string) string {
	o := normalizePolicyFormatting(original)
	ins := strings.TrimRight(strings.ReplaceAll(insertion, "\r\n", "\n"), "\n ")
	if o == "" {
		return normalizePolicyFormatting(ins)
	}
	return normalizePolicyFormatting(o + "\n\n" + ins)
}

// ---------------------------------------------------------------- API

type policyReq struct {
	Conn
	Revision        string `json:"revision"`
	OriginalContent string `json:"originalContent"`
	Insertion       string `json:"insertion"`
	FinalBlock      string `json:"finalBlock"`
	ManualEdited    bool   `json:"manualEdited"`
	AllowDuplicate  bool   `json:"allowDuplicate"`
	ExactBlock      string `json:"exactBlock"`
}

func apiReadPolicy(r *http.Request) (any, error) {
	var c Conn
	if err := decodeBody(r, &c); err != nil {
		return nil, err
	}
	s, err := openPrivileged(&c)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	text, err := readLocalPolicy(s)
	if err != nil {
		return nil, err
	}
	return map[string]any{"policy": policyInfo(text)}, nil
}

func apiPreview(r *http.Request) (any, error) {
	var q policyReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if strings.TrimSpace(q.Insertion) == "" {
		return nil, fail(400, "추가할 Trace 정책이 비어 있습니다.")
	}
	if hasDuplicateTrace(q.OriginalContent, q.Insertion) {
		return map[string]any{"duplicate": true}, nil
	}
	merged := mergeInsertion(q.OriginalContent, q.Insertion)
	marker := chooseApplyMarker(merged)
	return map[string]any{"duplicate": false, "finalBlock": buildFinalBlock(merged, marker), "applyMarker": marker}, nil
}

func linesEqual(a, b []string) (int, bool) {
	mm := 0
	n := len(a)
	if len(b) > n {
		n = len(b)
	}
	for i := 0; i < n; i++ {
		var x, y string
		if i < len(a) {
			x = strings.TrimSpace(a[i])
		}
		if i < len(b) {
			y = strings.TrimSpace(b[i])
		}
		if x != y {
			mm++
		}
	}
	return mm, mm == 0
}

func apiApplyPolicy(r *http.Request) (any, error) {
	var q policyReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	marker, content, err := parseFinalBlock(q.FinalBlock)
	if err != nil {
		return nil, err
	}
	s, err := openPrivileged(&q.Conn)
	if err != nil {
		return nil, err
	}
	defer s.Close()

	// 1) 적용 직전 재조회: 화면이 본 revision 과 다르면 중단
	cur, err := readLocalPolicy(s)
	if err != nil {
		return nil, err
	}
	if q.Revision != "" && revisionOf(cur) != q.Revision {
		return nil, failCode(409, "POLICY_CHANGED", "조회 이후 장비의 Local Policy가 변경되었습니다. 최종 정책을 다시 생성하세요.",
			map[string]any{"currentPolicy": cur})
	}
	insertion := strings.TrimSpace(q.Insertion)
	if insertion != "" && !q.AllowDuplicate && !q.ManualEdited && hasDuplicateTrace(cur, insertion) {
		return nil, failCode(409, "DUPLICATE_TRACE", "동일한 Trace 정책이 현재 Local Policy에 이미 존재합니다. 중복 적용하지 않습니다.", nil)
	}

	// 2) 적용
	out, err := installLocalPolicy(s, marker, content)
	msgs := extractApplyMessages(out)
	if err != nil {
		return nil, failCode(502, "APPLY_FAILED", err.Error(), map[string]any{"applyOutput": out, "applyMessages": msgs})
	}

	// 3) 재검증
	after, err := readLocalPolicy(s)
	if err != nil {
		return nil, failCode(502, "VERIFY_FAILED", "적용 후 재검증을 위한 Local Policy 조회에 실패했습니다: "+err.Error(),
			map[string]any{"applyOutput": out, "applyMessages": msgs})
	}
	want, got := nonBlankLines(content), nonBlankLines(after)
	if mm, ok := linesEqual(want, got); !ok {
		return nil, failCode(500, "VERIFY_FAILED", "적용 후 재검증에 실패했습니다. 장비의 Local Policy가 최종 정책과 다릅니다.",
			map[string]any{"applyOutput": out, "applyMessages": msgs, "expectedNonBlankLines": len(want),
				"currentNonBlankLines": len(got), "mismatchCount": mm, "finalRevision": revisionOf(after), "currentPolicy": after})
	}
	removable := ""
	if insertion != "" {
		removable = insertion
	}
	return map[string]any{"policy": policyInfo(after), "applyMarker": marker, "applyMessages": msgs, "removableTraceBlock": removable}, nil
}

func apiPrepareRemove(r *http.Request) (any, error) {
	var q policyReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	block := nonBlankLines(q.ExactBlock)
	if len(block) == 0 {
		return nil, fail(400, "제거할 Trace 정책 기록이 없습니다.")
	}
	s, err := openPrivileged(&q.Conn)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	cur, err := readLocalPolicy(s)
	if err != nil {
		return nil, err
	}
	pol := strings.Split(cur, "\n")
	// 비어 있지 않은 줄의 원래 위치
	var idx []int
	var nb []string
	for i, ln := range pol {
		if strings.TrimSpace(ln) != "" {
			idx = append(idx, i)
			nb = append(nb, strings.TrimSpace(ln))
		}
	}
	want := make([]string, len(block))
	for i, b := range block {
		want[i] = strings.TrimSpace(b)
	}
	var starts []int
	for i := 0; i+len(want) <= len(nb); i++ {
		ok := true
		for j := range want {
			if nb[i+j] != want[j] {
				ok = false
				break
			}
		}
		if ok {
			starts = append(starts, i)
		}
	}
	if len(starts) == 0 {
		return nil, removeNotFound(nb, want)
	}
	if len(starts) > 1 {
		return nil, failCode(409, "TRACE_BLOCK_AMBIGUOUS",
			fmt.Sprintf("동일한 Trace 정책이 %d곳에서 발견되어 중단합니다. 자동 제거하지 않습니다.", len(starts)),
			map[string]any{"summary": fmt.Sprintf("일치 구간 %d개", len(starts)), "expectedBlock": strings.Join(block, "\n")})
	}
	a, b := idx[starts[0]], idx[starts[0]+len(want)-1]
	rest := append(append([]string{}, pol[:a]...), pol[b+1:]...)
	content := normalizePolicyFormatting(strings.Join(rest, "\n"))
	if content == "" {
		content = "; (Trace 정책 제거 후 비어 있는 Local Policy)"
	}
	marker := chooseApplyMarker(content)
	return map[string]any{"policy": policyInfo(cur), "finalBlock": buildFinalBlock(content, marker), "applyMarker": marker}, nil
}

func removeNotFound(nb, want []string) error {
	best, bestScore := 0, -1
	for i := 0; i+len(want) <= len(nb) || i == 0; i++ {
		score := 0
		for j := range want {
			if i+j < len(nb) && nb[i+j] == want[j] {
				score++
			}
		}
		if score > bestScore {
			best, bestScore = i, score
		}
		if i+len(want) > len(nb) {
			break
		}
	}
	var diffs []map[string]any
	var closest []string
	for j := range want {
		act := ""
		if best+j < len(nb) {
			act = nb[best+j]
			closest = append(closest, act)
		}
		if act != want[j] {
			diffs = append(diffs, map[string]any{"policyLine": best + j + 1, "blockLine": j + 1, "expected": want[j], "actual": act})
		}
	}
	return failCode(404, "TRACE_BLOCK_NOT_FOUND", "현재 Local Policy에서 동일한 Trace 정책을 찾지 못했습니다. 이미 제거되었거나 수동으로 변경되었을 수 있습니다.",
		map[string]any{"summary": fmt.Sprintf("%d줄 중 %d줄 일치 (불일치 %d줄)", len(want), bestScore, len(want)-bestScore),
			"differences": diffs, "expectedBlock": strings.Join(want, "\n"), "closestCurrentBlock": strings.Join(closest, "\n"),
			"expectedNonBlankLines": len(want), "currentNonBlankLines": len(nb), "mismatchCount": len(want) - bestScore})
}
