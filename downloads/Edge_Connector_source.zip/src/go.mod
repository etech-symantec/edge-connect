module proxysgeditor

go 1.21
