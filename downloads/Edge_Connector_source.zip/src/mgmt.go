package main

import (
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

func apiSystem(r *http.Request) (any, error) {
	p, err := findSSH()
	if err != nil {
		return map[string]any{"sshFound": false, "error": err.Error(), "version": appVersion}, nil
	}
	return map[string]any{"sshFound": true, "sshPath": p, "version": appVersion}, nil
}

func apiTestConnection(r *http.Request) (any, error) {
	var c Conn
	if err := decodeBody(r, &c); err != nil {
		return nil, err
	}
	s, err := openPrivileged(&c)
	if err != nil {
		return nil, err
	}
	defer s.Close()
	out, _ := s.run("", runOpts{})
	return map[string]any{"prompt": lastLine(out)}, nil
}

// ---------------------------------------------------------------- Management HTTP(S)

var traceNameRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$`)
var logNameRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$`)

func (c *Conn) mgmtBase() (string, error) {
	c.Host = strings.TrimSpace(c.Host)
	if c.Host == "" || !hostRe.MatchString(c.Host) {
		return "", fail(400, "장비 IP / Hostname을 확인하세요.")
	}
	proto := strings.ToLower(c.MgmtProtocol)
	if proto != "http" && proto != "https" {
		proto = "https"
	}
	port := c.MgmtPort
	if port == 0 {
		port = 8082
	}
	if port < 1 || port > 65535 {
		return "", fail(400, "Management Port 범위가 올바르지 않습니다.")
	}
	host := c.Host
	if strings.Contains(host, ":") {
		host = "[" + host + "]"
	}
	return fmt.Sprintf("%s://%s:%d", proto, host, port), nil
}

func (c *Conn) mgmtClient(timeout time.Duration) *http.Client {
	tr := &http.Transport{
		TLSClientConfig:     &tls.Config{InsecureSkipVerify: c.MgmtSkipTLS},
		DialContext:         (&net.Dialer{Timeout: 10 * time.Second}).DialContext,
		DisableKeepAlives:   true,
		TLSHandshakeTimeout: 10 * time.Second,
		Proxy:               nil, // 장비에는 시스템 프록시를 거치지 않고 직접 접속
	}
	return &http.Client{Transport: tr, Timeout: timeout, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
}

type mgmtResp struct {
	Status  int
	Body    []byte
	Header  http.Header
	Elapsed time.Duration
}

func (c *Conn) mgmtDo(method, path string, hdr map[string]string, timeout time.Duration, maxBytes int64) (*mgmtResp, error) {
	base, err := c.mgmtBase()
	if err != nil {
		return nil, err
	}
	user, pass := c.MgmtUsername, c.MgmtPassword
	if user == "" {
		user, pass = c.Username, c.Password
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, method, base+path, nil)
	if err != nil {
		return nil, fail(400, err.Error())
	}
	req.SetBasicAuth(user, pass)
	for k, v := range hdr {
		req.Header.Set(k, v)
	}
	t0 := time.Now()
	resp, err := c.mgmtClient(timeout).Do(req)
	if err != nil {
		return nil, fail(502, "Management Console 연결 실패: "+maskPass(err.Error(), pass))
	}
	defer resp.Body.Close()
	body, rerr := io.ReadAll(io.LimitReader(resp.Body, maxBytes))
	if rerr != nil && len(body) == 0 && ctx.Err() == nil {
		return nil, fail(502, "Management Console 응답 읽기 실패: "+rerr.Error())
	}
	return &mgmtResp{Status: resp.StatusCode, Body: body, Header: resp.Header, Elapsed: time.Since(t0)}, nil
}

func maskPass(s, p string) string {
	if p != "" {
		s = strings.ReplaceAll(s, p, "********")
	}
	return s
}

func mgmtStatusErr(resp *mgmtResp, what string) error {
	switch {
	case resp.Status == 401 || resp.Status == 403:
		return fail(401, fmt.Sprintf("Management Console 인증에 실패했습니다(HTTP %d). Management 계정/비밀번호를 확인하세요.", resp.Status))
	case resp.Status == 404:
		return fail(404, what+" 경로를 찾을 수 없습니다(HTTP 404).")
	case resp.Status >= 400:
		return fail(502, fmt.Sprintf("%s 조회 실패 (HTTP %d)", what, resp.Status))
	}
	return nil
}

var hrefRe = regexp.MustCompile(`(?is)href\s*=\s*["']([^"']+)["']`)

func hrefsAfter(body []byte, marker string) []string {
	seen := map[string]bool{}
	var out []string
	lm := strings.ToLower(marker)
	for _, m := range hrefRe.FindAllSubmatch(body, -1) {
		h := string(m[1])
		if i := strings.Index(strings.ToLower(h), lm); i >= 0 {
			name := h[i+len(lm):]
			if j := strings.IndexAny(name, "?#/"); j >= 0 {
				name = name[:j]
			}
			if u, err := url.PathUnescape(name); err == nil {
				name = u
			}
			if name != "" && !seen[name] {
				seen[name] = true
				out = append(out, name)
			}
		}
	}
	return out
}

func listTraceFiles(c *Conn) ([]string, *mgmtResp, error) {
	resp, err := c.mgmtDo("GET", "/policy", map[string]string{"Accept": "text/html,*/*"}, 20*time.Second, 4<<20)
	if err != nil {
		return nil, nil, err
	}
	if e := mgmtStatusErr(resp, "/policy"); e != nil {
		return nil, resp, e
	}
	files := hrefsAfter(resp.Body, "/policy/trace/")
	var ok []string
	for _, f := range files {
		if traceNameRe.MatchString(f) {
			ok = append(ok, f)
		}
	}
	sort.Slice(ok, func(i, j int) bool { return strings.ToLower(ok[i]) < strings.ToLower(ok[j]) })
	return ok, resp, nil
}

func apiTestManagement(r *http.Request) (any, error) {
	var c Conn
	if err := decodeBody(r, &c); err != nil {
		return nil, err
	}
	files, resp, err := listTraceFiles(&c)
	if err != nil {
		return nil, err
	}
	base, _ := c.mgmtBase()
	return map[string]any{"httpStatus": resp.Status, "files": len(files), "url": base + "/policy"}, nil
}

func apiListTraces(r *http.Request) (any, error) {
	var c Conn
	if err := decodeBody(r, &c); err != nil {
		return nil, err
	}
	files, _, err := listTraceFiles(&c)
	if err != nil {
		return nil, err
	}
	if files == nil {
		files = []string{}
	}
	return map[string]any{"files": files, "count": len(files), "transport": strings.ToUpper(orDefault(c.MgmtProtocol, "https")), "readAt": nowStr()}, nil
}

func orDefault(s, d string) string {
	if s == "" {
		return d
	}
	return s
}

func nowStr() string { return time.Now().Format("2006-01-02 15:04:05") }

type traceReq struct {
	Conn
	TraceFile    string `json:"traceFile"`
	Offset       int64  `json:"offset"`
	ETag         string `json:"etag"`
	LastModified string `json:"lastModified"`
	ForceFull    bool   `json:"forceFull"`
	LogName      string `json:"logName"`
}

var contentRangeStarRe = regexp.MustCompile(`(?i)^bytes\s+\*/(\d+)$`)
var contentRangeRe = regexp.MustCompile(`(?i)^bytes\s+(\d+)-(\d+)/(\d+|\*)$`)

func apiReadTrace(r *http.Request) (any, error) {
	var q traceReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if !traceNameRe.MatchString(q.TraceFile) {
		return nil, fail(400, "Trace 파일명 형식이 올바르지 않습니다.")
	}
	path := "/Policy/Trace/" + url.PathEscape(q.TraceFile)
	hdr := map[string]string{"Accept": "text/html,text/plain,*/*", "Accept-Encoding": "identity"}
	incremental := !q.ForceFull && q.Offset > 0
	if incremental {
		hdr["Range"] = "bytes=" + strconv.FormatInt(q.Offset, 10) + "-"
		if q.ETag != "" {
			hdr["If-None-Match"] = q.ETag
		} else if q.LastModified != "" {
			hdr["If-Modified-Since"] = q.LastModified
		}
	}
	resp, err := q.Conn.mgmtDo("GET", path, hdr, 25*time.Second, 64<<20)
	if err != nil {
		return nil, err
	}
	etag, lm := resp.Header.Get("ETag"), resp.Header.Get("Last-Modified")
	t := map[string]any{"fileName": q.TraceFile, "httpStatus": resp.Status, "readAt": nowStr(), "etag": etag, "lastModified": lm}
	switch {
	case resp.Status == 304:
		upd(t, incrementalUnchanged(q.Offset, etag, lm))
	case resp.Status == 416:
		total := q.Offset
		if m := contentRangeStarRe.FindStringSubmatch(resp.Header.Get("Content-Range")); m != nil {
			total, _ = strconv.ParseInt(m[1], 10, 64)
		}
		if total < q.Offset { // 파일이 줄어듦(재생성) -> 전체 다시 읽기 필요
			return readTraceFull(&q.Conn, path, q.TraceFile)
		}
		upd(t, map[string]any{"mode": "append", "content": "", "changed": false, "nextOffset": total, "totalBytes": total})
	case resp.Status == 206:
		var start, total int64 = q.Offset, 0
		if m := contentRangeRe.FindStringSubmatch(resp.Header.Get("Content-Range")); m != nil {
			start, _ = strconv.ParseInt(m[1], 10, 64)
			total, _ = strconv.ParseInt(m[3], 10, 64)
		}
		next := start + int64(len(resp.Body))
		if total == 0 {
			total = next
		}
		upd(t, map[string]any{"mode": "append", "content": string(resp.Body), "changed": len(resp.Body) > 0, "nextOffset": next, "totalBytes": total})
	case resp.Status == 200:
		upd(t, map[string]any{"mode": "full", "content": string(resp.Body), "changed": true, "nextOffset": int64(len(resp.Body)), "totalBytes": int64(len(resp.Body))})
	default:
		if e := mgmtStatusErr(resp, "Trace 파일 "+q.TraceFile); e != nil {
			return nil, e
		}
		return nil, fail(502, fmt.Sprintf("Trace 조회 실패 (HTTP %d)", resp.Status))
	}
	return map[string]any{"trace": t}, nil
}

type m = map[string]any

func incrementalUnchanged(off int64, etag, lm string) m {
	return m{"mode": "append", "content": "", "changed": false, "nextOffset": off, "totalBytes": off}
}

func readTraceFull(c *Conn, path, name string) (any, error) {
	resp, err := c.mgmtDo("GET", path, map[string]string{"Accept-Encoding": "identity"}, 25*time.Second, 64<<20)
	if err != nil {
		return nil, err
	}
	if resp.Status != 200 {
		if e := mgmtStatusErr(resp, "Trace 파일 "+name); e != nil {
			return nil, e
		}
	}
	return map[string]any{"trace": m{"fileName": name, "httpStatus": resp.Status, "readAt": nowStr(), "etag": resp.Header.Get("ETag"),
		"lastModified": resp.Header.Get("Last-Modified"), "mode": "full", "content": string(resp.Body), "changed": true,
		"nextOffset": int64(len(resp.Body)), "totalBytes": int64(len(resp.Body))}}, nil
}

func apiDeleteTrace(r *http.Request) (any, error) {
	var q traceReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if !traceNameRe.MatchString(q.TraceFile) {
		return nil, fail(400, "Trace 파일명 형식이 올바르지 않습니다.")
	}
	resp, err := q.Conn.mgmtDo("POST", "/Policy/Delete-Trace/"+url.PathEscape(q.TraceFile), nil, 20*time.Second, 1<<20)
	if err != nil {
		return nil, err
	}
	if resp.Status >= 400 {
		return nil, mgmtStatusErr(resp, "Trace 삭제")
	}
	files, _, err := listTraceFiles(&q.Conn)
	if err != nil {
		files = nil
	}
	out := []string{}
	for _, f := range files {
		if f != q.TraceFile {
			out = append(out, f)
		}
	}
	return map[string]any{"files": out, "deleted": q.TraceFile}, nil
}

func apiListAccessLogs(r *http.Request) (any, error) {
	var c Conn
	if err := decodeBody(r, &c); err != nil {
		return nil, err
	}
	resp, err := c.mgmtDo("GET", "/Accesslog/statistics", map[string]string{"Accept": "text/html,*/*"}, 20*time.Second, 4<<20)
	if err != nil {
		return nil, err
	}
	if e := mgmtStatusErr(resp, "/Accesslog/statistics"); e != nil {
		return nil, e
	}
	logs := []string{}
	for _, n := range hrefsAfter(resp.Body, "/accesslog/statistics/") {
		if logNameRe.MatchString(n) {
			logs = append(logs, n)
		}
	}
	sort.Slice(logs, func(i, j int) bool { return strings.ToLower(logs[i]) < strings.ToLower(logs[j]) })
	return map[string]any{"logs": logs, "count": len(logs), "readAt": nowStr()}, nil
}

// apiReadAccessLog 는 /Accesslog/tail-f/<로그명> 이 흘려주는 최근 로그를 잠시 읽어 돌려줍니다.
func apiReadAccessLog(r *http.Request) (any, error) {
	var q traceReq
	if err := decodeBody(r, &q); err != nil {
		return nil, err
	}
	if !logNameRe.MatchString(q.LogName) {
		return nil, fail(400, "Access Log 이름 형식이 올바르지 않습니다.")
	}
	base, err := q.Conn.mgmtBase()
	if err != nil {
		return nil, err
	}
	user, pass := q.MgmtUsername, q.MgmtPassword
	if user == "" {
		user, pass = q.Username, q.Password
	}
	ctx, cancel := context.WithTimeout(context.Background(), 1800*time.Millisecond)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "GET", base+"/Accesslog/tail-f/"+url.PathEscape(q.LogName), nil)
	req.SetBasicAuth(user, pass)
	req.Header.Set("Accept-Encoding", "identity")
	resp, err := q.Conn.mgmtClient(0).Do(req)
	if err != nil {
		if ctx.Err() != nil {
			return map[string]any{"content": "", "httpStatus": 200, "readAt": nowStr()}, nil
		}
		return nil, fail(502, "Access Log 연결 실패: "+maskPass(err.Error(), pass))
	}
	defer resp.Body.Close()
	if e := mgmtStatusErr(&mgmtResp{Status: resp.StatusCode}, "Access Log "+q.LogName); e != nil {
		return nil, e
	}
	data, _ := io.ReadAll(io.LimitReader(resp.Body, 2<<20)) // 타임아웃으로 끊기면 받은 만큼만 사용
	return map[string]any{"content": string(data), "httpStatus": resp.StatusCode, "readAt": nowStr()}, nil
}

func upd(t, u map[string]any) {
	for k, v := range u {
		t[k] = v
	}
}
